// ============================================================
// avatar.js — Sistema de avatar (customização, mesh humanoide, remoto)
// ============================================================
(function() {
'use strict';

let avatarPreviewScene = null;
let avatarPreviewCamera = null;
let avatarPreviewRenderer = null;
let avatarPreviewMesh = null;
let avatarPreviewAnim = 0;

const HAIR_STYLES = ['short', 'long', 'spiky', 'bald', 'mohawk', 'ponytail'];
const CLOTHES = ['tshirt', 'hoodie', 'suit', 'tank', 'jacket'];
const SHOES = ['sneakers', 'boots', 'sandals', 'bare'];
const HATS = [null, 'cap', 'helmet', 'tophat', 'beanie', 'crown'];
const GLASSES = [null, 'sunglasses', 'round', 'vr', 'visor'];
const MASKS = [null, 'clown', 'ninja', 'cyborg', 'skull'];
const BACKS = [null, 'backpack', 'wings', 'cape', 'jetpack'];

const COLORS = ['#ffcc99','#f5cba7','#e8b796','#d4a373','#a87c5f','#7d5233',
  '#3b82f6','#ef4444','#10b981','#fbbf24','#a855f7','#ec4899','#0f172a','#ffffff','#6b7280'];

function buildAvatarMesh(customization, accessories) {
  const c = customization || {};
  const a = accessories || {};
  const group = new THREE.Group();

  const head = new THREE.Mesh(
    new THREE.BoxGeometry(0.5, 0.5, 0.5),
    new THREE.MeshLambertMaterial({ color: c.headColor || '#ffcc99' })
  );
  head.position.y = 1.7;
  head.name = 'head';
  group.add(head);

  const eyeGeom = new THREE.SphereGeometry(0.06, 8, 8);
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0x222222 });
  const leftEye = new THREE.Mesh(eyeGeom, eyeMat);
  leftEye.position.set(-0.12, 1.75, 0.25);
  const rightEye = new THREE.Mesh(eyeGeom, eyeMat);
  rightEye.position.set(0.12, 1.75, 0.25);
  group.add(leftEye, rightEye);

  const mouth = new THREE.Mesh(
    new THREE.BoxGeometry(0.18, 0.04, 0.02),
    new THREE.MeshBasicMaterial({ color: 0x662222 })
  );
  mouth.position.set(0, 1.62, 0.25);
  group.add(mouth);

  applyHair(group, c.hairStyle || 'short', c.hairColor || '#3a2a1a');

  const torso = new THREE.Mesh(
    new THREE.BoxGeometry(0.7, 0.85, 0.35),
    new THREE.MeshLambertMaterial({ color: c.clothesColor || '#3b82f6' })
  );
  torso.position.y = 1.05;
  torso.name = 'torso';
  group.add(torso);
  applyClothesPattern(group, c.clothes || 'tshirt', c);

  const armGeom = new THREE.BoxGeometry(0.2, 0.75, 0.2);
  const armMat = new THREE.MeshLambertMaterial({ color: c.armsColor || '#ffcc99' });
  const leftArm = new THREE.Mesh(armGeom, armMat);
  leftArm.name = 'leftArm';
  leftArm.geometry.translate(0, -0.375, 0);
  leftArm.position.set(-0.45, 1.45, 0);
  const rightArm = new THREE.Mesh(armGeom.clone(), armMat);
  rightArm.name = 'rightArm';
  rightArm.geometry.translate(0, -0.375, 0);
  rightArm.position.set(0.45, 1.45, 0);
  group.add(leftArm, rightArm);

  const legGeom = new THREE.BoxGeometry(0.25, 0.8, 0.25);
  const legMat = new THREE.MeshLambertMaterial({ color: c.legsColor || '#1e293b' });
  const leftLeg = new THREE.Mesh(legGeom, legMat);
  leftLeg.name = 'leftLeg';
  leftLeg.geometry.translate(0, -0.4, 0);
  leftLeg.position.set(-0.18, 0.8, 0);
  const rightLeg = new THREE.Mesh(legGeom.clone(), legMat);
  rightLeg.name = 'rightLeg';
  rightLeg.geometry.translate(0, -0.4, 0);
  rightLeg.position.set(0.18, 0.8, 0);
  group.add(leftLeg, rightLeg);

  applyShoes(group, c.shoes || 'sneakers', c.shoesColor || '#0f172a');
  applyHat(group, a.hat);
  applyGlasses(group, a.glasses);
  applyMask(group, a.mask);
  applyBack(group, a.back);

  const nameSprite = createNameSprite('');
  nameSprite.position.set(0, 2.3, 0);
  nameSprite.name = 'nameSprite';
  group.add(nameSprite);

  const healthBar = createHealthBar();
  healthBar.position.set(0, 2.1, 0);
  healthBar.name = 'healthBar';
  group.add(healthBar);

  group.userData.type = 'avatar';
  return group;
}

function applyHair(group, style, color) {
  const mat = new THREE.MeshLambertMaterial({ color });
  if (style === 'bald') return;
  if (style === 'short') {
    const h = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.18, 0.52), mat);
    h.position.y = 1.95;
    group.add(h);
  } else if (style === 'long') {
    const h = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.35, 0.55), mat);
    h.position.y = 1.92;
    group.add(h);
    const back = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 0.1), mat);
    back.position.set(0, 1.65, -0.22);
    group.add(back);
  } else if (style === 'spiky') {
    for (let i = 0; i < 8; i++) {
      const s = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.25, 4), mat);
      const ang = (i / 8) * Math.PI * 2;
      s.position.set(Math.cos(ang) * 0.18, 2.0, Math.sin(ang) * 0.18);
      s.rotation.z = Math.cos(ang) * 0.3;
      s.rotation.x = -Math.sin(ang) * 0.3;
      group.add(s);
    }
  } else if (style === 'mohawk') {
    for (let i = 0; i < 5; i++) {
      const s = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.25, 0.08), mat);
      s.position.set(0, 1.95, -0.18 + i * 0.09);
      group.add(s);
    }
  } else if (style === 'ponytail') {
    const h = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.18, 0.52), mat);
    h.position.y = 1.95;
    group.add(h);
    const tail = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.5, 0.15), mat);
    tail.position.set(0, 1.7, -0.28);
    group.add(tail);
  }
}

function applyClothesPattern(group, type, c) {
  if (type === 'suit') {
    const tie = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.5, 0.02), new THREE.MeshBasicMaterial({ color: 0xff0000 }));
    tie.position.set(0, 1.05, 0.18);
    group.add(tie);
  } else if (type === 'hoodie') {
    const hood = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.25, 0.2), new THREE.MeshLambertMaterial({ color: c.clothesColor }));
    hood.position.set(0, 1.5, -0.18);
    group.add(hood);
  } else if (type === 'jacket') {
    const zip = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.8, 0.02), new THREE.MeshBasicMaterial({ color: 0x222222 }));
    zip.position.set(0, 1.05, 0.18);
    group.add(zip);
  }
}

function applyShoes(group, type, color) {
  const mat = new THREE.MeshLambertMaterial({ color });
  const leftShoe = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.15, 0.35), mat);
  leftShoe.position.set(-0.18, 0.07, 0.05);
  leftShoe.name = 'leftShoe';
  const rightShoe = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.15, 0.35), mat);
  rightShoe.position.set(0.18, 0.07, 0.05);
  rightShoe.name = 'rightShoe';
  group.add(leftShoe, rightShoe);
  if (type === 'bare') { leftShoe.visible = false; rightShoe.visible = false; }
}

function applyHat(group, type) {
  if (!type) return;
  const mat = new THREE.MeshLambertMaterial({ color: 0x222222 });
  if (type === 'cap') {
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat);
    cap.position.y = 2.0;
    group.add(cap);
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.04, 0.2), mat);
    visor.position.set(0, 1.97, 0.25);
    group.add(visor);
  } else if (type === 'helmet') {
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 12), new THREE.MeshLambertMaterial({ color: 0xffaa00 }));
    h.position.y = 1.95;
    group.add(h);
  } else if (type === 'tophat') {
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.05, 16), new THREE.MeshLambertMaterial({ color: 0x0a0a0a }));
    brim.position.y = 1.97;
    const top = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.5, 16), new THREE.MeshLambertMaterial({ color: 0x0a0a0a }));
    top.position.y = 2.25;
    group.add(brim, top);
  } else if (type === 'beanie') {
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshLambertMaterial({ color: 0x8b3aaf }));
    b.position.y = 2.0;
    group.add(b);
  } else if (type === 'crown') {
    const cg = new THREE.ConeGeometry(0.08, 0.2, 4);
    const cm = new THREE.MeshLambertMaterial({ color: 0xffd700 });
    for (let i = 0; i < 6; i++) {
      const c = new THREE.Mesh(cg, cm);
      const ang = (i / 6) * Math.PI * 2;
      c.position.set(Math.cos(ang) * 0.2, 2.15, Math.sin(ang) * 0.2);
      group.add(c);
    }
  }
}

function applyGlasses(group, type) {
  if (!type) return;
  const mat = new THREE.MeshBasicMaterial({ color: 0x111111 });
  if (type === 'sunglasses') {
    const l = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.08, 0.02), mat);
    l.position.set(-0.12, 1.78, 0.25);
    const r = l.clone();
    r.position.x = 0.12;
    group.add(l, r);
  } else if (type === 'round') {
    const l = new THREE.Mesh(new THREE.TorusGeometry(0.08, 0.015, 8, 16), mat);
    l.position.set(-0.12, 1.78, 0.25);
    const r = l.clone();
    r.position.x = 0.12;
    group.add(l, r);
  } else if (type === 'vr') {
    const v = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.15, 0.1), mat);
    v.position.set(0, 1.78, 0.2);
    group.add(v);
  } else if (type === 'visor') {
    const v = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.1, 0.05), new THREE.MeshBasicMaterial({ color: 0x00ffaa, transparent: true, opacity: 0.7 }));
    v.position.set(0, 1.78, 0.25);
    group.add(v);
  }
}

function applyMask(group, type) {
  if (!type) return;
  if (type === 'clown') {
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), new THREE.MeshBasicMaterial({ color: 0xff0000 }));
    nose.position.set(0, 1.68, 0.27);
    group.add(nose);
  } else if (type === 'ninja') {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.18, 0.02), new THREE.MeshBasicMaterial({ color: 0x111111 }));
    m.position.set(0, 1.68, 0.25);
    group.add(m);
  } else if (type === 'cyborg') {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.15, 0.05), new THREE.MeshBasicMaterial({ color: 0x444444 }));
    m.position.set(0, 1.7, 0.23);
    group.add(m);
    const led = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 6), new THREE.MeshBasicMaterial({ color: 0xff0000 }));
    led.position.set(0.1, 1.72, 0.27);
    group.add(led);
  } else if (type === 'skull') {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.28, 8, 8), new THREE.MeshBasicMaterial({ color: 0xeeeeee }));
    m.position.set(0, 1.7, 0.02);
    m.scale.set(1, 1, 0.7);
    group.add(m);
  }
}

function applyBack(group, type) {
  if (!type) return;
  if (type === 'backpack') {
    const bp = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.55, 0.2), new THREE.MeshLambertMaterial({ color: 0x8b4513 }));
    bp.position.set(0, 1.1, -0.28);
    group.add(bp);
  } else if (type === 'wings') {
    const wingMat = new THREE.MeshLambertMaterial({ color: 0xffffff, side: THREE.DoubleSide });
    const lw = new THREE.Mesh(new THREE.PlaneGeometry(0.6, 0.8), wingMat);
    lw.position.set(-0.4, 1.2, -0.15);
    lw.rotation.y = 0.3;
    const rw = lw.clone();
    rw.position.x = 0.4;
    rw.rotation.y = -0.3;
    lw.name = 'leftWing';
    rw.name = 'rightWing';
    group.add(lw, rw);
  } else if (type === 'cape') {
    const cape = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 1.2), new THREE.MeshLambertMaterial({ color: 0x660000, side: THREE.DoubleSide }));
    cape.position.set(0, 1.1, -0.22);
    cape.rotation.x = -0.1;
    cape.name = 'cape';
    group.add(cape);
  } else if (type === 'jetpack') {
    const jp = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 0.7, 8), new THREE.MeshLambertMaterial({ color: 0x666666 }));
    jp.position.set(0, 1.2, -0.3);
    group.add(jp);
  }
}

function createNameSprite(text) {
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.font = 'bold 32px sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text || 'Jogador', 128, 32);
  const tex = new THREE.CanvasTexture(canvas);
  const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(1.2, 0.3, 1);
  sprite.userData.canvas = canvas;
  sprite.userData.ctx = ctx;
  sprite.userData.texture = tex;
  return sprite;
}

function updateNameSprite(sprite, text) {
  if (!sprite || !sprite.userData.canvas) return;
  const ctx = sprite.userData.ctx;
  ctx.clearRect(0, 0, 256, 64);
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.font = 'bold 32px sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text || 'Jogador', 128, 32);
  sprite.userData.texture.needsUpdate = true;
}

function createHealthBar() {
  const group = new THREE.Group();
  const bg = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.1), new THREE.MeshBasicMaterial({ color: 0x000000 }));
  const fill = new THREE.Mesh(new THREE.PlaneGeometry(0.78, 0.08), new THREE.MeshBasicMaterial({ color: 0x00ff00 }));
  fill.position.z = 0.001;
  fill.name = 'healthFill';
  group.add(bg, fill);
  return group;
}

function updateHealthBar(group, health) {
  const fill = group.getObjectByName('healthFill');
  if (!fill) return;
  const pct = Math.max(0, health) / 100;
  fill.scale.x = pct;
  fill.position.x = -(0.78 * (1 - pct)) / 2;
  fill.material.color.setHex(pct > 0.5 ? 0x00ff00 : pct > 0.25 ? 0xffaa00 : 0xff0000);
}

function applyCustomization(mesh, customization, accessories) {
  if (!mesh) return;
  const parent = mesh.parent;
  const pos = mesh.position.clone();
  const rot = mesh.rotation.clone();
  if (parent) parent.remove(mesh);
  disposeAvatar(mesh);
  const newMesh = buildAvatarMesh(customization, accessories);
  newMesh.position.copy(pos);
  newMesh.rotation.copy(rot);
  if (parent) parent.add(newMesh);
  return newMesh;
}

function createRemoteAvatar(name) {
  const mesh = buildAvatarMesh(window.Save.getAvatar(), window.Save.getAccessories());
  updateNameSprite(mesh.getObjectByName('nameSprite'), name);
  return mesh;
}

function updateRemoteInfo(rp) {
  if (!rp.mesh) return;
  const sprite = rp.mesh.getObjectByName('nameSprite');
  if (sprite) updateNameSprite(sprite, rp.name);
  const hb = rp.mesh.getObjectByName('healthBar');
  if (hb) updateHealthBar(hb, rp.health);
}

function setRemoteAnimation(mesh, anim) {
  if (!mesh) return;
  mesh.userData.animState = anim;
}

function animateAvatar(mesh, anim, time, delta) {
  if (!mesh) return;
  const leftArm = mesh.getObjectByName('leftArm');
  const rightArm = mesh.getObjectByName('rightArm');
  const leftLeg = mesh.getObjectByName('leftLeg');
  const rightLeg = mesh.getObjectByName('rightLeg');
  if (!leftArm || !rightArm || !leftLeg || !rightLeg) return;
  const t = time;

  if (anim === 'walk') {
    const swing = Math.sin(t * 8) * 0.6;
    leftLeg.rotation.x = swing; rightLeg.rotation.x = -swing;
    leftArm.rotation.x = -swing * 0.7; rightArm.rotation.x = swing * 0.7;
  } else if (anim === 'run') {
    const swing = Math.sin(t * 14) * 1.0;
    leftLeg.rotation.x = swing; rightLeg.rotation.x = -swing;
    leftArm.rotation.x = -swing * 0.9; rightArm.rotation.x = swing * 0.9;
  } else if (anim === 'jump') {
    leftLeg.rotation.x = 0.3; rightLeg.rotation.x = 0.3;
    leftArm.rotation.x = -0.8; rightArm.rotation.x = -0.8;
  } else if (anim === 'crouch') {
    leftLeg.rotation.x = -0.7; rightLeg.rotation.x = 0.7;
    leftArm.rotation.x = 0.3; rightArm.rotation.x = 0.3;
  } else if (anim === 'swim') {
    const s = Math.sin(t * 4);
    leftArm.rotation.x = -0.5 + s * 0.5;
    rightArm.rotation.x = -0.5 - s * 0.5;
    leftLeg.rotation.x = s * 0.3;
    rightLeg.rotation.x = -s * 0.3;
  } else if (anim === 'climb') {
    const s = Math.sin(t * 6);
    leftArm.rotation.x = -s * 0.8;
    rightArm.rotation.x = s * 0.8;
    leftLeg.rotation.x = s * 0.5;
    rightLeg.rotation.x = -s * 0.5;
  } else if (anim === 'wave') {
    leftArm.rotation.x = 0; leftArm.rotation.z = 0;
    rightArm.rotation.x = -2.4;
    rightArm.rotation.z = Math.sin(t * 10) * 0.3 - 0.5;
  } else if (anim === 'dance') {
    const s = Math.sin(t * 8);
    leftArm.rotation.z = 0.8 + s * 0.5;
    rightArm.rotation.z = -0.8 - s * 0.5;
    leftArm.rotation.x = -0.5; rightArm.rotation.x = -0.5;
    leftLeg.rotation.x = 0; rightLeg.rotation.x = 0;
    mesh.rotation.y = Math.sin(t * 4) * 0.3;
  } else if (anim === 'sit') {
    leftLeg.rotation.x = -1.5; rightLeg.rotation.x = -1.5;
    leftArm.rotation.x = -0.5; rightArm.rotation.x = -0.5;
  } else if (anim === 'sleep') {
    leftArm.rotation.x = -1.2; rightArm.rotation.x = -1.2;
    leftLeg.rotation.x = 0; rightLeg.rotation.x = 0;
  } else if (anim === 'point') {
    rightArm.rotation.x = -1.5; rightArm.rotation.z = 0;
    leftArm.rotation.x = 0;
  } else if (anim === 'laugh') {
    const s = Math.sin(t * 15);
    leftArm.rotation.x = -0.3 + s * 0.2;
    rightArm.rotation.x = -0.3 - s * 0.2;
  } else if (anim === 'throw') {
    // Animação de arremesso: braço direito vai para trás e lança para frente
    const throwStart = mesh.userData.throwAnim || 0;
    const throwT = (performance.now() - throwStart) / 1000;
    if (throwT < 0.6) {
      // Fase 1: vento (0 a 0.3s) — braço para trás e para cima
      if (throwT < 0.3) {
        const p = throwT / 0.3;
        rightArm.rotation.x = -0.5 - p * 1.5;     // vai para trás
        rightArm.rotation.z = -0.3 - p * 0.5;
        leftArm.rotation.x = 0.3 + p * 0.5;        // contrabalanço
      } else {
        // Fase 2: arremesso (0.3 a 0.6s) — braço vai para frente rápido
        const p = (throwT - 0.3) / 0.3;
        rightArm.rotation.x = -2.0 + p * 3.0;      // lança para frente
        rightArm.rotation.z = -0.8 + p * 0.8;
        leftArm.rotation.x = 0.8 - p * 0.5;
      }
      // Tronco acompanha
      const torso = mesh.getObjectByName('torso');
      if (torso) {
        torso.rotation.x = throwT < 0.3 ? -throwT * 0.3 : -(0.3 - (throwT - 0.3)) * 0.3;
      }
    } else {
      // Volta ao normal
      rightArm.rotation.x = 0;
      rightArm.rotation.z = -0.1;
      leftArm.rotation.x = 0;
      leftArm.rotation.z = 0.1;
      const torso = mesh.getObjectByName('torso');
      if (torso) torso.rotation.x = 0;
      mesh.userData.throwAnim = null;
    }
  } else {
    const breath = Math.sin(t * 2) * 0.05;
    leftArm.rotation.x = breath; rightArm.rotation.x = breath;
    leftLeg.rotation.x = 0; rightLeg.rotation.x = 0;
    leftArm.rotation.z = 0.1; rightArm.rotation.z = -0.1;
  }
}

function playEmote(mesh, emote) {
  if (!mesh) return;
  mesh.userData.emoteLock = true;
  mesh.userData.emote = emote;
  setTimeout(() => { mesh.userData.emoteLock = false; }, emote === 'dance' ? 5000 : emote === 'sleep' || emote === 'sit' ? 30000 : 3000);
}

function setRemoteWeapon(mesh, weaponId) {
  if (!mesh) return;
  const existing = mesh.getObjectByName('heldWeapon');
  if (existing) {
    mesh.remove(existing);
    if (existing.geometry) existing.geometry.dispose();
    if (existing.material) existing.material.dispose();
  }
  if (!weaponId) return;
  const rightArm = mesh.getObjectByName('rightArm');
  if (!rightArm) return;
  const wpn = buildWeaponMesh(weaponId);
  wpn.name = 'heldWeapon';
  wpn.position.set(0.1, -0.6, 0.1);
  rightArm.add(wpn);
}

function buildWeaponMesh(weaponId) {
  const group = new THREE.Group();
  const configs = {
    pistol:  { color: 0x222222, len: 0.3, w: 0.06, h: 0.15 },
    rifle:   { color: 0x3a2a1a, len: 0.7, w: 0.06, h: 0.12 },
    shotgun: { color: 0x5a3a1a, len: 0.7, w: 0.08, h: 0.14 },
    sniper:  { color: 0x1a1a2a, len: 0.9, w: 0.05, h: 0.1 },
    launcher:{ color: 0x4a4a4a, len: 0.7, w: 0.15, h: 0.18 }
  };
  const c = configs[weaponId] || configs.pistol;
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(c.w, c.h, c.len),
    new THREE.MeshLambertMaterial({ color: c.color })
  );
  body.position.z = -c.len / 2;
  group.add(body);
  const barrel = new THREE.Mesh(
    new THREE.CylinderGeometry(c.w * 0.3, c.w * 0.3, c.len * 0.7, 8),
    new THREE.MeshLambertMaterial({ color: 0x111111 })
  );
  barrel.rotation.x = Math.PI / 2;
  barrel.position.set(0, c.h * 0.3, -c.len * 0.6);
  group.add(barrel);
  return group;
}

function initPreview(canvas) {
  avatarPreviewScene = new THREE.Scene();
  avatarPreviewScene.background = new THREE.Color(0x1a2332);
  avatarPreviewCamera = new THREE.PerspectiveCamera(45, canvas.clientWidth / canvas.clientHeight, 0.1, 100);
  avatarPreviewCamera.position.set(0, 1.3, 3.5);
  avatarPreviewCamera.lookAt(0, 1.2, 0);
  avatarPreviewRenderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  avatarPreviewRenderer.setSize(canvas.clientWidth, canvas.clientHeight);
  avatarPreviewScene.add(new THREE.AmbientLight(0xffffff, 0.6));
  const dir = new THREE.DirectionalLight(0xffffff, 0.8);
  dir.position.set(2, 4, 3);
  avatarPreviewScene.add(dir);
  const ground = new THREE.Mesh(new THREE.CircleGeometry(2, 32), new THREE.MeshLambertMaterial({ color: 0x0d1117 }));
  ground.rotation.x = -Math.PI / 2;
  avatarPreviewScene.add(ground);
  avatarPreviewMesh = buildAvatarMesh(window.Save.getAvatar(), window.Save.getAccessories());
  avatarPreviewScene.add(avatarPreviewMesh);
}

function updatePreview(customization, accessories) {
  if (!avatarPreviewScene) return;
  if (avatarPreviewMesh) {
    avatarPreviewScene.remove(avatarPreviewMesh);
    disposeAvatar(avatarPreviewMesh);
  }
  avatarPreviewMesh = buildAvatarMesh(customization, accessories);
  avatarPreviewScene.add(avatarPreviewMesh);
}

function renderPreview(delta) {
  if (!avatarPreviewRenderer || !avatarPreviewMesh) return;
  avatarPreviewAnim += delta;
  avatarPreviewMesh.rotation.y = Math.sin(avatarPreviewAnim * 0.5) * 0.5;
  animateAvatar(avatarPreviewMesh, 'idle', avatarPreviewAnim, delta);
  avatarPreviewRenderer.render(avatarPreviewScene, avatarPreviewCamera);
}

function disposeAvatar(mesh) {
  if (!mesh) return;
  mesh.traverse(o => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      if (Array.isArray(o.material)) o.material.forEach(m => m.dispose());
      else o.material.dispose();
    }
  });
}

window.Avatar = {
  buildAvatarMesh, applyCustomization, createRemoteAvatar, updateRemoteInfo,
  setRemoteAnimation, animateAvatar, playEmote, setRemoteWeapon, buildWeaponMesh,
  initPreview, updatePreview, renderPreview, disposeAvatar,
  updateNameSprite, updateHealthBar,
  HAIR_STYLES, CLOTHES, SHOES, HATS, GLASSES, MASKS, BACKS, COLORS
};
})();
