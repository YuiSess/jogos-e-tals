// ============================================================
// weapon.js — Sistema de armas (FP)
// ============================================================
(function() {
'use strict';

const WEAPONS = {
  pistol:  { name: 'Pistola', icon: '🔫', damage: 18, fireRate: 0.18, magSize: 12, reserveAmmo: 60, reloadTime: 1.2, range: 80, spread: 0.01, pellets: 1, auto: false, recoil: 0.04 },
  rifle:   { name: 'Rifle',   icon: '🪖', damage: 14, fireRate: 0.1,  magSize: 30, reserveAmmo: 120, reloadTime: 2.0, range: 120, spread: 0.02, pellets: 1, auto: true,  recoil: 0.03 },
  shotgun: { name: 'Shotgun', icon: '💥', damage: 8,  fireRate: 0.7,  magSize: 6,  reserveAmmo: 30,  reloadTime: 2.5, range: 40,  spread: 0.08, pellets: 8, auto: false, recoil: 0.12 },
  sniper:  { name: 'Sniper',  icon: '🎯', damage: 80, fireRate: 1.2,  magSize: 5,  reserveAmmo: 25,  reloadTime: 2.8, range: 300, spread: 0.0,  pellets: 1, auto: false, recoil: 0.2 },
  launcher:{ name: 'Lança-Granada', icon: '🚀', damage: 100, fireRate: 1.5, magSize: 1, reserveAmmo: 8, reloadTime: 3.0, range: 100, spread: 0.0, pellets: 1, auto: false, recoil: 0.25, explosive: true },
  grenade: { name: 'Granada', icon: '💣', damage: 120, fireRate: 1.5, magSize: 3, reserveAmmo: 5, reloadTime: 1.0, range: 30, spread: 0.05, pellets: 1, auto: false, recoil: 0.1, throwable: true, explosive: true }
};

let currentSlot = 0;
let currentWeaponId = null;
let magAmmo = {};
let reserveAmmo = {};
let lastShot = 0;
let reloading = false;
let weaponMesh = null;
let firstPersonWeapon = null;
let scene = null;
let camera = null;
let projectileList = [];
let recoilOffset = 0;

function WeaponInit(scn, cam) {
  scene = scn; camera = cam;
  for (const id in WEAPONS) {
    magAmmo[id] = WEAPONS[id].magSize;
    reserveAmmo[id] = WEAPONS[id].reserveAmmo;
  }
  const inv = window.Save.getInventory();
  if (inv.equipped.weapon1) {
    currentSlot = 0;
    currentWeaponId = inv.equipped.weapon1;
  }
  equipWeapon(currentWeaponId);
  updateHUD();
}

function selectSlot(slot) {
  const inv = window.Save.getInventory();
  const slots = [inv.equipped.weapon1, inv.equipped.weapon2, inv.equipped.weapon3];
  const newId = slots[slot];
  if (!newId) return;
  currentSlot = slot;
  equipWeapon(newId);
}

function equipWeapon(weaponId) {
  if (!WEAPONS[weaponId]) return;
  if (firstPersonWeapon) {
    camera.remove(firstPersonWeapon);
    if (firstPersonWeapon.geometry) firstPersonWeapon.geometry.dispose();
    if (firstPersonWeapon.material) firstPersonWeapon.material.dispose();
    firstPersonWeapon = null;
  }
  if (window.Player) {
    const pm = window.Player.getPlayerMesh();
    if (pm) {
      const existing = pm.getObjectByName('heldWeapon');
      if (existing) {
        existing.parent.remove(existing);
        if (existing.geometry) existing.geometry.dispose();
        if (existing.material) existing.material.dispose();
      }
    }
  }
  if (weaponMesh) {
    if (weaponMesh.parent) weaponMesh.parent.remove(weaponMesh);
    if (weaponMesh.geometry) weaponMesh.geometry.dispose();
    if (weaponMesh.material) weaponMesh.material.dispose();
    weaponMesh = null;
  }
  currentWeaponId = weaponId;
  reloading = false;

  if (window.Player && !window.Player.isFP()) {
    const pm = window.Player.getPlayerMesh();
    if (pm) {
      const rightArm = pm.getObjectByName('rightArm');
      if (rightArm && window.Avatar) {
        const wpn = window.Avatar.buildWeaponMesh(weaponId);
        wpn.name = 'heldWeapon';
        wpn.position.set(0.1, -0.6, 0.1);
        rightArm.add(wpn);
      }
    }
  } else {
    firstPersonWeapon = window.Avatar.buildWeaponMesh(weaponId);
    firstPersonWeapon.position.set(0.25, -0.25, -0.5);
    firstPersonWeapon.rotation.y = Math.PI;
    firstPersonWeapon.scale.set(0.8, 0.8, 0.8);
    camera.add(firstPersonWeapon);
  }

  if (window.Network) {
    window.Network.broadcast({ type: 'equip', id: window.PeerAPI.getMyId(), weapon: weaponId });
  }
  updateHUD();
}

function shoot() {
  if (!currentWeaponId) return;
  const cfg = WEAPONS[currentWeaponId];
  const now = performance.now() / 1000;
  if (now - lastShot < cfg.fireRate) return;
  if (reloading) return;
  if (magAmmo[currentWeaponId] <= 0) { reload(); return; }
  lastShot = now;
  magAmmo[currentWeaponId]--;

  if (cfg.throwable) {
    throwGrenade(cfg);
  } else {
    const camPos = window.Player.getCameraPosition();
    const camDir = window.Player.getCameraDirection().clone();
    for (let i = 0; i < cfg.pellets; i++) {
      const dir = camDir.clone();
      dir.x += (Math.random() - 0.5) * cfg.spread;
      dir.y += (Math.random() - 0.5) * cfg.spread;
      dir.z += (Math.random() - 0.5) * cfg.spread;
      dir.normalize();
      fireBullet(camPos, dir, cfg);
    }
    const muzzlePos = camPos.clone().add(camDir.clone().multiplyScalar(0.5));
    if (window.Effects) window.Effects.createMuzzleFlash(muzzlePos.x, muzzlePos.y, muzzlePos.z, camDir.x, camDir.y, camDir.z);
    // Recoil (adiciona pitch)
    recoilOffset += cfg.recoil;
    if (window.Audio && window.Audio.playShot) window.Audio.playShot(currentWeaponId);
  }

  if (window.Network) {
    const camPos = window.Player.getCameraPosition();
    const camDir = window.Player.getCameraDirection();
    window.Network.broadcast({
      type: 'shoot',
      id: window.PeerAPI.getMyId(),
      ox: camPos.x, oy: camPos.y, oz: camPos.z,
      dx: camDir.x, dy: camDir.y, dz: camDir.z,
      weapon: currentWeaponId
    });
  }
  updateHUD();
}

function fireBullet(from, dir, cfg) {
  const to = from.clone().add(dir.clone().multiplyScalar(cfg.range));
  const hit = window.Physics.raycast(from, to);
  if (hit && hit.hasHit) {
    const hitPoint = new THREE.Vector3(hit.hitPoint.x, hit.hitPoint.y, hit.hitPoint.z);
    const hitNormal = new THREE.Vector3(hit.hitNormalWorld.x, hit.hitNormalWorld.y, hit.hitNormalWorld.z);
    let hitPlayer = null;
    if (window.Network) {
      const remote = window.Network.getRemotePlayers();
      for (const [id, rp] of remote) {
        if (!rp.mesh) continue;
        const dist = rp.mesh.position.distanceTo(hitPoint);
        if (dist < 0.8) { hitPlayer = rp; break; }
      }
    }
    if (hitPlayer) {
      if (window.Network) {
        window.Network.sendTo(hitPlayer.peerId, {
          type: 'hit', shooter: window.PeerAPI.getMyId(),
          target: hitPlayer.peerId, damage: cfg.damage
        });
      }
      if (window.Effects) {
        window.Effects.createBlood(hitPoint.x, hitPoint.y, hitPoint.z, dir);
        window.Effects.createHitMarker(hitPoint);
      }
    } else {
      if (window.Effects) window.Effects.createImpact(hitPoint.x, hitPoint.y, hitPoint.z, hitNormal.x, hitNormal.y, hitNormal.z);
    }
    if (window.Effects) window.Effects.createBulletTrail(from, hitPoint);
  } else {
    if (window.Effects) window.Effects.createBulletTrail(from, to);
  }
}

function throwGrenade(cfg) {
  const camPos = window.Player.getCameraPosition();
  const camDir = window.Player.getCameraDirection();
  const start = camPos.clone().add(camDir.clone().multiplyScalar(0.8));
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.12, 12, 12),
    new THREE.MeshLambertMaterial({ color: 0x336633 })
  );
  mesh.position.copy(start);
  scene.add(mesh);
  const vel = camDir.clone().multiplyScalar(25);
  vel.y += 5;
  projectileList.push({ mesh, vel, life: 3.0, damage: cfg.damage, explosive: true, pos: start.clone(), radius: 5 });
}

function reload() {
  if (!currentWeaponId || reloading) return;
  const cfg = WEAPONS[currentWeaponId];
  if (magAmmo[currentWeaponId] >= cfg.magSize) return;
  if (reserveAmmo[currentWeaponId] <= 0) return;
  reloading = true;
  if (window.UI) window.UI.addNotification('Recarregando...', 'info');
  if (window.Audio && window.Audio.playReload) window.Audio.playReload(currentWeaponId);
  setTimeout(() => {
    const needed = cfg.magSize - magAmmo[currentWeaponId];
    const taken = Math.min(needed, reserveAmmo[currentWeaponId]);
    magAmmo[currentWeaponId] += taken;
    reserveAmmo[currentWeaponId] -= taken;
    reloading = false;
    updateHUD();
  }, cfg.reloadTime * 1000);
}

function WeaponUpdate(delta) {
  // Recoil recuperação
  recoilOffset *= 0.85;
  // Projéteis
  for (let i = projectileList.length - 1; i >= 0; i--) {
    const p = projectileList[i];
    p.life -= delta;
    p.vel.y -= 18 * delta;
    p.pos.x += p.vel.x * delta;
    p.pos.y += p.vel.y * delta;
    p.pos.z += p.vel.z * delta;
    if (p.pos.y < 0.1) {
      p.pos.y = 0.1;
      p.vel.y *= -0.4;
      p.vel.x *= 0.7;
      p.vel.z *= 0.7;
    }
    p.mesh.position.copy(p.pos);
    if (p.life <= 0) {
      if (window.Effects) window.Effects.createExplosion(p.pos.x, p.pos.y, p.pos.z, p.radius);
      if (window.Network) {
        const remote = window.Network.getRemotePlayers();
        for (const [id, rp] of remote) {
          if (!rp.mesh) continue;
          const d = rp.mesh.position.distanceTo(p.pos);
          if (d < p.radius) {
            const dmg = p.damage * (1 - d / p.radius);
            window.Network.sendTo(id, { type: 'hit', shooter: window.PeerAPI.getMyId(), target: id, damage: Math.round(dmg) });
          }
        }
      }
      const playerPos = window.Player.getPosition();
      const d = playerPos.distanceTo(p.pos);
      if (d < p.radius) {
        const dmg = p.damage * (1 - d / p.radius) * 0.5;
        window.Player.takeDamage(Math.round(dmg), 'grenade');
      }
      scene.remove(p.mesh);
      p.mesh.geometry.dispose();
      p.mesh.material.dispose();
      projectileList.splice(i, 1);
    }
  }
}

function receiveRemoteShot(data) {
  const from = new THREE.Vector3(data.ox, data.oy, data.oz);
  const dir = new THREE.Vector3(data.dx, data.dy, data.dz);
  const cfg = WEAPONS[data.weapon] || WEAPONS.pistol;
  const to = from.clone().add(dir.clone().multiplyScalar(cfg.range));
  if (window.Effects) window.Effects.createBulletTrail(from, to);
}

function getCurrentWeaponId() { return currentWeaponId; }
function getCurrentWeaponCfg() { return WEAPONS[currentWeaponId]; }
function isReloading() { return reloading; }
function getFirstPersonWeapon() { return firstPersonWeapon; }

function updateHUD() {
  if (!window.UI) return;
  const cfg = WEAPONS[currentWeaponId] || { name: '--' };
  window.UI.updateAmmo(magAmmo[currentWeaponId] || 0, reserveAmmo[currentWeaponId] || 0, cfg.name);
  window.UI.updateWeaponsList();
}

function giveAmmo(weaponId, amount) {
  if (!WEAPONS[weaponId]) return;
  reserveAmmo[weaponId] = (reserveAmmo[weaponId] || 0) + amount;
  updateHUD();
}

window.Weapon = {
  init: WeaponInit,
  update: WeaponUpdate,
  shoot, reload, selectSlot, equipWeapon,
  receiveRemoteShot,
  getCurrentWeaponId, getCurrentWeaponCfg, isReloading,
  getFirstPersonWeapon, giveAmmo,
  WEAPONS
};
})();
