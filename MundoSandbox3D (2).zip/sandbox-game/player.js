// ============================================================
// player.js — Controle do jogador (PRIMEIRA PESSOA por padrão)
// ============================================================
(function() {
'use strict';

let camera = null;
let scene = null;
let playerBody = null;
let playerMesh = null;
let yaw = 0;
let pitch = 0;
let isJumping = false;
let isGrounded = true;
let isCrouching = false;
let isSprinting = false;
let isSwimming = false;
let isClimbing = false;
let health = 100;
let currentAnim = 'idle';
let fpMode = true;        // PRIMEIRA PESSOA POR PADRÃO
let sensitivity = 1;
let fov = 75;
let cameraDistance = 4;
let pointerLocked = false;
let keys = {};
let waterLevel = -1000;
let climbObjects = [];
let interactables = [];
let respawnPoint = new THREE.Vector3(0, 3, 0);
let damageCooldown = 0;
let emoteLock = false;
let currentEmote = null;
let bobTimer = 0;
let weaponSway = { x: 0, y: 0 };
let velocityY = 0;

function PlayerInit(scn, cam) {
  scene = scn;
  camera = cam;
  const settings = window.Save ? window.Save.getSettings() : {};
  sensitivity = settings.sensitivity || 1;
  fov = settings.fov || 75;
  fpMode = settings.fpMode !== undefined ? settings.fpMode : true;  // default true
  camera.fov = fov;
  camera.updateProjectionMatrix();

  playerBody = window.Physics.createPlayerBody([respawnPoint.x, respawnPoint.y, respawnPoint.z]);

  // Avatar local (invisível em FP)
  playerMesh = window.Avatar.buildAvatarMesh(window.Save.getAvatar(), window.Save.getAccessories());
  scene.add(playerMesh);
  playerMesh.visible = !fpMode;

  setupInput();
  setupPointerLock();
}

function setupInput() {
  window.addEventListener('keydown', (e) => {
    if (document.activeElement && document.activeElement.tagName === 'INPUT') return;
    keys[e.code] = true;
    if (e.code === 'Space') isJumping = true;
    if (e.code === 'ControlLeft' || e.code === 'KeyC') isCrouching = true;
    if (e.code === 'ShiftLeft') isSprinting = true;
    if (e.code === 'KeyV') toggleCameraMode();
    if (e.code === 'KeyR') {
      if (!(window.Builder && window.Builder.isActive()) && window.Weapon) window.Weapon.reload();
    }
    if (e.code === 'KeyB') { if (window.Builder) window.Builder.toggle(); }
    if (e.code === 'KeyN') {
      if (window.Loader) {
        const t = window.Loader.toggleDayNight();
        if (window.UI) window.UI.addNotification(`Hora: ${t < 0.25 ? 'Madrugada' : t < 0.5 ? 'Manhã' : t < 0.75 ? 'Tarde' : 'Noite'}`, 'info');
      }
    }
    if (e.code === 'KeyM') {
      if (window.Loader) {
        const w = window.Loader.toggleWeather();
        if (window.UI) window.UI.addNotification(`Clima: ${w === 'clear' ? 'Limpo ☀️' : w === 'rain' ? 'Chuva 🌧️' : w === 'snow' ? 'Neve ❄️' : 'Folhas 🍂'}`, 'info');
      }
    }
    if (e.code === 'KeyG') {
      if (window.VoiceChat) {
        const enabled = window.VoiceChat.toggle();
        const btn = document.getElementById('btnVoiceChat');
        if (btn) btn.classList.toggle('active', enabled);
        const indicator = document.getElementById('voiceIndicator');
        if (indicator) indicator.classList.toggle('hidden', !enabled);
      }
    }
    if (e.code === 'KeyH') {
      if (window.VoiceChat) {
        const muted = window.VoiceChat.toggleMute();
        const btn = document.getElementById('btnMuteMic');
        if (btn) btn.textContent = muted ? '🔇' : '🔊';
      }
    }
    if (e.code === 'KeyQ') {
      // No modo queimada/futebol, Q pega a bola
      if (window.GameMode) {
        if (window.GameMode.getMode() === 'queimada' || window.GameMode.getMode() === 'futebol') {
          window.GameMode.tryCatchBall();
        }
      }
    }
    if (e.code === 'KeyE') {
      // Interação contextual (pegar bandeira no CTF)
      if (window.GameMode && window.GameMode.getMode() === 'ctf') {
        window.GameMode.tryCatchBall();  // reusar para pegar bandeira
      }
    }
    if (e.code === 'Tab') {
      e.preventDefault();
      if (window.UI) window.UI.toggleInventory();
    }
    if (e.code === 'Enter') { if (window.Chat) window.Chat.toggle(); }
    if (e.code === 'Digit1') if (window.Weapon) window.Weapon.selectSlot(0);
    if (e.code === 'Digit2') if (window.Weapon) window.Weapon.selectSlot(1);
    if (e.code === 'Digit3') if (window.Weapon) window.Weapon.selectSlot(2);
  });
  window.addEventListener('keyup', (e) => {
    keys[e.code] = false;
    if (e.code === 'Space') isJumping = false;
    if (e.code === 'ControlLeft' || e.code === 'KeyC') isCrouching = false;
    if (e.code === 'ShiftLeft') isSprinting = false;
  });
  window.addEventListener('mousedown', (e) => {
    if (!pointerLocked) return;
    if (e.button === 0) {
      // Modos de jogo têm prioridade sobre atirar
      if (window.GameMode) {
        const mode = window.GameMode.getMode();
        if (mode === 'queimada' || mode === 'futebol') {
          if (window.GameMode.throwBall()) return;
        }
      }
      if (window.Builder && window.Builder.isActive()) window.Builder.placeBlock();
      else if (window.Weapon) window.Weapon.shoot();
    } else if (e.button === 2) {
      if (window.Builder && window.Builder.isActive()) window.Builder.deleteBlock();
    }
  });
  window.addEventListener('contextmenu', (e) => e.preventDefault());
}

function setupPointerLock() {
  const canvas = document.getElementById('gameCanvas');
  canvas.addEventListener('click', () => {
    if (!pointerLocked && window.GameState && window.GameState.inGame) {
      canvas.requestPointerLock();
      if (window.Audio) window.Audio.resume();
    }
  });
  document.addEventListener('pointerlockchange', () => {
    pointerLocked = document.pointerLockElement === canvas;
  });
  document.addEventListener('mousemove', (e) => {
    if (!pointerLocked) return;
    yaw -= e.movementX * 0.002 * sensitivity;
    pitch -= e.movementY * 0.002 * sensitivity;
    pitch = Math.max(-Math.PI / 2 + 0.1, Math.min(Math.PI / 2 - 0.1, pitch));
    // Weapon sway baseado no movimento do mouse
    weaponSway.x += e.movementX * 0.0001;
    weaponSway.y += e.movementY * 0.0001;
  });
}

function toggleCameraMode() {
  fpMode = !fpMode;
  if (playerMesh) playerMesh.visible = !fpMode;
  if (window.Weapon && window.Weapon.getCurrentWeaponId()) {
    window.Weapon.equipWeapon(window.Weapon.getCurrentWeaponId());
  }
  if (window.UI) window.UI.addNotification(fpMode ? 'Câmera: 1ª pessoa' : 'Câmera: 3ª pessoa', 'info');
}

function PlayerUpdate(delta) {
  if (!playerBody) return;

  const pos = playerBody.position;

  // === Escalada ===
  isClimbing = false;
  for (const obj of climbObjects) {
    if (obj.position.distanceTo(new THREE.Vector3(pos.x, pos.y, pos.z)) < (obj.userData.climbRadius || 1.5)) {
      isClimbing = true;
      break;
    }
  }

  // === Natação ===
  isSwimming = pos.y < waterLevel;

  // === Movimento ===
  const speed = isCrouching ? 2.5 : isSprinting ? 9 : isSwimming ? 4 : 5;
  const sinY = Math.sin(yaw), cosY = Math.cos(yaw);

  let moveX = 0, moveZ = 0;
  if (keys['KeyW']) { moveX -= sinY; moveZ -= cosY; }
  if (keys['KeyS']) { moveX += sinY; moveZ += cosY; }
  if (keys['KeyA']) { moveX -= cosY; moveZ += sinY; }
  if (keys['KeyD']) { moveX += cosY; moveZ -= sinY; }

  const len = Math.hypot(moveX, moveZ);
  if (len > 0) {
    moveX = (moveX / len) * speed;
    moveZ = (moveZ / len) * speed;
  }

  if (isClimbing) {
    if (keys['KeyW']) playerBody.position.y += 3 * delta;
    else if (keys['KeyS']) playerBody.position.y -= 3 * delta;
  } else if (isSwimming) {
    if (keys['Space']) playerBody.position.y += 3 * delta;
    else if (keys['ControlLeft'] || keys['KeyC']) playerBody.position.y -= 3 * delta;
  } else {
    // Gravidade manual (body é kinematic)
    if (!isGrounded) {
      // Aplica gravidade acumulando velocidade Y
      velocityY = (velocityY || 0) - 22 * delta;
    } else {
      velocityY = 0;
    }
    if (isJumping && isGrounded) {
      velocityY = 9;
      isGrounded = false;
    }
    playerBody.position.y += velocityY * delta;
  }

  // Move o body MANUALMENTE (horizontal)
  // Usa delta sem limite para garantir velocidade constante mesmo com FPS baixo
  if (len > 0) {
    const moveSpeed = isClimbing ? 0.5 : 1.0;
    const moveDelta = Math.min(delta, 0.1);  // limita para evitar teleporte
    playerBody.position.x += moveX * moveDelta * moveSpeed;
    playerBody.position.z += moveZ * moveDelta * moveSpeed;
  }

  // Acorda o body caso esteja dormindo (cannon.js)
  if (playerBody.wakeUp) playerBody.wakeUp();

  // Ground check — raycast do centro do body para baixo
  const from = new CANNON.Vec3(pos.x, pos.y, pos.z);
  const to = new CANNON.Vec3(pos.x, pos.y - 1.0, pos.z);
  const result = new CANNON.RaycastResult();
  window.Physics.getWorld().raycastClosest(from, to, { skipBackfaces: true }, result);
  isGrounded = result.hasHit;

  // Se está caindo e bateu no chão, para de cair
  if (isGrounded && velocityY < 0) {
    // Ajusta posição para não afundar
    if (result.hasHit && result.hitPoint) {
      const groundY = result.hitPoint.y;
      // Base do body = pos.y - 0.8 (half-height)
      // Queremos base do body = groundY, então pos.y = groundY + 0.8
      const targetY = groundY + 0.8;
      if (pos.y < targetY) {
        playerBody.position.y = targetY;
      }
    }
    velocityY = 0;
  }

  // === Avatar (atualiza mesh mesmo em FP para sincronizar com rede) ===
  if (playerMesh) {
    // O mesh do avatar tem ~1.8 de altura, base em y=0
    // O body é uma caixa de 1.6 de altura, centro em pos.y
    // Offset: pos.y - 0.8 (base do body) = base do avatar
    playerMesh.position.set(pos.x, pos.y - 0.8, pos.z);
    playerMesh.rotation.y = yaw + Math.PI;
    let anim = 'idle';
    if (isClimbing) anim = 'climb';
    else if (isSwimming) anim = 'swim';
    else if (!isGrounded) anim = 'jump';
    else if (isCrouching) anim = len > 0 ? 'crouch' : 'idle';
    else if (len > 0) anim = isSprinting ? 'run' : 'walk';
    if (emoteLock) anim = currentEmote;
    // Animação de arremesso tem prioridade
    if (playerMesh.userData.throwAnim) anim = 'throw';
    currentAnim = anim;
    window.Avatar.animateAvatar(playerMesh, anim, performance.now() / 1000, delta);
  }

  // === Câmera (PRIMEIRA PESSOA) ===
  // Head bob e weapon sway
  const isMoving = len > 0 && isGrounded;
  if (isMoving) {
    bobTimer += delta * (isSprinting ? 14 : 8);
  } else {
    bobTimer *= 0.9;
  }
  const bobY = isMoving ? Math.sin(bobTimer) * 0.04 : 0;
  const bobX = isMoving ? Math.cos(bobTimer * 0.5) * 0.03 : 0;

  if (fpMode) {
    // Câmera na altura da cabeça (centro do body + offset)
    camera.position.set(pos.x + bobX, pos.y + 0.7 + bobY, pos.z);
    const euler = new THREE.Euler(pitch, yaw, 0, 'YXZ');
    camera.quaternion.setFromEuler(euler);
    // Aplica sway na arma em 1a pessoa
    if (window.Weapon && window.Weapon.getFirstPersonWeapon) {
      const wpn = window.Weapon.getFirstPersonWeapon();
      if (wpn) {
        weaponSway.x *= 0.9;
        weaponSway.y *= 0.9;
        wpn.position.x = 0.3 - weaponSway.x * 5;
        wpn.position.y = -0.25 - weaponSway.y * 5 + bobY * 0.5;
        wpn.position.z = -0.6;
      }
    }
  } else {
    const targetPos = new THREE.Vector3(pos.x, pos.y + (isCrouching ? 0.8 : 1.2), pos.z);
    const offset = new THREE.Vector3(
      Math.sin(yaw) * Math.cos(pitch) * cameraDistance,
      Math.sin(pitch) * cameraDistance + 0.5,
      Math.cos(yaw) * Math.cos(pitch) * cameraDistance
    );
    camera.position.set(targetPos.x + offset.x, targetPos.y - offset.y + cameraDistance * 0.5, targetPos.z + offset.z);
    camera.lookAt(targetPos.x, targetPos.y + 0.3, targetPos.z);
  }

  // === Dano por queda ===
  if (pos.y < -30) {
    takeDamage(100, 'void');
    respawn();
  }
  if (damageCooldown > 0) damageCooldown -= delta;
}

function getHealth() { return health; }

function takeDamage(amount, source) {
  if (damageCooldown > 0 && amount < 50) return;
  health -= amount;
  damageCooldown = 0.5;
  if (window.UI) window.UI.updateHealth(health);
  if (window.UI) window.UI.flashDamage();
  if (health <= 0) {
    health = 0;
    die(source);
  }
}

function heal(amount) {
  health = Math.min(100, health + amount);
  if (window.UI) window.UI.updateHealth(health);
}

function die(source) {
  if (window.UI) window.UI.addNotification(`Você morreu (${source || 'desconhecido'})`, 'error');
  if (window.Chat) window.Chat.addSystem(`Você morreu.`);
  setTimeout(() => respawn(), 1500);
}

function respawn() {
  health = 100;
  if (playerBody) {
    playerBody.position.set(respawnPoint.x, respawnPoint.y, respawnPoint.z);
    playerBody.velocity.set(0, 0, 0);
  }
  if (window.UI) window.UI.updateHealth(100);
}

function setRespawnPoint(v) { respawnPoint.copy(v); }
function setWaterLevel(y) { waterLevel = y; }
function addClimbable(mesh, radius) { mesh.userData.climbRadius = radius || 1.5; climbObjects.push(mesh); }
function addInteractable(mesh, action, label) { interactables.push({ mesh, action, label }); }

function getNetworkState() {
  if (!playerBody) return { x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0, anim: 'idle', weapon: null, health: 100, state: 'alive' };
  return {
    x: playerBody.position.x, y: playerBody.position.y, z: playerBody.position.z,
    rx: pitch, ry: yaw, rz: 0,
    anim: currentAnim,
    weapon: window.Weapon ? window.Weapon.getCurrentWeaponId() : null,
    health: health,
    state: health > 0 ? 'alive' : 'dead'
  };
}

function getPosition() {
  if (!playerBody) return new THREE.Vector3();
  return new THREE.Vector3(playerBody.position.x, playerBody.position.y, playerBody.position.z);
}

function getCameraDirection() {
  const dir = new THREE.Vector3();
  camera.getWorldDirection(dir);
  return dir;
}

function getCameraPosition() { return camera.position.clone(); }

function playEmoteLocal(emote) {
  emoteLock = true;
  currentEmote = emote;
  const durations = { wave: 3000, dance: 5000, sit: 30000, point: 2000, laugh: 3000, sleep: 30000 };
  setTimeout(() => { emoteLock = false; }, durations[emote] || 3000);
  if (window.Network) {
    window.Network.broadcast({ type: 'emote', id: window.PeerAPI.getMyId(), emote: emote });
  }
}

function resetPlayer() {
  if (playerBody && window.Physics) window.Physics.getWorld().removeBody(playerBody);
  if (playerMesh && playerMesh.parent) playerMesh.parent.remove(playerMesh);
  if (window.Avatar) window.Avatar.disposeAvatar(playerMesh);
  playerBody = null; playerMesh = null;
  climbObjects = []; interactables = [];
  health = 100;
}

window.Player = {
  init: PlayerInit,
  update: PlayerUpdate,
  getHealth, takeDamage, heal, respawn,
  setRespawnPoint, setWaterLevel, addClimbable, addInteractable,
  getNetworkState, getPosition, getCameraDirection, getCameraPosition,
  getPlayerMesh: () => playerMesh,
  playEmote: playEmoteLocal,
  reset: resetPlayer,
  toggleCameraMode,
  isFP: () => fpMode,
  getYaw: () => yaw,
  getPitch: () => pitch,
  isGrounded: () => isGrounded
};
})();
