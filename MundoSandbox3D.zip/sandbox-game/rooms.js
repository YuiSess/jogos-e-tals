// ============================================================
// rooms.js — Sistema de descoberta de salas abertas
// Usa PeerJS para descobrir salas (cada host registra sua sala
// num Peer fixo que atua como "tracker" de salas)
// ============================================================
(function() {
'use strict';

let roomsList = [];
let trackerPeer = null;
let trackerConn = null;
let myRoom = null;
let trackerId = 'sandbox3d-tracker-v1';
let isTracker = false;
let trackerCallbacks = { onRoomsUpdate: null };

// ===== Init — conecta ao tracker =====
function RoomsInit(callbacks) {
  trackerCallbacks = callbacks || {};
  // Tenta conectar ao tracker (qualquer cliente pode ser o tracker)
  setTimeout(() => connectToTracker(), 2000);
}

// ===== Conecta ao tracker =====
function connectToTracker() {
  if (!window.PeerAPI || !window.PeerAPI.getMyId()) {
    setTimeout(connectToTracker, 2000);
    return;
  }
  // Cria um peer específico para o tracker
  trackerPeer = new Peer(trackerId, {
    config: {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    },
    debug: 0
  });

  trackerPeer.on('open', (id) => {
    // Sou o tracker (consegui o ID fixo)
    console.log('[ROOMS] ✅ Sou o tracker de salas');
    isTracker = true;
    roomsList = [];
    trackerPeer.on('connection', (conn) => {
      conn.on('open', () => {
        conn.on('data', (data) => {
          handleTrackerMessage(conn, data);
        });
        conn.on('close', () => {
          // Remove salas deste peer
          roomsList = roomsList.filter(r => r.peerId !== conn.peer);
          broadcastRoomsList();
        });
      });
    });
  });

  trackerPeer.on('error', (err) => {
    // O tracker já existe — conecta como cliente
    if (err.type === 'unavailable-id') {
      console.log('[ROOMS] Tracker já existe — conectando como cliente');
      isTracker = false;
      try { trackerPeer.destroy(); } catch(e){}
      trackerPeer = new Peer({
        config: {
          iceServers: [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' }
          ]
        },
        debug: 0
      });
      trackerPeer.on('open', (id) => {
        trackerConn = trackerPeer.connect(trackerId, { reliable: true });
        trackerConn.on('open', () => {
          console.log('[ROOMS] ✅ Conectado ao tracker');
          trackerConn.on('data', (data) => {
            if (data.type === 'rooms_list' && trackerCallbacks.onRoomsUpdate) {
              roomsList = data.rooms || [];
              trackerCallbacks.onRoomsUpdate(roomsList);
            }
          });
          // Pede lista de salas
          trackerConn.send({ type: 'get_rooms' });
          // Atualiza lista a cada 5s
          setInterval(() => {
            if (trackerConn && trackerConn.open) trackerConn.send({ type: 'get_rooms' });
          }, 5000);
        });
        trackerConn.on('close', () => {
          console.log('[ROOMS] Conexão com tracker perdida');
          // Tenta virar tracker
          setTimeout(connectToTracker, 3000);
        });
      });
    } else {
      console.warn('[ROOMS] Erro:', err.type);
    }
  });
}

// ===== Host registra sua sala no tracker =====
function registerRoom(roomData) {
  myRoom = roomData;
  myRoom.peerId = window.PeerAPI.getMyId();
  myRoom.createdAt = Date.now();
  if (trackerConn && trackerConn.open) {
    trackerConn.send({ type: 'register_room', room: myRoom });
    console.log('[ROOMS] Sala registrada:', myRoom.name);
  } else if (isTracker) {
    // Sou tracker e host — adiciona direto
    roomsList = roomsList.filter(r => r.peerId !== myRoom.peerId);
    roomsList.push(myRoom);
    broadcastRoomsList();
  }
}

// ===== Remove sala do tracker (host fecha) =====
function unregisterRoom() {
  if (trackerConn && trackerConn.open && myRoom) {
    trackerConn.send({ type: 'unregister_room', peerId: myRoom.peerId });
  } else if (isTracker && myRoom) {
    roomsList = roomsList.filter(r => r.peerId !== myRoom.peerId);
    broadcastRoomsList();
  }
  myRoom = null;
}

// ===== Tracker recebe mensagem =====
function handleTrackerMessage(conn, data) {
  if (data.type === 'register_room') {
    // Adiciona/atualiza sala
    roomsList = roomsList.filter(r => r.peerId !== data.room.peerId);
    roomsList.push(data.room);
    broadcastRoomsList();
  } else if (data.type === 'unregister_room') {
    roomsList = roomsList.filter(r => r.peerId !== data.peerId);
    broadcastRoomsList();
  } else if (data.type === 'get_rooms') {
    // Envia lista atual
    conn.send({ type: 'rooms_list', rooms: roomsList });
  }
}

// ===== Tracker envia lista para todos =====
function broadcastRoomsList() {
  if (!isTracker || !trackerPeer) return;
  // trackerPeer.connections é um objeto {peerId: [conn, ...]
  if (trackerPeer.connections) {
    for (const key in trackerPeer.connections) {
      const conns = trackerPeer.connections[key];
      const arr = Array.isArray(conns) ? conns : [conns];
      for (const c of arr) {
        if (c.open) {
          c.send({ type: 'rooms_list', rooms: roomsList });
        }
      }
    }
  }
  if (trackerCallbacks.onRoomsUpdate) {
    trackerCallbacks.onRoomsUpdate(roomsList);
  }
}

// ===== Lista salas locais =====
function getRooms() {
  return roomsList;
}

// ===== Conectar a uma sala (entra direto) =====
function joinRoom(peerId, playerName) {
  if (window.Save) window.Save.setPlayerName(playerName || 'Jogador');
  if (window.Network) {
    window.Network.init({
      onOpen: (id, isHost) => {
        window.Network.connect(peerId);
      }
    });
    setTimeout(() => {
      const map = (window.GameState && window.GameState.map) || 'lobby';
      const roomName = (window.GameState && window.GameState.roomName) || 'Sala';
      const gameMode = (window.GameState && window.GameState.gameMode) || 'free';
      if (window.Game) window.Game.start({ mode: 'client', map, roomName, hostId: peerId, gameMode });
    }, 3000);
  }
}

window.Rooms = {
  init: RoomsInit,
  registerRoom,
  unregisterRoom,
  getRooms,
  joinRoom
};
})();
