// ============================================================
// voice-chat.js — Chat de voz via WebRTC (getUserMedia)
// ============================================================
(function() {
'use strict';

let localStream = null;
let audioContext = null;
let analyser = null;
let peers = new Map();  // peerId -> { connection, audio, gain, analyser }
let enabled = false;
let muted = false;
let micVolume = 0.8;
let peerConnections = new Map();  // peerId -> RTCPeerConnection
let isHost = false;

function VoiceChatInit() {
  // Configura mic + listeners quando PeerJS conecta
  console.log('[VOICE] Voice chat ready');
}

async function startMic() {
  try {
    localStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      },
      video: false
    });
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const source = audioContext.createMediaStreamSource(localStream);
    analyser = audioContext.createAnalyser();
    analyser.fftSize = 256;
    source.connect(analyser);
    enabled = true;
    console.log('[VOICE] ✅ Microfone ativo');
    if (window.UI) window.UI.addNotification('🎤 Chat de voz ativado', 'success');
    return true;
  } catch (err) {
    console.warn('[VOICE] Erro ao acessar microfone:', err);
    if (window.UI) window.UI.addNotification('❌ Erro ao ativar microfone: ' + err.message, 'error');
    return false;
  }
}

function stopMic() {
  if (localStream) {
    localStream.getTracks().forEach(t => t.stop());
    localStream = null;
  }
  if (audioContext) {
    audioContext.close();
    audioContext = null;
  }
  analyser = null;
  enabled = false;
  // Fecha todas conexões
  for (const [id, pc] of peerConnections) {
    try { pc.close(); } catch(e){}
  }
  peerConnections.clear();
  peers.clear();
  if (window.UI) window.UI.addNotification('🔇 Chat de voz desativado', 'info');
}

function toggle() {
  if (enabled) stopMic();
  else startMic();
  return enabled;
}

function toggleMute() {
  muted = !muted;
  if (localStream) {
    localStream.getAudioTracks().forEach(t => t.enabled = !muted);
  }
  if (window.UI) window.UI.addNotification(muted ? '🔇 Microfone mutado' : '🎤 Microfone ativo', 'info');
  return muted;
}

// Cria conexão WebRTC com um peer para chat de voz
async function createVoiceConnection(peerId) {
  if (!enabled || !localStream) return;
  if (peerConnections.has(peerId)) return;

  const pc = new RTCPeerConnection({
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' }
    ]
  });
  peerConnections.set(peerId, pc);

  // Adiciona o áudio local
  localStream.getTracks().forEach(track => {
    pc.addTrack(track, localStream);
  });

  // Recebe áudio remoto
  pc.ontrack = (event) => {
    const audio = new Audio();
    audio.srcObject = event.streams[0];
    audio.volume = micVolume;
    audio.play().catch(e => console.warn('[VOICE] Audio play error:', e));
    peers.set(peerId, { audio });
    console.log('[VOICE] 🎧 Recebendo áudio de', peerId);
  };

  // ICE candidates — envia via PeerJS data channel
  pc.onicecandidate = (event) => {
    if (event.candidate && window.PeerAPI) {
      window.PeerAPI.sendTo(peerId, {
        type: 'voice_ice',
        candidate: event.candidate,
        from: window.PeerAPI.getMyId()
      });
    }
  };

  // Se for host, cria offer; se for cliente, espera offer
  if (window.PeerAPI && window.PeerAPI.isHost()) {
    try {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      window.PeerAPI.sendTo(peerId, {
        type: 'voice_offer',
        sdp: offer,
        from: window.PeerAPI.getMyId()
      });
    } catch (e) {
      console.warn('[VOICE] Erro ao criar offer:', e);
    }
  }
}

// Recebe offer/answer/ICE via PeerJS data channel
async function handleSignaling(data, fromId) {
  if (!enabled) return;
  let pc = peerConnections.get(fromId);
  if (!pc) {
    // Cria PC se não existe
    pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    });
    peerConnections.set(fromId, pc);
    if (localStream) {
      localStream.getTracks().forEach(track => {
        pc.addTrack(track, localStream);
      });
    }
    pc.ontrack = (event) => {
      const audio = new Audio();
      audio.srcObject = event.streams[0];
      audio.volume = micVolume;
      audio.play().catch(e => console.warn('[VOICE] Audio play error:', e));
      peers.set(fromId, { audio });
    };
    pc.onicecandidate = (event) => {
      if (event.candidate && window.PeerAPI) {
        window.PeerAPI.sendTo(fromId, {
          type: 'voice_ice',
          candidate: event.candidate,
          from: window.PeerAPI.getMyId()
        });
      }
    };
  }

  if (data.type === 'voice_offer') {
    try {
      await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      window.PeerAPI.sendTo(fromId, {
        type: 'voice_answer',
        sdp: answer,
        from: window.PeerAPI.getMyId()
      });
    } catch (e) { console.warn('[VOICE] Offer error:', e); }
  } else if (data.type === 'voice_answer') {
    try {
      await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
    } catch (e) { console.warn('[VOICE] Answer error:', e); }
  } else if (data.type === 'voice_ice') {
    try {
      if (data.candidate) {
        await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
      }
    } catch (e) { console.warn('[VOICE] ICE error:', e); }
  }
}

// Quando novo peer entra, conecta voz
function onPeerConnected(peerId) {
  if (enabled) {
    setTimeout(() => createVoiceConnection(peerId), 1000);
  }
}

function onPeerDisconnected(peerId) {
  const pc = peerConnections.get(peerId);
  if (pc) {
    try { pc.close(); } catch(e){}
    peerConnections.delete(peerId);
  }
  peers.delete(peerId);
}

// Get mic level (0-1) para visualização
function getMicLevel() {
  if (!analyser) return 0;
  const data = new Uint8Array(analyser.frequencyBinCount);
  analyser.getByteFrequencyData(data);
  let sum = 0;
  for (let i = 0; i < data.length; i++) sum += data[i];
  return Math.min(1, sum / data.length / 80);
}

function isEnabled() { return enabled; }
function isMuted() { return muted; }

window.VoiceChat = {
  init: VoiceChatInit,
  start: startMic,
  stop: stopMic,
  toggle,
  toggleMute,
  handleSignaling,
  onPeerConnected,
  onPeerDisconnected,
  getMicLevel,
  isEnabled,
  isMuted
};
})();
