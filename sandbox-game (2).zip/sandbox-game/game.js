// ============================================================
// game.js — Orquestrador principal
// ============================================================
(function() {
'use strict';

window.GameState = {
  inGame: false, mode: null, roomName: '', map: 'lobby',
  hostId: null, scene: null, camera: null, renderer: null, clock: null
};

let scene, camera, renderer, clock;
let ambientLight, sunLight;
let sky = null;
let lastTime = 0;

function Init() {
  // PeerJS silencioso no menu (gera ID)
  if (window.PeerAPI) {
    window.PeerAPI.init({
      onOpen: (id, isHost) => {
        const el = document.getElementById('myPeerId');
        if (el) el.textContent = 'ID: ' + id;
        window.GameState.myPeerId = id;
      },
      onError: (err) => console.warn('[GAME] Peer erro inicial:', err.type),
      onData: (data, fromId) => { if (window.Network) window.Network.receive(data, fromId); },
      onPeerJoined: (peerId) => {
        if (window.UI) window.UI.updatePlayerCount(window.PeerAPI.getConnectedPeerIds().length + 1);
      },
      onPeerLeft: (peerId) => {
        if (window.Network) window.Network.removeRemotePlayer(peerId, 'Jogador');
        if (window.UI) window.UI.updatePlayerCount(window.PeerAPI.getConnectedPeerIds().length + 1);
      }
    });
  }

  if (window.UI) window.UI.init();
  if (window.Chat) window.Chat.init();
  if (window.Inventory) window.Inventory.init();
  if (window.Audio) window.Audio.init();

  const canvas = document.getElementById('gameCanvas');
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;

  scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0xaaccff, 60, 300);

  camera = new THREE.PerspectiveCamera(window.Save.getSettings().fov, window.innerWidth / window.innerHeight, 0.1, 600);
  clock = new THREE.Clock();

  ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);

  sunLight = new THREE.DirectionalLight(0xffeecc, 1.2);
  sunLight.position.set(50, 80, 30);
  sunLight.castShadow = true;
  sunLight.shadow.mapSize.set(2048, 2048);
  sunLight.shadow.camera.left = -100;
  sunLight.shadow.camera.right = 100;
  sunLight.shadow.camera.top = 100;
  sunLight.shadow.camera.bottom = -100;
  sunLight.shadow.camera.far = 400;
  scene.add(sunLight);

  // Sky com shader dinâmico
  sky = window.Loader.createSky();
  scene.add(sky);

  window.GameState.scene = scene;
  window.GameState.camera = camera;
  window.GameState.renderer = renderer;

  window.addEventListener('resize', onResize);

  if (window.Physics) window.Physics.init();
  if (window.Effects) window.Effects.init(scene);
  if (window.Builder) window.Builder.init(scene);
  if (window.GameMode) window.GameMode.init(scene, camera);

  lastTime = performance.now();
  requestAnimationFrame(loop);
}

function onResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function Start(options) {
  window.GameState.inGame = true;
  window.GameState.mode = options.mode;
  window.GameState.roomName = options.roomName;
  window.GameState.map = options.map;
  window.GameState.gameMode = options.gameMode || 'free';

  if (options.mode === 'host') {
    setInterval(() => {
      if (window.PeerAPI && window.PeerAPI.isHost()) {
        window.PeerAPI.broadcast({
          type: 'lobby',
          hostId: window.PeerAPI.getMyId(),
          roomName: options.roomName,
          map: options.map,
          gameMode: options.gameMode || 'free'
        });
      }
    }, 2000);
  }

  if (window.Loader) window.Loader.loadMap(scene, options.map);
  if (window.Player) window.Player.init(scene, camera);
  if (window.Weapon) window.Weapon.init(scene, camera);

  // Inicializa modo de jogo
  if (window.GameMode && options.gameMode && options.gameMode !== 'free') {
    setTimeout(() => window.GameMode.setMode(options.gameMode), 500);
  }

  if (window.UI) {
    window.UI.updateRoomInfo(options.roomName, options.map);
    window.UI.updateHealth(100);
    window.UI.updatePlayerCount(window.PeerAPI.getConnectedPeerIds().length + 1);
    window.UI.addNotification(`Bem-vindo a ${options.roomName}!`, 'success');
    if (window.Chat) window.Chat.addSystem(`Você entrou em "${options.roomName}" (${options.map})`);
    if (options.gameMode && options.gameMode !== 'free') {
      if (window.Chat) window.Chat.addSystem(`Modo: ${options.gameMode.toUpperCase()}`);
    }
  }

  const settings = window.Save.getSettings();
  sunLight.castShadow = settings.shadows;
  renderer.shadowMap.enabled = settings.shadows;

  setTimeout(() => {
    const canvas = document.getElementById('gameCanvas');
    if (canvas.requestPointerLock) canvas.requestPointerLock();
  }, 500);
}

function loop() {
  requestAnimationFrame(loop);
  const now = performance.now();
  const delta = Math.min(0.05, (now - lastTime) / 1000);
  lastTime = now;

  if (window.GameState.inGame && window.Physics) window.Physics.step(delta);
  if (window.GameState.inGame && window.Player) window.Player.update(delta);
  if (window.GameState.inGame && window.Weapon) window.Weapon.update(delta);
  if (window.GameState.inGame && window.Builder) window.Builder.update(delta);
  if (window.GameState.inGame && window.GameMode) window.GameMode.update(delta);
  if (window.GameState.inGame && window.Network) {
    window.Network.update(now);
    window.Network.interpolate(delta);
  }
  if (window.GameState.inGame && window.Loader) window.Loader.UpdateShaders(delta);
  if (window.Effects) window.Effects.update(delta);
  if (window.Avatar) window.Avatar.renderPreview(delta);

  // Sky segue a câmera
  if (sky && camera) {
    sky.position.copy(camera.position);
    if (sky.material.uniforms && sky.material.uniforms.time) {
      sky.material.uniforms.time.value = now / 1000;
    }
  }

  renderer.render(scene, camera);
}

function Exit() {
  if (window.Network) window.Network.sendLeave();
  if (window.PeerAPI) window.PeerAPI.disconnect();
  if (window.Player) window.Player.reset();
  if (window.Builder) window.Builder.clearAll();
  if (window.Loader) window.Loader.clearMap(scene);
  if (window.Network) window.Network.clearAll();
  if (window.Effects) window.Effects.clearAll();
  if (window.Physics) window.Physics.removeAllBodies();
  window.GameState.inGame = false;
  document.getElementById('hud').classList.add('hidden');
  document.getElementById('chatBox').classList.add('hidden');
  document.getElementById('buildPanel').classList.add('hidden');
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('mainMenu').classList.add('active');
}

window.Game = { start: Start, exit: Exit };

window.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    const chatInput = document.getElementById('chatInput');
    if (document.activeElement === chatInput) {
      chatInput.blur();
      chatInput.value = '';
    }
  }
});

// Boot
Init();
})();
