// ============================================================
// physics.js — Mundo de física Cannon.js (UMD)
// ============================================================
(function() {
'use strict';

let world = null;
let bodies = new Map();
let nextBodyId = 1;

function PhysicsInit() {
  world = new CANNON.World();
  world.gravity.set(0, -22, 0);
  world.broadphase = new CANNON.SAPBroadphase(world);
  world.allowSleep = true;
  world.defaultContactMaterial.friction = 0.4;

  const groundMat = new CANNON.Material('ground');
  const playerMat = new CANNON.Material('player');
  const objectMat = new CANNON.Material('object');

  world.addContactMaterial(new CANNON.ContactMaterial(groundMat, playerMat, {
    friction: 0.0, restitution: 0.0
  }));
  world.addContactMaterial(new CANNON.ContactMaterial(groundMat, objectMat, {
    friction: 0.6, restitution: 0.2
  }));
  world.addContactMaterial(new CANNON.ContactMaterial(playerMat, objectMat, {
    friction: 0.1, restitution: 0.0
  }));

  world.materials = { groundMat, playerMat, objectMat };
}

function PhysicsStep(delta) {
  if (!world) return;
  // cannon.js: world.step(dt) — usa timestep fixo internamente
  world.step(Math.min(delta, 1/30));
}

function AddStaticBox(position, halfExtents, rotation, material) {
  const shape = new CANNON.Box(new CANNON.Vec3(halfExtents[0], halfExtents[1], halfExtents[2]));
  const body = new CANNON.Body({
    mass: 0,
    shape: shape,
    position: new CANNON.Vec3(position[0], position[1], position[2]),
    material: material || world.materials.objectMat
  });
  if (rotation) {
    body.quaternion.setFromEuler(rotation[0], rotation[1], rotation[2]);
  }
  world.addBody(body);
  const id = nextBodyId++;
  bodies.set(id, { body, type: 'static' });
  return id;
}

function AddStaticPlane(y) {
  const groundBody = new CANNON.Body({
    mass: 0,
    shape: new CANNON.Plane(),
    material: world.materials.groundMat
  });
  groundBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
  groundBody.position.set(0, y || 0, 0);
  world.addBody(groundBody);
  const id = nextBodyId++;
  bodies.set(id, { body: groundBody, type: 'static' });
  return id;
}

function AddStaticSphere(position, radius) {
  const shape = new CANNON.Sphere(radius);
  const body = new CANNON.Body({
    mass: 0, shape: shape,
    position: new CANNON.Vec3(position[0], position[1], position[2]),
    material: world.materials.objectMat
  });
  world.addBody(body);
  const id = nextBodyId++;
  bodies.set(id, { body, type: 'static' });
  return id;
}

function AddStaticCylinder(position, radius, height) {
  // Cylinder em cannon.js é no eixo Z, rotaciona para Y
  const shape = new CANNON.Cylinder(radius, radius, height, 12);
  const body = new CANNON.Body({
    mass: 0, shape: shape,
    position: new CANNON.Vec3(position[0], position[1], position[2]),
    material: world.materials.objectMat
  });
  const quat = new CANNON.Quaternion();
  quat.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), Math.PI / 2);
  body.quaternion = quat;
  world.addBody(body);
  const id = nextBodyId++;
  bodies.set(id, { body, type: 'static' });
  return id;
}

function CreatePlayerBody(position) {
  const shape = new CANNON.Sphere(0.6);
  const body = new CANNON.Body({
    mass: 70,
    shape: shape,
    position: new CANNON.Vec3(position[0], position[1], position[2]),
    material: world.materials.playerMat,
    fixedRotation: true,
    linearDamping: 0.95
  });
  body.updateMassProperties();
  world.addBody(body);
  return body;
}

function RemoveBody(id) {
  const b = bodies.get(id);
  if (b) { world.removeBody(b.body); bodies.delete(id); }
}

function RemoveAllBodies() {
  for (const [id, b] of bodies) { world.removeBody(b.body); }
  bodies.clear();
}

function Raycast(from, to, excludeBody) {
  const result = new CANNON.RaycastResult();
  const opts = { collisionFilterMask: -1, skipBackfaces: true };
  world.raycastClosest(
    new CANNON.Vec3(from.x, from.y, from.z),
    new CANNON.Vec3(to.x, to.y, to.z),
    opts,
    result
  );
  return result.hasHit ? result : null;
}

window.Physics = {
  init: PhysicsInit,
  step: PhysicsStep,
  addStaticBox: AddStaticBox,
  addStaticPlane: AddStaticPlane,
  addStaticSphere: AddStaticSphere,
  addStaticCylinder: AddStaticCylinder,
  createPlayerBody: CreatePlayerBody,
  removeBody: RemoveBody,
  removeAllBodies: RemoveAllBodies,
  raycast: Raycast,
  getWorld: () => world
};
})();
