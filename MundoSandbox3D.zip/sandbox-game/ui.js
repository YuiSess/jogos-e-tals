// ============================================================
// ui.js — Interface
// ============================================================
(function() {
'use strict';

let currentTab = 'head';
let previewCanvas = null;

function UIInit() {
  setupMenuNavigation();
  setupMainButtons();
  setupCustomize();
  setupEmotes();
  setupSettings();
  if (window.PeerAPI && window.PeerAPI.getMyId()) {
    document.getElementById('myPeerId').textContent = 'ID: ' + window.PeerAPI.getMyId();
  }
}

function setupMenuNavigation() {
  document.querySelectorAll('[data-back]').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
      document.getElementById('mainMenu').classList.add('active');
    };
  });
}

function setupMainButtons() {
  document.getElementById('btnPlay').onclick = () => startGame({ mode: 'solo', map: 'lobby', roomName: 'Solo' });
  document.getElementById('btnCreateRoom').onclick = () => showScreen('createRoomScreen');
  document.getElementById('btnJoinRoom').onclick = () => showScreen('joinRoomScreen');
  document.getElementById('btnBrowseRooms').onclick = () => {
    showScreen('browseRoomsScreen');
    refreshRoomsList();
  };
  document.getElementById('btnCustomize').onclick = () => { showScreen('customizeScreen'); initCustomizePreview(); };
  document.getElementById('btnInventory').onclick = () => { showScreen('inventoryScreen'); if (window.Inventory) window.Inventory.render(); };
  document.getElementById('btnShop').onclick = () => { showScreen('shopScreen'); if (window.Inventory) window.Inventory.renderShop(); };
  document.getElementById('btnSettings').onclick = () => { showScreen('settingsScreen'); loadSettings(); };
  document.getElementById('btnCopyId').onclick = () => {
    const id = window.PeerAPI ? window.PeerAPI.getMyId() : null;
    if (id) { navigator.clipboard.writeText(id); addNotification('ID copiado!', 'success'); }
  };

  // Botão de atualizar salas
  const refreshBtn = document.getElementById('btnRefreshRooms');
  if (refreshBtn) {
    refreshBtn.onclick = () => refreshRoomsList();
  }

  document.getElementById('btnConfirmCreate').onclick = () => {
    const roomName = document.getElementById('roomName').value || 'Sala';
    const map = document.getElementById('mapSelect').value;
    const mode = document.getElementById('modeSelect').value;
    const maxPlayers = parseInt(document.getElementById('maxPlayers').value);
    if (window.Network) {
      window.Network.init({
        onOpen: (id, isHost) => {
          // Mostra o código da sala em destaque
          document.getElementById('createRoomInfo').innerHTML = `
            <div style="background:#1a2332;padding:14px;border-radius:8px;border:2px solid #fbbf24;margin-top:10px;">
              <div style="color:#8b949e;font-size:11px;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px;">🔑 CÓDIGO DA SALA</div>
              <div style="display:flex;align-items:center;gap:10px;">
                <code style="background:#0d1117;padding:8px 12px;border-radius:6px;font-size:14px;color:#fbbf24;font-weight:bold;flex:1;word-break:break-all;">${id}</code>
                <button id="btnCopyRoomCode" style="background:#238636;color:#fff;border:none;padding:8px 14px;border-radius:6px;cursor:pointer;font-weight:bold;">📋 COPIAR</button>
              </div>
              <div style="color:#8b949e;font-size:12px;margin-top:10px;">Compartilhe este código com seus amigos para entrarem via "Entrar em Sala".</div>
              <div style="color:#3fb950;font-size:12px;margin-top:6px;">⏳ Iniciando jogo em 8s...</div>
            </div>
          `;
          document.getElementById('myPeerId').textContent = 'ID: ' + id;
          // Botão copiar
          setTimeout(() => {
            const copyBtn = document.getElementById('btnCopyRoomCode');
            if (copyBtn) {
              copyBtn.onclick = () => {
                navigator.clipboard.writeText(id);
                copyBtn.textContent = '✓ COPIADO!';
                setTimeout(() => copyBtn.textContent = '📋 COPIAR', 2000);
                addNotification('Código copiado!', 'success');
              };
            }
          }, 100);
          // Registra a sala nas salas abertas
          if (window.Rooms) {
            window.Rooms.registerRoom({
              name: roomName,
              map: map,
              gameMode: mode,
              hostName: window.Save ? window.Save.getPlayerName() : 'Host',
              maxPlayers: maxPlayers,
              currentPlayers: 1
            });
          }
          // Inicia o jogo direto — o peer do próprio jogo é o host
          setTimeout(() => { startGame({ mode: 'host', map, roomName, maxPlayers, peerId: id, gameMode: mode }); }, 8000);
        },
        onError: (err) => {
          document.getElementById('createRoomInfo').textContent = 'Erro: ' + err.type + ' — tente novamente.';
        }
      });
    }
  };

  document.getElementById('btnConfirmJoin').onclick = () => {
    const hostId = document.getElementById('hostIdInput').value.trim();
    const name = document.getElementById('playerNameInput').value.trim() || 'Jogador';
    if (!hostId) {
      document.getElementById('joinRoomInfo').textContent = '❌ Digite o ID do host!';
      return;
    }
    if (window.Save) window.Save.setPlayerName(name);
    const info = document.getElementById('joinRoomInfo');
    info.innerHTML = `🔄 Conectando a <b>${hostId}</b>...`;

    if (window.Network) {
      window.Network.init({
        onOpen: (id, isHost) => {
          document.getElementById('myPeerId').textContent = 'ID: ' + id;
          info.innerHTML = `🔄 Conectando ao host...`;
          window.Network.connect(hostId);
        },
        onError: (err) => {
          info.innerHTML = '❌ Erro: ' + err.type + '<br>Tente novamente ou verifique o ID.';
        },
        onPeerJoined: (peerId) => {
          info.innerHTML = '✅ Conectado ao host! Entrando no jogo...';
        }
      });
      // Timeout — se não conectar em 8s, avisa
      setTimeout(() => {
        if (!window.GameState || !window.GameState.inGame) {
          const connected = window.PeerAPI && window.PeerAPI.getConnectedPeerIds().length > 0;
          if (!connected) {
            info.innerHTML = '⚠️ Não foi possível conectar.<br>Verifique se o ID está correto e se o host está online.';
          } else {
            const map = (window.GameState && window.GameState.map) || 'lobby';
            const roomName = (window.GameState && window.GameState.roomName) || 'Sala';
            const gameMode = (window.GameState && window.GameState.gameMode) || 'free';
            startGame({ mode: 'client', map, roomName, hostId, gameMode });
          }
        }
      }, 5000);
    }
  };

  document.getElementById('btnSaveAvatar').onclick = () => {
    addNotification('Avatar salvo!', 'success');
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('mainMenu').classList.add('active');
  };
}

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// ===== Salas abertas — atualiza a lista =====
function refreshRoomsList() {
  const list = document.getElementById('roomsList');
  if (!list) return;
  const rooms = window.Rooms ? window.Rooms.getRooms() : [];
  if (!rooms || rooms.length === 0) {
    list.innerHTML = '<div class="room-empty">🔍 Nenhuma sala aberta no momento.<br><br>Crie uma sala e compartilhe o código com seus amigos!<br><br><span style="font-size:11px;opacity:0.6;">💡 Você também pode usar "Entrar em Sala" com o ID fornecido pelo host.</span></div>';
    return;
  }
  list.innerHTML = '';
  const mapIcons = {
    lobby: '🏛️', city: '🏙️', park: '🌳', sandbox: '🏖️', range: '🎯',
    pvp: '⚔️', arena: '🥊', house: '🏠', apartment: '🏢', forest: '🌲',
    beach: '🏖️', island: '🏝️', queimada: '🏐', futebol: '⚽', ctf: '🚩'
  };
  const modeLabels = {
    free: 'Livre', queimada: 'Queimada', futebol: 'Futebol', ctf: 'Capture the Flag'
  };
  for (const room of rooms) {
    // Não mostra minha própria sala
    if (room.peerId === (window.PeerAPI ? window.PeerAPI.getMyId() : null)) continue;
    const card = document.createElement('div');
    card.className = 'room-card-public';
    const age = Math.floor((Date.now() - (room.createdAt || 0)) / 1000);
    const ageStr = age < 60 ? `${age}s atrás` : `${Math.floor(age/60)}min atrás`;
    card.innerHTML = `
      <div class="room-icon">${mapIcons[room.map] || '🎮'}</div>
      <div class="room-info">
        <div class="room-name">${escapeHtml(room.name)}</div>
        <div class="room-meta">
          🗺️ ${room.map || 'lobby'} · 👤 ${escapeHtml(room.hostName || 'Host')} · ⏱️ ${ageStr}
        </div>
        <div class="room-tags">
          <span class="room-tag">${modeLabels[room.gameMode] || room.gameMode || 'Livre'}</span>
          <span class="room-tag">👥 ${room.currentPlayers || 1}/${room.maxPlayers || 12}</span>
        </div>
      </div>
      <button class="room-join">ENTRAR</button>
    `;
    card.querySelector('.room-join').onclick = () => {
      const playerName = window.Save ? window.Save.getPlayerName() : 'Jogador';
      addNotification(`Entrando em "${room.name}"...`, 'info');
      if (window.Rooms) window.Rooms.joinRoom(room.peerId, playerName);
    };
    list.appendChild(card);
  }
  // Se só tem minha sala
  if (list.children.length === 0) {
    list.innerHTML = '<div class="room-empty">🔍 Nenhuma sala aberta no momento.<br><br>Crie uma sala e compartilhe o código com seus amigos!</div>';
  }
}

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function setupCustomize() {
  // Adiciona a aba de Personagem
  const tabsContainer = document.querySelector('.tabs');
  if (tabsContainer && !document.querySelector('.tab[data-tab="character"]')) {
    const charTab = document.createElement('button');
    charTab.className = 'tab';
    charTab.dataset.tab = 'character';
    charTab.textContent = 'Personagem';
    charTab.style.background = 'linear-gradient(135deg, #ff6399, #fbbf24)';
    charTab.style.color = '#fff';
    tabsContainer.insertBefore(charTab, tabsContainer.firstChild);
    charTab.onclick = () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      charTab.classList.add('active');
      currentTab = 'character';
      renderCustomizeTab();
    };
  }
  document.querySelectorAll('.tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentTab = tab.dataset.tab;
      renderCustomizeTab();
    };
  });
  renderCustomizeTab();
}

function initCustomizePreview() {
  previewCanvas = document.getElementById('avatarPreviewCanvas');
  if (previewCanvas && window.Avatar) window.Avatar.initPreview(previewCanvas);
  renderCustomizeTab();
}

function renderCustomizeTab() {
  const content = document.getElementById('customizeContent');
  if (!content) return;
  const av = window.Save.getAvatar();
  const acc = window.Save.getAccessories();
  let html = '';

  if (currentTab === 'character') {
    html += '<h4>Escolha seu Personagem</h4>';
    const charInfo = {
      human:    { name: 'Humano',    icon: '🧑', desc: 'Personagem padrão' },
      skeleton: { name: 'Esqueleto', icon: '💀', desc: 'Olhos vermelhos brilhantes' },
      robot:    { name: 'Robô',      icon: '🤖', desc: 'Metal com LEDs e antena' },
      ninja:    { name: 'Ninja',     icon: '🥷', desc: 'Traje preto + katana' },
      zombie:   { name: 'Zumbi',     icon: '🧟', desc: 'Olhos amarelos e sangue' },
      alien:    { name: 'Alien',     icon: '👽', desc: 'Pele verde + antenas' },
      wizard:   { name: 'Mago',      icon: '🧙', desc: 'Chapéu pontudo + cajado' }
    };
    for (const type of window.Avatar.CHARACTER_TYPES) {
      const info = charInfo[type] || { name: type, icon: '❓', desc: '' };
      const isCurrent = av.characterType === type || (!av.characterType && type === 'human');
      html += `<div class="char-card ${isCurrent ? 'active' : ''}" data-char="${type}" style="display:flex;align-items:center;gap:12px;padding:12px;background:#21262d;border:2px solid ${isCurrent ? '#fbbf24' : '#30363d'};border-radius:8px;margin:6px 0;cursor:pointer;">
        <div style="font-size:36px;">${info.icon}</div>
        <div>
          <div style="font-weight:bold;color:${isCurrent ? '#fbbf24' : '#e6edf3'};">${info.name}</div>
          <div style="font-size:11px;color:#8b949e;">${info.desc}</div>
        </div>
      </div>`;
    }
  } else if (currentTab === 'head') {
    html += '<h4>Cor da Pele</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.headColor === c ? 'active' : ''}" style="background:${c}" data-field="headColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'body') {
    html += '<h4>Cor do Corpo</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.bodyColor === c ? 'active' : ''}" style="background:${c}" data-field="bodyColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'arms') {
    html += '<h4>Cor dos Braços</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.armsColor === c ? 'active' : ''}" style="background:${c}" data-field="armsColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'legs') {
    html += '<h4>Cor das Pernas</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.legsColor === c ? 'active' : ''}" style="background:${c}" data-field="legsColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'hair') {
    html += '<h4>Estilo de Cabelo</h4>';
    for (const h of window.Avatar.HAIR_STYLES) {
      html += `<button class="option-btn ${av.hairStyle === h ? 'active' : ''}" data-field="hairStyle" data-value="${h}">${h}</button>`;
    }
    html += '<h4>Cor do Cabelo</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.hairColor === c ? 'active' : ''}" style="background:${c}" data-field="hairColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'clothes') {
    html += '<h4>Roupa</h4>';
    for (const cl of window.Avatar.CLOTHES) {
      html += `<button class="option-btn ${av.clothes === cl ? 'active' : ''}" data-field="clothes" data-value="${cl}">${cl}</button>`;
    }
    html += '<h4>Cor da Roupa</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.clothesColor === c ? 'active' : ''}" style="background:${c}" data-field="clothesColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'shoes') {
    html += '<h4>Sapatos</h4>';
    for (const sh of window.Avatar.SHOES) {
      html += `<button class="option-btn ${av.shoes === sh ? 'active' : ''}" data-field="shoes" data-value="${sh}">${sh}</button>`;
    }
    html += '<h4>Cor dos Sapatos</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.shoesColor === c ? 'active' : ''}" style="background:${c}" data-field="shoesColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'accessory') {
    html += '<h4>Chapéu/Boné</h4>';
    for (const h of window.Avatar.HATS) {
      html += `<button class="option-btn ${acc.hat === h ? 'active' : ''}" data-acc="hat" data-value="${h || ''}">${h || 'Nenhum'}</button>`;
    }
    html += '<h4>Óculos</h4>';
    for (const g of window.Avatar.GLASSES) {
      html += `<button class="option-btn ${acc.glasses === g ? 'active' : ''}" data-acc="glasses" data-value="${g || ''}">${g || 'Nenhum'}</button>`;
    }
    html += '<h4>Máscara</h4>';
    for (const m of window.Avatar.MASKS) {
      html += `<button class="option-btn ${acc.mask === m ? 'active' : ''}" data-acc="mask" data-value="${m || ''}">${m || 'Nenhum'}</button>`;
    }
  } else if (currentTab === 'wings') {
    html += '<h4>Costas</h4>';
    for (const b of window.Avatar.BACKS) {
      html += `<button class="option-btn ${acc.back === b ? 'active' : ''}" data-acc="back" data-value="${b || ''}">${b || 'Nenhum'}</button>`;
    }
  }

  content.innerHTML = html;

  content.querySelectorAll('.color-swatch').forEach(sw => {
    sw.onclick = () => {
      const field = sw.dataset.field;
      const value = sw.dataset.value;
      av[field] = value;
      window.Save.setAvatar(av);
      content.querySelectorAll(`[data-field="${field}"]`).forEach(s => s.classList.remove('active'));
      sw.classList.add('active');
      if (window.Avatar) window.Avatar.updatePreview(av, acc);
    };
  });
  content.querySelectorAll('.option-btn').forEach(btn => {
    btn.onclick = () => {
      if (btn.dataset.acc) {
        const accField = btn.dataset.acc;
        const value = btn.dataset.value || null;
        acc[accField] = value;
        window.Save.setAccessories(acc);
        content.querySelectorAll(`[data-acc="${accField}"]`).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      } else {
        const field = btn.dataset.field;
        const value = btn.dataset.value;
        av[field] = value;
        window.Save.setAvatar(av);
        content.querySelectorAll(`[data-field="${field}"]`).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      }
      if (window.Avatar) window.Avatar.updatePreview(av, acc);
    };
  });
  // Handler para seleção de personagem
  content.querySelectorAll('.char-card').forEach(card => {
    card.onclick = () => {
      const charType = card.dataset.char;
      av.characterType = charType;
      window.Save.setAvatar(av);
      content.querySelectorAll('.char-card').forEach(c => {
        c.style.borderColor = '#30363d';
        c.querySelector('div div:first-child').style.color = '#e6edf3';
      });
      card.style.borderColor = '#fbbf24';
      card.querySelector('div div:first-child').style.color = '#fbbf24';
      if (window.Avatar) window.Avatar.updatePreview(av, acc);
      addNotification(`Personagem: ${charType}`, 'success');
    };
  });
}

function setupEmotes() {
  document.querySelectorAll('#emoteBar button').forEach(btn => {
    btn.onclick = () => { if (window.Player) window.Player.playEmote(btn.dataset.emote); };
  });
  const btnDay = document.getElementById('btnDayNight');
  if (btnDay) {
    btnDay.onclick = () => {
      if (window.Loader) {
        const t = window.Loader.toggleDayNight();
        addNotification(`Hora: ${t < 0.25 ? 'Madrugada' : t < 0.5 ? 'Manhã' : t < 0.75 ? 'Tarde' : 'Noite'}`, 'info');
      }
    };
  }
  const btnWeather = document.getElementById('btnWeather');
  if (btnWeather) {
    btnWeather.onclick = () => {
      if (window.Loader) {
        const w = window.Loader.toggleWeather();
        addNotification(`Clima: ${w === 'clear' ? 'Limpo ☀️' : w === 'rain' ? 'Chuva 🌧️' : w === 'snow' ? 'Neve ❄️' : 'Folhas 🍂'}`, 'info');
      }
    };
  }
  const btnVoice = document.getElementById('btnVoiceChat');
  if (btnVoice) {
    btnVoice.onclick = () => {
      if (window.VoiceChat) {
        const enabled = window.VoiceChat.toggle();
        btnVoice.classList.toggle('active', enabled);
        const indicator = document.getElementById('voiceIndicator');
        if (indicator) indicator.classList.toggle('hidden', !enabled);
      }
    };
  }
  const btnMute = document.getElementById('btnMuteMic');
  if (btnMute) {
    btnMute.onclick = () => {
      if (window.VoiceChat) {
        const muted = window.VoiceChat.toggleMute();
        btnMute.textContent = muted ? '🔇' : '🔊';
        btnMute.title = muted ? 'Desmutar [H]' : 'Mutar [H]';
      }
    };
  }
}

function setupSettings() {
  const settings = window.Save.getSettings();
  document.getElementById('sensitivity').oninput = (e) => { settings.sensitivity = parseFloat(e.target.value); window.Save.setSettings(settings); };
  document.getElementById('volume').oninput = (e) => { settings.volume = parseFloat(e.target.value); window.Save.setSettings(settings); };
  document.getElementById('fov').oninput = (e) => {
    settings.fov = parseInt(e.target.value);
    window.Save.setSettings(settings);
    if (window.GameState && window.GameState.camera) {
      window.GameState.camera.fov = settings.fov;
      window.GameState.camera.updateProjectionMatrix();
    }
  };
  document.getElementById('shadows').onchange = (e) => { settings.shadows = e.target.checked; window.Save.setSettings(settings); };
  document.getElementById('particles').onchange = (e) => { settings.particles = e.target.checked; window.Save.setSettings(settings); };
  if (document.getElementById('bloom')) {
    document.getElementById('bloom').onchange = (e) => { settings.bloom = e.target.checked; window.Save.setSettings(settings); };
  }
  document.getElementById('fpMode').onchange = (e) => { settings.fpMode = e.target.checked; window.Save.setSettings(settings); };
}

function loadSettings() {
  const s = window.Save.getSettings();
  document.getElementById('sensitivity').value = s.sensitivity;
  document.getElementById('volume').value = s.volume;
  document.getElementById('fov').value = s.fov;
  document.getElementById('shadows').checked = s.shadows;
  document.getElementById('particles').checked = s.particles;
  if (document.getElementById('bloom')) document.getElementById('bloom').checked = s.bloom !== false;
  document.getElementById('fpMode').checked = s.fpMode !== false;
}

function toggleInventory() {
  // Durante o jogo, usa o HUD de inventário; no menu, usa a tela cheia
  if (window.GameState && window.GameState.inGame) {
    toggleInventoryHud();
    return;
  }
  const screen = document.getElementById('inventoryScreen');
  if (screen.classList.contains('active')) {
    screen.classList.remove('active');
  } else {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    screen.classList.add('active');
    if (window.Inventory) window.Inventory.render();
  }
}

function startGame(options) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('hud').classList.remove('hidden');
  document.getElementById('chatBox').classList.remove('hidden');
  if (window.Game) window.Game.start(options);
}

function onLobbyJoined(data) {
  if (window.GameState) {
    window.GameState.roomName = data.roomName;
    window.GameState.map = data.map;
    window.GameState.hostId = data.hostId;
    window.GameState.gameMode = data.gameMode || 'free';
  }
  updateRoomInfo(data.roomName, data.map);
}

function updateHealth(h) {
  const fill = document.getElementById('healthFill');
  const text = document.getElementById('healthText');
  if (fill) { fill.style.width = h + '%'; fill.classList.toggle('low', h < 30); }
  if (text) text.textContent = Math.max(0, Math.round(h));
}

function updateAmmo(mag, reserve, weaponName) {
  const ammo = document.getElementById('ammoText');
  const wpn = document.getElementById('hudWeapon');
  if (ammo) ammo.textContent = `${mag}/${reserve}`;
  if (wpn) wpn.textContent = weaponName;
}

function updateWeaponsList() {
  const div = document.getElementById('hudWeapons');
  if (!div) return;
  const inv = window.Save.getInventory();
  const slots = [
    { id: inv.equipped.weapon1, num: 1 },
    { id: inv.equipped.weapon2, num: 2 },
    { id: inv.equipped.weapon3, num: 3 }
  ];
  div.innerHTML = '';
  for (const s of slots) {
    if (!s.id) continue;
    const cfg = window.Weapon.WEAPONS[s.id];
    const el = document.createElement('div');
    if (window.Weapon && window.Weapon.getCurrentWeaponId() === s.id) el.classList.add('active');
    el.textContent = `${s.num}. ${cfg.icon} ${cfg.name}`;
    el.onclick = () => { if (window.Weapon) window.Weapon.selectSlot(s.num - 1); };
    div.appendChild(el);
  }
  // Atualiza hotbar
  updateHotbar();
}

// Atualiza a hotbar (3 slots de arma + Q + B)
function updateHotbar() {
  const inv = window.Save.getInventory();
  const weapons = [inv.equipped.weapon1, inv.equipped.weapon2, inv.equipped.weapon3];
  const currentWpn = window.Weapon ? window.Weapon.getCurrentWeaponId() : null;
  for (let i = 0; i < 3; i++) {
    const slotEl = document.querySelector(`.hotbar-slot[data-slot="${i}"]`);
    const iconEl = document.getElementById('hotbar' + i);
    if (slotEl && iconEl) {
      const wpnId = weapons[i];
      if (wpnId && window.Weapon && window.Weapon.WEAPONS[wpnId]) {
        iconEl.textContent = window.Weapon.WEAPONS[wpnId].icon;
        slotEl.classList.remove('empty');
        slotEl.classList.toggle('active', wpnId === currentWpn);
      } else {
        iconEl.textContent = '—';
        slotEl.classList.add('empty');
        slotEl.classList.remove('active');
      }
      slotEl.onclick = () => { if (window.Weapon) window.Weapon.selectSlot(i); };
    }
  }
  // Slot Q (emote/pegar)
  const qSlot = document.querySelector('.hotbar-slot[data-slot="emote"]');
  if (qSlot) {
    qSlot.onclick = () => {
      if (window.GameMode && (window.GameMode.getMode() === 'queimada' || window.GameMode.getMode() === 'futebol')) {
        window.GameMode.tryCatchBall();
      }
    };
  }
  // Slot B (build)
  const bSlot = document.querySelector('.hotbar-slot[data-slot="build"]');
  if (bSlot) {
    bSlot.onclick = () => { if (window.Builder) window.Builder.toggle(); };
  }
}

// Toggle do painel de inventário completo (Tab)
function toggleInventoryHud() {
  const hud = document.getElementById('inventoryHud');
  if (!hud) return;
  if (hud.classList.contains('hidden')) {
    renderInventoryHud();
    hud.classList.remove('hidden');
    // Solta o pointer lock para interagir
    if (document.exitPointerLock) document.exitPointerLock();
  } else {
    hud.classList.add('hidden');
    // Re-trava o pointer
    const canvas = document.getElementById('gameCanvas');
    if (canvas.requestPointerLock && window.GameState && window.GameState.inGame) {
      canvas.requestPointerLock();
    }
  }
}

function renderInventoryHud() {
  const grid = document.getElementById('inventoryHudGrid');
  if (!grid) return;
  const inv = window.Save.getInventory();
  grid.innerHTML = '';
  for (const itemId of inv.items) {
    const item = window.Inventory.ALL_ITEMS[itemId];
    if (!item) continue;
    const isEquipped = isItemEquippedHud(itemId);
    const el = document.createElement('div');
    el.className = 'hud-inv-item' + (isEquipped ? ' equipped' : '');
    el.innerHTML = `<div class="icon">${item.icon}</div><div class="name">${item.name}</div>`;
    el.onclick = () => {
      window.Inventory.toggleEquip(itemId);
      renderInventoryHud();
      updateHotbar();
      updateWeaponsList();
    };
    grid.appendChild(el);
  }
  // Atualiza slots equipados
  document.querySelectorAll('.hud-equip-slot').forEach(slot => {
    const slotName = slot.dataset.slot;
    const equippedId = inv.equipped[slotName];
    slot.classList.toggle('filled', !!equippedId);
    if (equippedId && window.Inventory.ALL_ITEMS[equippedId]) {
      slot.textContent = window.Inventory.ALL_ITEMS[equippedId].icon;
      slot.onclick = () => {
        window.Inventory.unequip(slotName);
        renderInventoryHud();
        updateHotbar();
        updateWeaponsList();
      };
    } else {
      const labels = { weapon1: '1', weapon2: '2', weapon3: '3', hat: '🎩', mask: '😷', back: '🎒' };
      slot.textContent = labels[slotName] || '?';
      slot.onclick = () => {};
    }
  });
}

function isItemEquippedHud(itemId) {
  const inv = window.Save.getInventory();
  for (const slot in inv.equipped) {
    if (inv.equipped[slot] === itemId) return true;
  }
  return false;
}

function updateRoomInfo(room, map) {
  const r = document.getElementById('hudRoom');
  const m = document.getElementById('hudMap');
  if (r) r.textContent = 'Sala: ' + (room || '-');
  if (m) m.textContent = 'Mapa: ' + (map || '-');
}

function updatePlayerCount(count) {
  const p = document.getElementById('hudPlayers');
  if (p) p.textContent = 'Jogadores: ' + count;
}

function addNotification(text, type, duration) {
  type = type || 'info';
  duration = duration || 3000;
  const div = document.getElementById('notifications');
  if (!div) return;
  const n = document.createElement('div');
  n.className = 'notif ' + type;
  n.textContent = text;
  div.appendChild(n);
  setTimeout(() => {
    n.style.opacity = '0';
    n.style.transition = 'opacity 0.3s';
    setTimeout(() => n.remove(), 300);
  }, duration);
}

function flashDamage() {
  let overlay = document.getElementById('damageOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'damageOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:radial-gradient(circle,transparent 30%,rgba(255,0,0,0.4) 100%);pointer-events:none;z-index:200;opacity:0;transition:opacity 0.2s;';
    document.body.appendChild(overlay);
  }
  overlay.style.opacity = '1';
  setTimeout(() => { overlay.style.opacity = '0'; }, 200);
}

// ===== Painel de Seleção de Times (Queimada) =====
function showTeamSelect() {
  const panel = document.getElementById('teamSelectPanel');
  if (!panel) return;
  panel.classList.remove('hidden');
  if (document.exitPointerLock) document.exitPointerLock();
  updateTeamSelectUI();

  // Botões de ENTRAR em cada time
  document.querySelectorAll('.join-team').forEach(btn => {
    btn.onclick = () => {
      const t = parseInt(btn.dataset.team);
      if (window.GameMode) {
        window.GameMode.joinTeam(t);
        addNotification(`Você entrou no Time ${t === 1 ? 'Azul 🔵' : 'Vermelho 🔴'}`, 'success');
        setTimeout(updateTeamSelectUI, 300);
      }
    };
  });
  // Botão fechar
  const closeBtn = document.getElementById('btnCloseTeamSelect');
  if (closeBtn) {
    closeBtn.onclick = () => hideTeamSelect();
  }
}

function hideTeamSelect() {
  const panel = document.getElementById('teamSelectPanel');
  if (panel) panel.classList.add('hidden');
  // Re-trava o ponteiro
  const canvas = document.getElementById('gameCanvas');
  if (canvas.requestPointerLock && window.GameState && window.GameState.inGame) {
    canvas.requestPointerLock();
  }
}

function updateTeamSelectUI() {
  if (!window.GameMode || window.GameMode.getMode() !== 'queimada') return;
  const teams = window.GameMode.getTeams();
  const myId = window.PeerAPI ? window.PeerAPI.getMyId() : null;
  const playersAlive = window.GameMode.getPlayersAlive();
  const scores = window.GameMode.getScores();
  const round = window.GameMode.getRoundNumber();

  // Lista de jogadores por time
  const blueList = document.getElementById('teamBluePlayers');
  const redList = document.getElementById('teamRedPlayers');
  if (blueList) {
    blueList.innerHTML = '';
    if (teams.team1.length === 0) {
      blueList.innerHTML = '<div style="color:#484f58;text-align:center;padding:20px;">Nenhum jogador</div>';
    } else {
      for (const pid of teams.team1) {
        const name = getPeerName(pid);
        const isMe = pid === myId;
        const isAlive = !eliminatedGlobalCheck(pid);
        const div = document.createElement('div');
        div.className = 'team-player' + (isMe ? ' me' : '');
        div.textContent = (isAlive ? '✓ ' : '✗ ') + name + (isMe ? ' (você)' : '');
        blueList.appendChild(div);
      }
    }
  }
  if (redList) {
    redList.innerHTML = '';
    if (teams.team2.length === 0) {
      redList.innerHTML = '<div style="color:#484f58;text-align:center;padding:20px;">Nenhum jogador</div>';
    } else {
      for (const pid of teams.team2) {
        const name = getPeerName(pid);
        const isMe = pid === myId;
        const isAlive = !eliminatedGlobalCheck(pid);
        const div = document.createElement('div');
        div.className = 'team-player' + (isMe ? ' me' : '');
        div.textContent = (isAlive ? '✓ ' : '✗ ') + name + (isMe ? ' (você)' : '');
        redList.appendChild(div);
      }
    }
  }
  // Placar
  const scoreEl = document.getElementById('teamScore');
  if (scoreEl) scoreEl.textContent = `${scores.team1} x ${scores.team2}`;
  const aliveEl = document.getElementById('teamAlive');
  if (aliveEl) aliveEl.textContent = `🔵 ${playersAlive.team1} vs 🔴 ${playersAlive.team2}`;
  const roundEl = document.getElementById('teamRound');
  if (roundEl) roundEl.textContent = round;
}

// Helper: pega nome do peer
function getPeerName(peerId) {
  if (window.Network && window.Network.getRemotePlayer) {
    const rp = window.Network.getRemotePlayer(peerId);
    if (rp) return rp.name;
  }
  if (window.PeerAPI && peerId === window.PeerAPI.getMyId()) {
    return window.Save ? window.Save.getPlayerName() : 'Você';
  }
  return 'Jogador';
}

// Helper: verifica se peer está eliminado
function eliminatedGlobalCheck(peerId) {
  if (window.GameMode && window.GameMode.isPeerEliminated) {
    return window.GameMode.isPeerEliminated(peerId);
  }
  return false;
}

window.UI = {
  init: UIInit, showScreen,
  updateHealth, updateAmmo, updateWeaponsList,
  updateRoomInfo, updatePlayerCount,
  addNotification, flashDamage,
  onLobbyJoined, toggleInventory,
  renderCustomize: renderCustomizeTab,
  showTeamSelect, hideTeamSelect, updateTeamSelectUI,
  refreshRoomsList
};
})();
