// ============================================================
// player.js — Controle do jogador (PRIMEIRA PESSOA por padrão)
// ============================================================
(function() {
'use strict';

let camera = null;
let scene = null;
let playerBody = null;
let playerMesh = null;
let yaw = 0;
let pitch = 0;
let isJumping = false;
let isGrounded = true;
let isCrouching = false;
let isSprinting = false;
let isSwimming = false;
let isClimbing = false;
let health = 100;
let currentAnim = 'idle';
let fpMode = true;        // PRIMEIRA PESSOA POR PADRÃO
let sensitivity = 1;
let fov = 75;
let cameraDistance = 4;
let pointerLocked = false;
let keys = {};
let waterLevel = -1000;
let climbObjects = [];
let interactables = [];
let respawnPoint = new THREE.Vector3(0, 2, 0);
let damageCooldown = 0;
let emoteLock = false;
let currentEmote = null;
let bobTimer = 0;
let weaponSway = { x: 0, y: 0 };

function PlayerInit(scn, cam) {
  scene = scn;
  camera = cam;
  const settings = window.Save ? window.Save.getSettings() : {};
  sensitivity = settings.sensitivity || 1;
  fov = settings.fov || 75;
  fpMode = settings.fpMode !== undefined ? settings.fpMode : true;  // default true
  camera.fov = fov;
  camera.updateProjectionMatrix();

  playerBody = window.Physics.createPlayerBody([respawnPoint.x, respawnPoint.y, respawnPoint.z]);

  // Avatar local (invisível em FP)
  playerMesh = window.Avatar.buildAvatarMesh(window.Save.getAvatar(), window.Save.getAccessories());
  scene.add(playerMesh);
  playerMesh.visible = !fpMode;

  setupInput();
  setupPointerLock();
}

function setupInput() {
  window.addEventListener('keydown', (e) => {
    if (document.activeElement && document.activeElement.tagName === 'INPUT') return;
    keys[e.code] = true;
    if (e.code === 'Space') isJumping = true;
    if (e.code === 'ControlLeft' || e.code === 'KeyC') isCrouching = true;
    if (e.code === 'ShiftLeft') isSprinting = true;
    if (e.code === 'KeyV') toggleCameraMode();
    if (e.code === 'KeyR') {
      if (!(window.Builder && window.Builder.isActive()) && window.Weapon) window.Weapon.reload();
    }
    if (e.code === 'KeyB') { if (window.Builder) window.Builder.toggle(); }
    if (e.code === 'KeyQ') {
      // No modo queimada/futebol, Q pega a bola
      if (window.GameMode) {
        if (window.GameMode.getMode() === 'queimada' || window.GameMode.getMode() === 'futebol') {
          window.GameMode.tryCatchBall();
        }
      }
    }
    if (e.code === 'KeyE') {
      // Interação contextual (pegar bandeira no CTF)
      if (window.GameMode && window.GameMode.getMode() === 'ctf') {
        window.GameMode.tryCatchBall();  // reusar para pegar bandeira
      }
    }
    if (e.code === 'Tab') {
      e.preventDefault();
      if (window.UI) window.UI.toggleInventory();
    }
    if (e.code === 'Enter') { if (window.Chat) window.Chat.toggle(); }
    if (e.code === 'Digit1') if (window.Weapon) window.Weapon.selectSlot(0);
    if (e.code === 'Digit2') if (window.Weapon) window.Weapon.selectSlot(1);
    if (e.code === 'Digit3') if (window.Weapon) window.Weapon.selectSlot(2);
  });
  window.addEventListener('keyup', (e) => {
    keys[e.code] = false;
    if (e.code === 'Space') isJumping = false;
    if (e.code === 'ControlLeft' || e.code === 'KeyC') isCrouching = false;
    if (e.code === 'ShiftLeft') isSprinting = false;
  });
  window.addEventListener('mousedown', (e) => {
    if (!pointerLocked) return;
    if (e.button === 0) {
      // Modos de jogo têm prioridade sobre atirar
      if (window.GameMode) {
        const mode = window.GameMode.getMode();
        if (mode === 'queimada' || mode === 'futebol') {
          if (window.GameMode.throwBall()) return;
        }
      }
      if (window.Builder && window.Builder.isActive()) window.Builder.placeBlock();
      else if (window.Weapon) window.Weapon.shoot();
    } else if (e.button === 2) {
      if (window.Builder && window.Builder.isActive()) window.Builder.deleteBlock();
    }
  });
  window.addEventListener('contextmenu', (e) => e.preventDefault());
}

function setupPointerLock() {
  const canvas = document.getElementById('gameCanvas');
  canvas.addEventListener('click', () => {
    if (!pointerLocked && window.GameState && window.GameState.inGame) {
      canvas.requestPointerLock();
      if (window.Audio) window.Audio.resume();
    }
  });
  document.addEventListener('pointerlockchange', () => {
    pointerLocked = document.pointerLockElement === canvas;
  });
  document.addEventListener('mousemove', (e) => {
    if (!pointerLocked) return;
    yaw -= e.movementX * 0.002 * sensitivity;
    pitch -= e.movementY * 0.002 * sensitivity;
    pitch = Math.max(-Math.PI / 2 + 0.1, Math.min(Math.PI / 2 - 0.1, pitch));
    // Weapon sway baseado no movimento do mouse
    weaponSway.x += e.movementX * 0.0001;
    weaponSway.y += e.movementY * 0.0001;
  });
}

function toggleCameraMode() {
  fpMode = !fpMode;
  if (playerMesh) playerMesh.visible = !fpMode;
  if (window.Weapon && window.Weapon.getCurrentWeaponId()) {
    window.Weapon.equipWeapon(window.Weapon.getCurrentWeaponId());
  }
  if (window.UI) window.UI.addNotification(fpMode ? 'Câmera: 1ª pessoa' : 'Câmera: 3ª pessoa', 'info');
}

function PlayerUpdate(delta) {
  if (!playerBody) return;

  const pos = playerBody.position;

  // === Escalada ===
  isClimbing = false;
  for (const obj of climbObjects) {
    if (obj.position.distanceTo(new THREE.Vector3(pos.x, pos.y, pos.z)) < (obj.userData.climbRadius || 1.5)) {
      isClimbing = true;
      break;
    }
  }

  // === Natação ===
  isSwimming = pos.y < waterLevel;

  // === Movimento ===
  const speed = isCrouching ? 2.5 : isSprinting ? 9 : isSwimming ? 4 : 5;
  const sinY = Math.sin(yaw), cosY = Math.cos(yaw);

  let moveX = 0, moveZ = 0;
  if (keys['KeyW']) { moveX -= sinY; moveZ -= cosY; }
  if (keys['KeyS']) { moveX += sinY; moveZ += cosY; }
  if (keys['KeyA']) { moveX -= cosY; moveZ += sinY; }
  if (keys['KeyD']) { moveX += cosY; moveZ -= sinY; }

  const len = Math.hypot(moveX, moveZ);
  if (len > 0) {
    moveX = (moveX / len) * speed;
    moveZ = (moveZ / len) * speed;
  }

  if (isClimbing) {
    playerBody.velocity.x = moveX * 0.5;
    playerBody.velocity.z = moveZ * 0.5;
    if (keys['KeyW']) playerBody.velocity.y = 3;
    else if (keys['KeyS']) playerBody.velocity.y = -3;
    else playerBody.velocity.y = 0;
  } else if (isSwimming) {
    playerBody.velocity.x = moveX;
    playerBody.velocity.z = moveZ;
    playerBody.velocity.y = keys['Space'] ? 3 : (keys['ControlLeft'] || keys['KeyC']) ? -3 : 0;
    playerBody.velocity.y *= 0.9;
  } else {
    playerBody.velocity.x = moveX;
    playerBody.velocity.z = moveZ;
    if (isJumping && isGrounded) {
      playerBody.velocity.y = 9;
      isGrounded = false;
    }
  }

  // Ground check
  const from = new CANNON.Vec3(pos.x, pos.y - 0.5, pos.z);
  const to = new CANNON.Vec3(pos.x, pos.y - 1.2, pos.z);
  const result = new CANNON.RaycastResult();
  window.Physics.getWorld().raycastClosest(from, to, { skipBackfaces: true }, result);
  isGrounded = result.hasHit;

  // === Avatar (atualiza mesh mesmo em FP para sincronizar com rede) ===
  if (playerMesh) {
    playerMesh.position.set(pos.x, pos.y - 0.6, pos.z);
    playerMesh.rotation.y = yaw + Math.PI;
    let anim = 'idle';
    if (isClimbing) anim = 'climb';
    else if (isSwimming) anim = 'swim';
    else if (!isGrounded) anim = 'jump';
    else if (isCrouching) anim = len > 0 ? 'crouch' : 'idle';
    else if (len > 0) anim = isSprinting ? 'run' : 'walk';
    if (emoteLock) anim = currentEmote;
    // Animação de arremesso tem prioridade
    if (playerMesh.userData.throwAnim) anim = 'throw';
    currentAnim = anim;
    window.Avatar.animateAvatar(playerMesh, anim, performance.now() / 1000, delta);
  }

  // === Câmera (PRIMEIRA PESSOA) ===
  // Head bob e weapon sway
  const isMoving = len > 0 && isGrounded;
  if (isMoving) {
    bobTimer += delta * (isSprinting ? 14 : 8);
  } else {
    bobTimer *= 0.9;
  }
  const bobY = isMoving ? Math.sin(bobTimer) * 0.04 : 0;
  const bobX = isMoving ? Math.cos(bobTimer * 0.5) * 0.03 : 0;

  if (fpMode) {
    camera.position.set(pos.x + bobX, pos.y + 0.6 + bobY, pos.z);
    const euler = new THREE.Euler(pitch, yaw, 0, 'YXZ');
    camera.quaternion.setFromEuler(euler);
    // Aplica sway na arma em 1a pessoa
    if (window.Weapon && window.Weapon.getFirstPersonWeapon) {
      const wpn = window.Weapon.getFirstPersonWeapon();
      if (wpn) {
        weaponSway.x *= 0.9;
        weaponSway.y *= 0.9;
        wpn.position.x = 0.25 - weaponSway.x;
        wpn.position.y = -0.25 - weaponSway.y + bobY * 0.5;
        wpn.position.z = -0.5;
      }
    }
  } else {
    const targetPos = new THREE.Vector3(pos.x, pos.y + (isCrouching ? 0.8 : 1.2), pos.z);
    const offset = new THREE.Vector3(
      Math.sin(yaw) * Math.cos(pitch) * cameraDistance,
      Math.sin(pitch) * cameraDistance + 0.5,
      Math.cos(yaw) * Math.cos(pitch) * cameraDistance
    );
    camera.position.set(targetPos.x + offset.x, targetPos.y - offset.y + cameraDistance * 0.5, targetPos.z + offset.z);
    camera.lookAt(targetPos.x, targetPos.y + 0.3, targetPos.z);
  }

  // === Dano por queda ===
  if (pos.y < -30) {
    takeDamage(100, 'void');
    respawn();
  }
  if (damageCooldown > 0) damageCooldown -= delta;
}

function getHealth() { return health; }

function takeDamage(amount, source) {
  if (damageCooldown > 0 && amount < 50) return;
  health -= amount;
  damageCooldown = 0.5;
  if (window.UI) window.UI.updateHealth(health);
  if (window.UI) window.UI.flashDamage();
  if (health <= 0) {
    health = 0;
    die(source);
  }
}

function heal(amount) {
  health = Math.min(100, health + amount);
  if (window.UI) window.UI.updateHealth(health);
}

function die(source) {
  if (window.UI) window.UI.addNotification(`Você morreu (${source || 'desconhecido'})`, 'error');
  if (window.Chat) window.Chat.addSystem(`Você morreu.`);
  setTimeout(() => respawn(), 1500);
}

function respawn() {
  health = 100;
  if (playerBody) {
    playerBody.position.set(respawnPoint.x, respawnPoint.y, respawnPoint.z);
    playerBody.velocity.set(0, 0, 0);
  }
  if (window.UI) window.UI.updateHealth(100);
}

function setRespawnPoint(v) { respawnPoint.copy(v); }
function setWaterLevel(y) { waterLevel = y; }
function addClimbable(mesh, radius) { mesh.userData.climbRadius = radius || 1.5; climbObjects.push(mesh); }
function addInteractable(mesh, action, label) { interactables.push({ mesh, action, label }); }

function getNetworkState() {
  if (!playerBody) return { x: 0, y: 0, z: 0, rx: 0, ry: 0, rz: 0, anim: 'idle', weapon: null, health: 100, state: 'alive' };
  return {
    x: playerBody.position.x, y: playerBody.position.y, z: playerBody.position.z,
    rx: pitch, ry: yaw, rz: 0,
    anim: currentAnim,
    weapon: window.Weapon ? window.Weapon.getCurrentWeaponId() : null,
    health: health,
    state: health > 0 ? 'alive' : 'dead'
  };
}

function getPosition() {
  if (!playerBody) return new THREE.Vector3();
  return new THREE.Vector3(playerBody.position.x, playerBody.position.y, playerBody.position.z);
}

function getCameraDirection() {
  const dir = new THREE.Vector3();
  camera.getWorldDirection(dir);
  return dir;
}

function getCameraPosition() { return camera.position.clone(); }

function playEmoteLocal(emote) {
  emoteLock = true;
  currentEmote = emote;
  const durations = { wave: 3000, dance: 5000, sit: 30000, point: 2000, laugh: 3000, sleep: 30000 };
  setTimeout(() => { emoteLock = false; }, durations[emote] || 3000);
  if (window.Network) {
    window.Network.broadcast({ type: 'emote', id: window.PeerAPI.getMyId(), emote: emote });
  }
}

function resetPlayer() {
  if (playerBody && window.Physics) window.Physics.getWorld().removeBody(playerBody);
  if (playerMesh && playerMesh.parent) playerMesh.parent.remove(playerMesh);
  if (window.Avatar) window.Avatar.disposeAvatar(playerMesh);
  playerBody = null; playerMesh = null;
  climbObjects = []; interactables = [];
  health = 100;
}

window.Player = {
  init: PlayerInit,
  update: PlayerUpdate,
  getHealth, takeDamage, heal, respawn,
  setRespawnPoint, setWaterLevel, addClimbable, addInteractable,
  getNetworkState, getPosition, getCameraDirection, getCameraPosition,
  getPlayerMesh: () => playerMesh,
  playEmote: playEmoteLocal,
  reset: resetPlayer,
  toggleCameraMode,
  isFP: () => fpMode,
  getYaw: () => yaw,
  getPitch: () => pitch,
  isGrounded: () => isGrounded
};
})();
