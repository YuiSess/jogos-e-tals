// ============================================================
// network.js — Protocolo de rede 20Hz
// ============================================================
(function() {
'use strict';

const NET_RATE = 20;
const NET_INTERVAL = 1000 / NET_RATE;
let lastNetSend = 0;
let remotePlayers = new Map();

function createRemotePlayerState(peerId, info) {
  return {
    peerId,
    name: info.name || 'Jogador',
    info: info,
    mesh: null,
    targetPos: new THREE.Vector3(),
    targetRot: new THREE.Euler(),
    currentPos: new THREE.Vector3(),
    currentRot: new THREE.Euler(),
    lastUpdate: performance.now(),
    animState: 'idle',
    equippedWeapon: null,
    health: 100,
    playerState: 'alive',
    accessories: [],
    skin: null
  };
}

function NetworkReceive(data, fromId) {
  if (!data || !data.type) return;

  switch (data.type) {
    case 'lobby': {
      if (window.GameState) {
        window.GameState.hostId = data.hostId;
        window.GameState.roomName = data.roomName;
        window.GameState.map = data.map;
      }
      if (window.UI) window.UI.onLobbyJoined(data);
      break;
    }
    case 'join': {
      if (data.id === window.PeerAPI.getMyId()) return;
      if (!remotePlayers.has(data.id)) {
        const state = createRemotePlayerState(data.id, { name: data.name });
        remotePlayers.set(data.id, state);
        if (window.Avatar) {
          state.mesh = window.Avatar.createRemoteAvatar(data.name);
          if (window.GameState && window.GameState.scene) {
            window.GameState.scene.add(state.mesh);
          }
        }
        if (window.UI) window.UI.addNotification(`${data.name} entrou na sala`, 'info');
        if (window.Chat) window.Chat.addSystem(`${data.name} entrou na sala`);
      }
      sendHello(data.id);
      break;
    }
    case 'hello': {
      if (data.id === window.PeerAPI.getMyId()) return;
      let rp = remotePlayers.get(data.id);
      if (!rp) {
        rp = createRemotePlayerState(data.id, { name: data.name });
        remotePlayers.set(data.id, rp);
        if (window.Avatar) {
          rp.mesh = window.Avatar.createRemoteAvatar(data.name);
          if (window.GameState && window.GameState.scene) {
            window.GameState.scene.add(rp.mesh);
          }
        }
      }
      rp.name = data.name;
      rp.skin = data.skin;
      rp.accessories = data.accessories || [];
      rp.equippedWeapon = data.equippedWeapon;
      rp.health = data.health;
      rp.playerState = data.playerState;
      if (window.Avatar && rp.mesh) {
        window.Avatar.applyCustomization(rp.mesh, data.skin, data.accessories);
      }
      break;
    }
    case 'player': {
      if (data.id === window.PeerAPI.getMyId()) return;
      let rp = remotePlayers.get(data.id);
      if (!rp) { sendHello(data.id); return; }
      rp.targetPos.set(data.x, data.y, data.z);
      rp.targetRot.set(data.rx, data.ry, data.rz);
      rp.animState = data.anim;
      rp.equippedWeapon = data.weapon;
      rp.health = data.health;
      rp.playerState = data.state;
      rp.lastUpdate = performance.now();
      if (window.Avatar && rp.mesh) {
        window.Avatar.setRemoteWeapon(rp.mesh, data.weapon);
        window.Avatar.setRemoteAnimation(rp.mesh, data.anim);
      }
      if (window.Avatar) window.Avatar.updateRemoteInfo(rp);
      break;
    }
    case 'chat': { if (window.Chat) window.Chat.receiveMessage(data); break; }
    case 'build': { if (window.Builder) window.Builder.receiveBuild(data); break; }
    case 'equip': {
      let rp = remotePlayers.get(data.id);
      if (rp) {
        rp.equippedWeapon = data.weapon;
        if (window.Avatar && rp.mesh) window.Avatar.setRemoteWeapon(rp.mesh, data.weapon);
      }
      break;
    }
    case 'shoot': {
      if (window.Weapon) window.Weapon.receiveRemoteShot(data);
      if (window.Effects) window.Effects.createMuzzleFlash(data.ox, data.oy, data.oz, data.dx, data.dy, data.dz);
      break;
    }
    case 'hit': {
      if (data.target === window.PeerAPI.getMyId()) {
        if (window.Player) window.Player.takeDamage(data.damage, data.shooter);
      }
      break;
    }
    case 'emote': {
      let rp = remotePlayers.get(data.id);
      if (rp && window.Avatar && rp.mesh) {
        window.Avatar.playEmote(rp.mesh, data.emote);
      }
      break;
    }
    case 'new_peer': {
      if (data.id && data.id !== window.PeerAPI.getMyId()) {
        if (!window.PeerAPI.getConnectedPeerIds().includes(data.id)) {
          console.log('[NET] Conectando ao novo peer:', data.id);
          window.PeerAPI.connect(data.id);
        }
      }
      break;
    }
    case 'leave': { removeRemotePlayer(data.id, data.name); break; }
    case 'ball': { if (window.GameMode) window.GameMode.receiveBall(data); break; }
    case 'mode': {
      if (window.GameMode) window.GameMode.receiveMode(data);
      NetworkExtraHandler(data, fromId);
      break;
    }
    case 'voice_offer':
    case 'voice_answer':
    case 'voice_ice': {
      if (window.VoiceChat) window.VoiceChat.handleSignaling(data, fromId);
      break;
    }
  }
}

// Processa mensagens específicas de modo que precisam de lógica do network
function NetworkExtraHandler(data, fromId) {
  if (data.type === 'mode' && data.action === 'request_team') {
    // Host recebe pedido de time e atribui
    if (window.PeerAPI && window.PeerAPI.isHost() && window.GameMode) {
      window.GameMode.assignTeam(data.peerId, data.team);
    }
  }
}

function sendHello(targetId) {
  const data = {
    type: 'hello',
    id: window.PeerAPI.getMyId(),
    name: (window.Save ? window.Save.getPlayerName() : 'Jogador'),
    skin: window.Save ? window.Save.getAvatar() : null,
    accessories: window.Save ? window.Save.getAccessories() : [],
    equippedWeapon: window.Weapon ? window.Weapon.getCurrentWeaponId() : null,
    health: window.Player ? window.Player.getHealth() : 100,
    playerState: 'alive'
  };
  window.PeerAPI.sendTo(targetId, data);
}

function sendLeave() {
  window.PeerAPI.broadcast({
    type: 'leave',
    id: window.PeerAPI.getMyId(),
    name: (window.Save ? window.Save.getPlayerName() : 'Jogador')
  });
}

function removeRemotePlayer(peerId, name) {
  const rp = remotePlayers.get(peerId);
  if (rp) {
    if (rp.mesh && rp.mesh.parent) rp.mesh.parent.remove(rp.mesh);
    if (window.Avatar) window.Avatar.disposeAvatar(rp.mesh);
    remotePlayers.delete(peerId);
    if (window.UI) window.UI.addNotification(`${name || 'Jogador'} saiu`, 'warn');
    if (window.Chat) window.Chat.addSystem(`${name || 'Jogador'} saiu da sala`);
  }
}

function NetworkUpdate(now) {
  if (now - lastNetSend < NET_INTERVAL) return;
  lastNetSend = now;
  if (!window.PeerAPI || window.PeerAPI.getConnectedPeerIds().length === 0) return;
  if (!window.Player) return;
  const p = window.Player.getNetworkState();
  window.PeerAPI.broadcast({
    type: 'player',
    id: window.PeerAPI.getMyId(),
    x: p.x, y: p.y, z: p.z,
    rx: p.rx, ry: p.ry, rz: p.rz,
    anim: p.anim, weapon: p.weapon,
    health: p.health, state: p.state
  });
}

function NetworkInterpolate(delta) {
  const now = performance.now();
  const t = now / 1000;
  for (const [id, rp] of remotePlayers) {
    if (!rp.mesh) continue;
    if (now - rp.lastUpdate > 10000) { removeRemotePlayer(id, rp.name); continue; }
    const lerpFactor = Math.min(1, delta * 10);
    rp.currentPos.lerp(rp.targetPos, lerpFactor);
    rp.mesh.position.copy(rp.currentPos);
    const drx = wrapAngle(rp.targetRot.x - rp.currentRot.x);
    const dry = wrapAngle(rp.targetRot.y - rp.currentRot.y);
    const drz = wrapAngle(rp.targetRot.z - rp.currentRot.z);
    rp.currentRot.x += drx * lerpFactor;
    rp.currentRot.y += dry * lerpFactor;
    rp.currentRot.z += drz * lerpFactor;
    rp.mesh.rotation.copy(rp.currentRot);
    if (window.Avatar) {
      let anim = rp.mesh.userData.emoteLock ? rp.mesh.userData.emote : rp.animState;
      // Animação de arremesso tem prioridade
      if (rp.mesh.userData.throwAnim) anim = 'throw';
      window.Avatar.animateAvatar(rp.mesh, anim || 'idle', t, delta);
    }
  }
}

function wrapAngle(a) {
  while (a > Math.PI) a -= Math.PI * 2;
  while (a < -Math.PI) a += Math.PI * 2;
  return a;
}

function ClearAllRemotePlayers() {
  for (const [id, rp] of remotePlayers) {
    if (rp.mesh && rp.mesh.parent) rp.mesh.parent.remove(rp.mesh);
    if (window.Avatar) window.Avatar.disposeAvatar(rp.mesh);
  }
  remotePlayers.clear();
}

window.Network = {
  init: (cb) => {
    cb = cb || {};
    window.PeerAPI.init({
      onOpen: cb.onOpen,
      onError: cb.onError,
      onDisconnected: cb.onDisconnected,
      onData: NetworkReceive,
      onPeerJoined: cb.onPeerJoined,
      onPeerLeft: cb.onPeerLeft
    });
  },
  connect: (hostId) => window.PeerAPI.connect(hostId),
  receive: NetworkReceive,
  update: NetworkUpdate,
  interpolate: NetworkInterpolate,
  broadcast: (data) => window.PeerAPI.broadcast(data),
  sendTo: (peerId, data) => window.PeerAPI.sendTo(peerId, data),
  sendLeave,
  getRemotePlayers: () => remotePlayers,
  getRemotePlayer: (id) => remotePlayers.get(id),
  clearAll: ClearAllRemotePlayers,
  removeRemotePlayer
};
})();
