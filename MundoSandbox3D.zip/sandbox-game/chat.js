// ============================================================
// chat.js — Global e por proximidade
// ============================================================
(function() {
'use strict';

let chatOpen = false;
const PROXIMITY_RANGE = 20;

function ChatInit() {
  const input = document.getElementById('chatInput');
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const text = input.value.trim();
      if (text) sendMessage(text);
      input.value = '';
      closeChat();
    } else if (e.key === 'Escape') {
      input.value = ''; closeChat();
    }
    e.stopPropagation();
  });
  input.addEventListener('focus', () => {
    if (document.exitPointerLock) document.exitPointerLock();
  });
}

function toggle() {
  if (chatOpen) closeChat();
  else openChat();
}

function openChat() {
  chatOpen = true;
  const box = document.getElementById('chatBox');
  const input = document.getElementById('chatInput');
  box.classList.remove('hidden');
  input.focus();
}

function closeChat() {
  chatOpen = false;
  const input = document.getElementById('chatInput');
  input.blur();
}

function sendMessage(text) {
  let mode = 'global';
  let msg = text;
  if (text.startsWith('/p ') || text.startsWith('/prox ')) {
    mode = 'proximity';
    msg = text.replace(/^\/(p|prox)\s+/, '');
  } else if (text.startsWith('/g ') || text.startsWith('/global ')) {
    mode = 'global';
    msg = text.replace(/^\/(g|global)\s+/, '');
  }
  const myName = window.Save ? window.Save.getPlayerName() : 'Jogador';
  const data = { type: 'chat', mode, name: myName, text: msg, id: window.PeerAPI.getMyId() };
  receiveMessage(data);
  if (window.Network) window.Network.broadcast(data);
}

function receiveMessage(data) {
  if (data.mode === 'proximity') {
    if (window.Player && window.Network) {
      const myPos = window.Player.getPosition();
      const rp = window.Network.getRemotePlayer(data.id);
      if (rp && rp.mesh) {
        const dist = rp.mesh.position.distanceTo(myPos);
        if (dist > PROXIMITY_RANGE) return;
      }
    }
  }
  addMessage(data.name, data.text, data.mode);
}

function addMessage(name, text, mode) {
  mode = mode || 'global';
  const div = document.getElementById('chatMessages');
  if (!div) return;
  const msg = document.createElement('div');
  msg.className = 'chat-msg' + (mode === 'proximity' ? ' proximity' : '') + (name === 'Sistema' ? ' system' : '');
  if (name === 'Sistema') msg.innerHTML = `<span class="name">⚙</span> ${escapeHtml(text)}`;
  else msg.innerHTML = `<span class="name">${escapeHtml(name)}:</span> ${escapeHtml(text)}`;
  div.appendChild(msg);
  div.scrollTop = div.scrollHeight;
  while (div.children.length > 50) div.removeChild(div.firstChild);
}

function addSystem(text) { addMessage('Sistema', text, 'global'); }

function escapeHtml(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

window.Chat = { init: ChatInit, toggle, receiveMessage, addSystem, addMessage };
})();
