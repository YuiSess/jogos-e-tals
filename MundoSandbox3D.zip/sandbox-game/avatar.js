// ============================================================
// avatar.js — Avatar humanoide detalhado (corpo bonito)
// ============================================================
(function() {
'use strict';

let avatarPreviewScene = null;
let avatarPreviewCamera = null;
let avatarPreviewRenderer = null;
let avatarPreviewMesh = null;
let avatarPreviewAnim = 0;

const HAIR_STYLES = ['short', 'long', 'spiky', 'bald', 'mohawk', 'ponytail', 'afro', 'bun'];
const CLOTHES = ['tshirt', 'hoodie', 'suit', 'tank', 'jacket', 'armor', 'kimono'];
const SHOES = ['sneakers', 'boots', 'sandals', 'bare', 'heels'];
const HATS = [null, 'cap', 'helmet', 'tophat', 'beanie', 'crown', 'cowboy', 'wizard'];
const GLASSES = [null, 'sunglasses', 'round', 'vr', 'visor', 'cyber'];
const MASKS = [null, 'clown', 'ninja', 'cyborg', 'skull', 'samurai', 'gas'];
const BACKS = [null, 'backpack', 'wings', 'cape', 'jetpack', 'shield', 'halo'];

const CHARACTER_TYPES = ['human', 'skeleton', 'robot', 'ninja', 'zombie', 'alien', 'wizard'];

const COLORS = ['#ffcc99','#f5cba7','#e8b796','#d4a373','#a87c5f','#7d5233','#5c3a21',
  '#3b82f6','#ef4444','#10b981','#fbbf24','#a855f7','#ec4899','#0f172a','#ffffff','#6b7280',
  '#06b6d4','#84cc16','#f97316','#dc2626'];

// ===== Constrói avatar detalhado =====
function buildAvatarMesh(customization, accessories) {
  const c = customization || {};
  const a = accessories || {};
  const group = new THREE.Group();
  const charType = c.characterType || 'human';

  // Delega para o construtor específico do personagem
  if (charType === 'skeleton') return buildSkeleton(c, a);
  if (charType === 'robot') return buildRobot(c, a);
  if (charType === 'ninja') return buildNinja(c, a);
  if (charType === 'zombie') return buildZombie(c, a);
  if (charType === 'alien') return buildAlien(c, a);
  if (charType === 'wizard') return buildWizard(c, a);

  // Humano padrão (código existente)
  const skinMat = new THREE.MeshStandardMaterial({
    color: c.headColor || '#ffcc99',
    roughness: 0.7, metalness: 0.05
  });

  // === HEAD (esfera achatada) ===
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.28, 24, 20),
    skinMat
  );
  head.position.y = 1.72;
  head.scale.set(0.95, 1.05, 0.95);
  head.name = 'head';
  head.castShadow = true;
  group.add(head);

  // Pescoço
  const neck = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.13, 0.15, 12),
    skinMat
  );
  neck.position.y = 1.45;
  group.add(neck);

  // Orelhas
  const earGeom = new THREE.SphereGeometry(0.06, 8, 8);
  const leftEar = new THREE.Mesh(earGeom, skinMat);
  leftEar.position.set(-0.25, 1.72, 0);
  leftEar.scale.set(0.4, 1, 0.7);
  const rightEar = leftEar.clone();
  rightEar.position.x = 0.25;
  group.add(leftEar, rightEar);

  // Olhos (esfera branca + pupila preta + brilho)
  const eyeWhiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
  const eyeGeom = new THREE.SphereGeometry(0.05, 12, 10);
  const leftEye = new THREE.Mesh(eyeGeom, eyeWhiteMat);
  leftEye.position.set(-0.11, 1.76, 0.23);
  leftEye.scale.set(1, 0.8, 0.6);
  const rightEye = leftEye.clone();
  rightEye.position.x = 0.11;
  group.add(leftEye, rightEye);

  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
  const pupilGeom = new THREE.SphereGeometry(0.025, 8, 6);
  const leftPupil = new THREE.Mesh(pupilGeom, pupilMat);
  leftPupil.position.set(-0.11, 1.76, 0.27);
  const rightPupil = leftPupil.clone();
  rightPupil.position.x = 0.11;
  group.add(leftPupil, rightPupil);

  // Sobrancelhas
  const browMat = new THREE.MeshStandardMaterial({ color: c.hairColor || 0x3a2a1a });
  const browGeom = new THREE.BoxGeometry(0.1, 0.015, 0.02);
  const leftBrow = new THREE.Mesh(browGeom, browMat);
  leftBrow.position.set(-0.11, 1.84, 0.25);
  leftBrow.rotation.z = 0.1;
  const rightBrow = leftBrow.clone();
  rightBrow.position.x = 0.11;
  rightBrow.rotation.z = -0.1;
  group.add(leftBrow, rightBrow);

  // Nariz
  const nose = new THREE.Mesh(
    new THREE.ConeGeometry(0.04, 0.12, 6),
    skinMat
  );
  nose.position.set(0, 1.7, 0.28);
  nose.rotation.x = Math.PI / 2;
  group.add(nose);

  // Boca (sorriso)
  const mouth = new THREE.Mesh(
    new THREE.TorusGeometry(0.06, 0.012, 6, 12, Math.PI),
    new THREE.MeshStandardMaterial({ color: 0xaa3344, roughness: 0.5 })
  );
  mouth.position.set(0, 1.6, 0.25);
  mouth.rotation.z = Math.PI;
  group.add(mouth);

  applyHair(group, c.hairStyle || 'short', c.hairColor || '#3a2a1a');

  // === TORSO (caixa arredondada com curvas) ===
  const torsoGeo = new THREE.CapsuleGeometry(0.28, 0.45, 8, 16);
  const torsoMat = new THREE.MeshStandardMaterial({
    color: c.clothesColor || '#3b82f6',
    roughness: 0.6, metalness: 0.1
  });
  const torso = new THREE.Mesh(torsoGeo, torsoMat);
  torso.position.y = 1.05;
  torso.scale.set(1, 0.95, 0.85);
  torso.name = 'torso';
  torso.castShadow = true;
  group.add(torso);
  applyClothesPattern(group, c.clothes || 'tshirt', c);

  // Ombros (esferas)
  const shoulderGeom = new THREE.SphereGeometry(0.13, 12, 10);
  const leftShoulder = new THREE.Mesh(shoulderGeom, skinMat);
  leftShoulder.position.set(-0.32, 1.35, 0);
  const rightShoulder = leftShoulder.clone();
  rightShoulder.position.x = 0.32;
  group.add(leftShoulder, rightShoulder);

  // === BRAÇOS (cilindros) ===
  const armMat = new THREE.MeshStandardMaterial({
    color: c.armsColor || '#ffcc99',
    roughness: 0.7
  });
  // Pivot para rotação do braço
  const leftArmGroup = new THREE.Group();
  leftArmGroup.name = 'leftArm';
  leftArmGroup.position.set(-0.4, 1.35, 0);
  // Braço superior
  const upperArm = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.08, 0.35, 6, 12),
    armMat
  );
  upperArm.position.y = -0.2;
  upperArm.castShadow = true;
  leftArmGroup.add(upperArm);
  // Cotovelo
  const elbow = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), armMat);
  elbow.position.y = -0.4;
  leftArmGroup.add(elbow);
  // Antebraço
  const forearm = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.07, 0.3, 6, 12),
    armMat
  );
  forearm.position.y = -0.6;
  leftArmGroup.add(forearm);
  // Mão
  const hand = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.15, 0.05), skinMat);
  hand.position.y = -0.82;
  leftArmGroup.add(hand);
  group.add(leftArmGroup);

  const rightArmGroup = leftArmGroup.clone();
  rightArmGroup.name = 'rightArm';
  rightArmGroup.position.x = 0.4;
  group.add(rightArmGroup);

  // === PERNAS (cilindros) ===
  const legMat = new THREE.MeshStandardMaterial({
    color: c.legsColor || '#1e293b',
    roughness: 0.7
  });
  const leftLegGroup = new THREE.Group();
  leftLegGroup.name = 'leftLeg';
  leftLegGroup.position.set(-0.15, 0.85, 0);
  // Coxa
  const thigh = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.12, 0.35, 6, 12),
    legMat
  );
  thigh.position.y = -0.2;
  thigh.castShadow = true;
  leftLegGroup.add(thigh);
  // Joelho
  const knee = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), legMat);
  knee.position.y = -0.4;
  leftLegGroup.add(knee);
  // Canela
  const shin = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.1, 0.3, 6, 12),
    legMat
  );
  shin.position.y = -0.6;
  leftLegGroup.add(shin);
  group.add(leftLegGroup);

  const rightLegGroup = leftLegGroup.clone();
  rightLegGroup.name = 'rightLeg';
  rightLegGroup.position.x = 0.15;
  group.add(rightLegGroup);

  applyShoes(group, c.shoes || 'sneakers', c.shoesColor || '#0f172a');
  applyHat(group, a.hat);
  applyGlasses(group, a.glasses);
  applyMask(group, a.mask);
  applyBack(group, a.back);

  // Nome + barra de vida
  const nameSprite = createNameSprite('');
  nameSprite.position.set(0, 2.25, 0);
  nameSprite.name = 'nameSprite';
  group.add(nameSprite);

  const healthBar = createHealthBar();
  healthBar.position.set(0, 2.05, 0);
  healthBar.name = 'healthBar';
  group.add(healthBar);

  group.userData.type = 'avatar';
  return group;
}

// ============================================================
// PERSONAGENS ESPECIAIS
// ============================================================

// Helper para criar avatar base com estrutura humanoide
function buildBaseAvatar(skinMat, bodyMat, legMat) {
  const group = new THREE.Group();

  // HEAD
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 24, 20), skinMat);
  head.position.y = 1.72;
  head.scale.set(0.95, 1.05, 0.95);
  head.name = 'head';
  head.castShadow = true;
  group.add(head);

  // Pescoço
  const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.13, 0.15, 12), skinMat);
  neck.position.y = 1.45;
  group.add(neck);

  // Orelhas
  const earGeom = new THREE.SphereGeometry(0.06, 8, 8);
  const leftEar = new THREE.Mesh(earGeom, skinMat);
  leftEar.position.set(-0.25, 1.72, 0);
  leftEar.scale.set(0.4, 1, 0.7);
  const rightEar = leftEar.clone();
  rightEar.position.x = 0.25;
  group.add(leftEar, rightEar);

  // Olhos
  const eyeWhiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.3 });
  const eyeGeom = new THREE.SphereGeometry(0.05, 12, 10);
  const leftEye = new THREE.Mesh(eyeGeom, eyeWhiteMat);
  leftEye.position.set(-0.11, 1.76, 0.23);
  leftEye.scale.set(1, 0.8, 0.6);
  const rightEye = leftEye.clone();
  rightEye.position.x = 0.11;
  group.add(leftEye, rightEye);

  // Pupilas
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x111111 });
  const pupilGeom = new THREE.SphereGeometry(0.025, 8, 6);
  const leftPupil = new THREE.Mesh(pupilGeom, pupilMat);
  leftPupil.position.set(-0.11, 1.76, 0.27);
  const rightPupil = leftPupil.clone();
  rightPupil.position.x = 0.11;
  group.add(leftPupil, rightPupil);

  // TORSO
  const torsoGeo = new THREE.CapsuleGeometry(0.28, 0.45, 8, 16);
  const torso = new THREE.Mesh(torsoGeo, bodyMat);
  torso.position.y = 1.05;
  torso.scale.set(1, 0.95, 0.85);
  torso.name = 'torso';
  torso.castShadow = true;
  group.add(torso);

  // Ombros
  const shoulderGeom = new THREE.SphereGeometry(0.13, 12, 10);
  const leftShoulder = new THREE.Mesh(shoulderGeom, skinMat);
  leftShoulder.position.set(-0.32, 1.35, 0);
  const rightShoulder = leftShoulder.clone();
  rightShoulder.position.x = 0.32;
  group.add(leftShoulder, rightShoulder);

  // BRAÇOS
  const armMat = skinMat;
  const leftArmGroup = new THREE.Group();
  leftArmGroup.name = 'leftArm';
  leftArmGroup.position.set(-0.4, 1.35, 0);
  const upperArm = new THREE.Mesh(new THREE.CapsuleGeometry(0.08, 0.35, 6, 12), armMat);
  upperArm.position.y = -0.2;
  upperArm.castShadow = true;
  leftArmGroup.add(upperArm);
  const elbow = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), armMat);
  elbow.position.y = -0.4;
  leftArmGroup.add(elbow);
  const forearm = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.3, 6, 12), armMat);
  forearm.position.y = -0.6;
  leftArmGroup.add(forearm);
  const hand = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.15, 0.05), skinMat);
  hand.position.y = -0.82;
  leftArmGroup.add(hand);
  group.add(leftArmGroup);

  const rightArmGroup = leftArmGroup.clone();
  rightArmGroup.name = 'rightArm';
  rightArmGroup.position.x = 0.4;
  group.add(rightArmGroup);

  // PERNAS
  const leftLegGroup = new THREE.Group();
  leftLegGroup.name = 'leftLeg';
  leftLegGroup.position.set(-0.15, 0.85, 0);
  const thigh = new THREE.Mesh(new THREE.CapsuleGeometry(0.12, 0.35, 6, 12), legMat);
  thigh.position.y = -0.2;
  thigh.castShadow = true;
  leftLegGroup.add(thigh);
  const knee = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), legMat);
  knee.position.y = -0.4;
  leftLegGroup.add(knee);
  const shin = new THREE.Mesh(new THREE.CapsuleGeometry(0.1, 0.3, 6, 12), legMat);
  shin.position.y = -0.6;
  leftLegGroup.add(shin);
  group.add(leftLegGroup);

  const rightLegGroup = leftLegGroup.clone();
  rightLegGroup.name = 'rightLeg';
  rightLegGroup.position.x = 0.15;
  group.add(rightLegGroup);

  // Nome + barra de vida
  const nameSprite = createNameSprite('');
  nameSprite.position.set(0, 2.25, 0);
  nameSprite.name = 'nameSprite';
  group.add(nameSprite);

  const healthBar = createHealthBar();
  healthBar.position.set(0, 2.05, 0);
  healthBar.name = 'healthBar';
  group.add(healthBar);

  group.userData.type = 'avatar';
  return group;
}

// ===== ESQUELETO =====
function buildSkeleton(c, a) {
  const boneMat = new THREE.MeshStandardMaterial({ color: 0xeeeeee, roughness: 0.6 });
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.8 });
  const group = buildBaseAvatar(boneMat, darkMat, darkMat);

  // Crânio (substitui a cabeça lisa)
  const skull = group.getObjectByName('head');
  skull.material = boneMat;
  skull.scale.set(1, 1.1, 0.95);

  // Órbitas oculares (buracos pretos)
  const eyeSocketMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
  const leftSocket = new THREE.Mesh(new THREE.SphereGeometry(0.07, 8, 8), eyeSocketMat);
  leftSocket.position.set(-0.11, 1.78, 0.22);
  leftSocket.scale.set(1, 0.8, 0.5);
  const rightSocket = leftSocket.clone();
  rightSocket.position.x = 0.11;
  group.add(leftSocket, rightSocket);

  // Brilho vermelho nos olhos
  const eyeGlowMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });
  const leftGlow = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), eyeGlowMat);
  leftGlow.position.set(-0.11, 1.78, 0.25);
  const rightGlow = leftGlow.clone();
  rightGlow.position.x = 0.11;
  group.add(leftGlow, rightGlow);

  // Dentes (fileira)
  for (let i = 0; i < 6; i++) {
    const tooth = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.05, 0.02), boneMat);
    tooth.position.set(-0.075 + i * 0.03, 1.6, 0.24);
    group.add(tooth);
  }

  // Costelas (no peito)
  for (let i = 0; i < 4; i++) {
    const rib = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.015, 6, 12, Math.PI), boneMat);
    rib.position.set(0, 1.2 - i * 0.15, 0.15);
    rib.rotation.x = Math.PI / 2;
    group.add(rib);
  }

  // Coluna vertebral
  for (let i = 0; i < 5; i++) {
    const vertebra = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.06, 8), boneMat);
    vertebra.position.set(0, 1.3 - i * 0.12, -0.15);
    group.add(vertebra);
  }

  // Aplica acessórios
  applyHat(group, a.hat);
  applyBack(group, a.back);

  return group;
}

// ===== ROBÔ =====
function buildRobot(c, a) {
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x888899, metalness: 0.9, roughness: 0.2 });
  const darkMetalMat = new THREE.MeshStandardMaterial({ color: 0x333344, metalness: 0.8, roughness: 0.3 });
  const group = buildBaseAvatar(metalMat, metalMat, darkMetalMat);

  // Cabeça mais quadrada
  const head = group.getObjectByName('head');
  head.geometry.dispose();
  head.geometry = new THREE.BoxGeometry(0.45, 0.45, 0.45);
  head.scale.set(1, 1, 1);

  // Antena
  const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.25, 6), darkMetalMat);
  antenna.position.set(0.12, 2.05, 0);
  group.add(antenna);
  const antennaTip = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xff0000 }));
  antennaTip.position.set(0.12, 2.18, 0);
  group.add(antennaTip);

  // Olhos LED (vermelhos brilhantes)
  const ledMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });
  const ledGeom = new THREE.BoxGeometry(0.08, 0.04, 0.02);
  const leftLed = new THREE.Mesh(ledGeom, ledMat);
  leftLed.position.set(-0.1, 1.75, 0.23);
  const rightLed = leftLed.clone();
  rightLed.position.x = 0.1;
  group.add(leftLed, rightLed);

  // Boca grade
  for (let i = 0; i < 4; i++) {
    const grille = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.02, 0.02), darkMetalMat);
    grille.position.set(-0.06 + i * 0.04, 1.6, 0.23);
    group.add(grille);
  }

  // Botões no peito
  const buttonColors = [0xff0000, 0x00ff00, 0x0000ff, 0xffff00];
  for (let i = 0; i < 4; i++) {
    const button = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.02, 8),
      new THREE.MeshBasicMaterial({ color: buttonColors[i] }));
    button.position.set(-0.1 + i * 0.07, 1.15, 0.22);
    button.rotation.x = Math.PI / 2;
    group.add(button);
  }

  // Juntas visíveis (cotovelos e joelhos mais escuros)
  applyHat(group, a.hat);
  applyBack(group, a.back);

  return group;
}

// ===== NINJA =====
function buildNinja(c, a) {
  const suitMat = new THREE.MeshStandardMaterial({ color: 0x1a1a2e, roughness: 0.7 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xf5cba7, roughness: 0.7 });
  const group = buildBaseAvatar(skinMat, suitMat, suitMat);

  // Máscara ninja cobrindo rosto (deixando só olhos)
  const mask = new THREE.Mesh(new THREE.SphereGeometry(0.27, 16, 12, 0, Math.PI*2, 0, Math.PI*0.7),
    suitMat);
  mask.position.set(0, 1.7, 0.05);
  mask.scale.set(1, 0.9, 1);
  group.add(mask);

  // Faixa vermelha na cabeça
  const headband = new THREE.Mesh(new THREE.TorusGeometry(0.26, 0.03, 8, 16), 
    new THREE.MeshStandardMaterial({ color: 0xaa0000 }));
  headband.position.set(0, 1.85, 0);
  headband.rotation.x = Math.PI / 2;
  group.add(headband);

  // Faixa nas costas (símbolo)
  const tail = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 0.4),
    new THREE.MeshStandardMaterial({ color: 0xaa0000, side: THREE.DoubleSide }));
  tail.position.set(0, 1.8, -0.25);
  group.add(tail);

  // Katana nas costas
  const katana = new THREE.Mesh(new THREE.BoxGeometry(0.04, 1.0, 0.02),
    new THREE.MeshStandardMaterial({ color: 0xaaaaaa, metalness: 0.9 }));
  katana.position.set(0.1, 1.4, -0.2);
  katana.rotation.z = 0.3;
  group.add(katana);

  // Cabo da katana
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.2, 8),
    new THREE.MeshStandardMaterial({ color: 0x000000 }));
  handle.position.set(0.25, 1.7, -0.2);
  handle.rotation.z = 0.3;
  group.add(handle);

  applyHat(group, a.hat);
  applyBack(group, a.back);

  return group;
}

// ===== ZUMBI =====
function buildZombie(c, a) {
  const skinMat = new THREE.MeshStandardMaterial({ color: 0x6a8a4a, roughness: 0.9 });
  const clothMat = new THREE.MeshStandardMaterial({ color: 0x3a3a2a, roughness: 0.9 });
  const group = buildBaseAvatar(skinMat, clothMat, clothMat);

  // Olhos amarelos brilhantes
  const leftPupil = group.getObjectByName('leftPupil') || group.children.find(ch => ch.position.y > 1.7 && ch.position.y < 1.8 && ch.material && ch.material.color && ch.material.color.r === 0);
  // Substitui pupilas por olhos amarelos
  group.traverse(o => {
    if (o.material && o.material.color && o.material.color.getHex() === 0x111111 && o.geometry && o.geometry.type === 'SphereGeometry' && o.geometry.parameters.radius === 0.025) {
      o.material = new THREE.MeshBasicMaterial({ color: 0xffff00 });
      o.scale.set(1.5, 1.5, 1.5);
    }
  });

  // Boca aberta (com dentes)
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.08, 0.02),
    new THREE.MeshBasicMaterial({ color: 0x330000 }));
  mouth.position.set(0, 1.6, 0.25);
  group.add(mouth);

  // Dentes
  for (let i = 0; i < 5; i++) {
    const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.015, 0.04, 4),
      new THREE.MeshStandardMaterial({ color: 0xddaa44 }));
    tooth.position.set(-0.06 + i * 0.03, 1.62, 0.26);
    tooth.rotation.x = Math.PI;
    group.add(tooth);
  }

  // Sangue no peito
  const blood = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 6),
    new THREE.MeshBasicMaterial({ color: 0x660000 }));
  blood.position.set(0.1, 1.1, 0.22);
  blood.scale.set(1.5, 1, 0.5);
  group.add(blood);

  // Braço levantado (característica de zumbi)
  const rightArm = group.getObjectByName('rightArm');
  if (rightArm) rightArm.rotation.x = -1.8;

  // Rasgos na roupa
  const tear1 = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 0.1),
    new THREE.MeshStandardMaterial({ color: 0x222222, side: THREE.DoubleSide }));
  tear1.position.set(-0.1, 1.0, 0.22);
  group.add(tear1);

  applyHat(group, a.hat);
  applyBack(group, a.back);

  return group;
}

// ===== ALIEN =====
function buildAlien(c, a) {
  const skinMat = new THREE.MeshStandardMaterial({ color: 0x6affaa, roughness: 0.5, metalness: 0.3 });
  const suitMat = new THREE.MeshStandardMaterial({ color: 0x222244, metalness: 0.6, roughness: 0.4 });
  const group = buildBaseAvatar(skinMat, suitMat, suitMat);

  // Cabeça maior e mais oval (alien clássico)
  const head = group.getObjectByName('head');
  head.scale.set(1.1, 1.3, 1.0);
  head.position.y = 1.78;

  // Olhos grandes pretos e inclinados
  group.children.forEach(child => {
    if (child.material && child.material.color && child.material.color.getHex() === 0xffffff && child.geometry && child.geometry.type === 'SphereGeometry') {
      child.scale.set(1.5, 1.8, 0.8);
      child.material = new THREE.MeshStandardMaterial({ color: 0x000000, metalness: 0.9, roughness: 0.1 });
    }
  });
  // Remove pupilas (alien tem olhos pretos)
  group.traverse(o => {
    if (o.material && o.material.color && o.material.color.getHex() === 0x111111 && o.geometry && o.geometry.type === 'SphereGeometry' && o.geometry.parameters.radius < 0.03) {
      o.visible = false;
    }
  });

  // Antenas na cabeça
  for (const x of [-0.1, 0.1]) {
    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.15, 6), skinMat);
    antenna.position.set(x, 2.15, 0);
    antenna.rotation.z = x > 0 ? 0.3 : -0.3;
    group.add(antenna);
    const tip = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0x00ff88 }));
    tip.position.set(x + (x > 0 ? 0.04 : -0.04), 2.22, 0);
    group.add(tip);
  }

  // Boca sem lábios
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.02, 0.02),
    new THREE.MeshBasicMaterial({ color: 0x003322 }));
  mouth.position.set(0, 1.62, 0.25);
  group.add(mouth);

  applyHat(group, a.hat);
  applyBack(group, a.back);

  return group;
}

// ===== MAGO =====
function buildWizard(c, a) {
  const robeMat = new THREE.MeshStandardMaterial({ color: 0x4a1a6a, roughness: 0.7 });
  const skinMat = new THREE.MeshStandardMaterial({ color: 0xffcc99, roughness: 0.7 });
  const group = buildBaseAvatar(skinMat, robeMat, robeMat);

  // Chapéu de mago pontudo
  const hat = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.8, 16),
    new THREE.MeshStandardMaterial({ color: 0x220044, roughness: 0.7 }));
  hat.position.y = 2.35;
  group.add(hat);
  // Aba do chapéu
  const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.03, 16),
    new THREE.MeshStandardMaterial({ color: 0x220044 }));
  brim.position.y = 1.95;
  group.add(brim);
  // Estrela no chapéu
  const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.05),
    new THREE.MeshBasicMaterial({ color: 0xffd700 }));
  star.position.set(0.1, 2.6, 0.22);
  group.add(star);

  // Barba branca longa
  const beard = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.4, 8),
    new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1 }));
  beard.position.set(0, 1.45, 0.18);
  beard.rotation.x = Math.PI;
  group.add(beard);

  // Cinto dourado
  const belt = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.04, 8, 16),
    new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9 }));
  belt.position.set(0, 0.85, 0);
  belt.rotation.x = Math.PI / 2;
  group.add(belt);

  // Cajado nas costas
  const staff = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 1.6, 8),
    new THREE.MeshStandardMaterial({ color: 0x5a3a1a }));
  staff.position.set(0.15, 1.3, -0.2);
  staff.rotation.z = 0.2;
  group.add(staff);
  // Gema no topo do cajado
  const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.06),
    new THREE.MeshBasicMaterial({ color: 0x00ffff }));
  gem.position.set(0.18, 2.1, -0.2);
  group.add(gem);

  // Capa roxa
  applyBack(group, 'cape');
  if (!group.userData.capeColor) {
    const cape = group.getObjectByName('cape');
    if (cape) cape.material = new THREE.MeshStandardMaterial({ color: 0x4a1a6a, side: THREE.DoubleSide });
  }

  return group;
}

function applyHair(group, style, color) {
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.85, metalness: 0.05 });
  if (style === 'bald') return;
  if (style === 'short') {
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12, 0, Math.PI*2, 0, Math.PI/2), mat);
    h.position.y = 1.78;
    h.scale.set(1, 1, 1);
    group.add(h);
  } else if (style === 'long') {
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 12, 0, Math.PI*2, 0, Math.PI*0.6), mat);
    h.position.y = 1.78;
    group.add(h);
    const back = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.28, 0.5, 12), mat);
    back.position.set(0, 1.5, -0.08);
    group.add(back);
  } else if (style === 'spiky') {
    for (let i = 0; i < 12; i++) {
      const s = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.22, 6), mat);
      const ang = (i / 12) * Math.PI * 2;
      const r = 0.22 + Math.random() * 0.05;
      s.position.set(Math.cos(ang) * r, 1.85, Math.sin(ang) * r);
      s.rotation.z = Math.cos(ang) * 0.4;
      s.rotation.x = -Math.sin(ang) * 0.4;
      group.add(s);
    }
    // Top spike
    const top = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.25, 6), mat);
    top.position.y = 2.0;
    group.add(top);
  } else if (style === 'mohawk') {
    const base = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8, 0, Math.PI*2, 0, Math.PI/2), mat);
    base.position.y = 1.78;
    base.scale.y = 0.5;
    group.add(base);
    for (let i = 0; i < 7; i++) {
      const s = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.25, 0.07), mat);
      s.position.set(0, 1.95, -0.18 + i * 0.06);
      group.add(s);
    }
  } else if (style === 'ponytail') {
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12, 0, Math.PI*2, 0, Math.PI/2), mat);
    h.position.y = 1.78;
    group.add(h);
    const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.06, 0.55, 10), mat);
    tail.position.set(0, 1.6, -0.28);
    tail.rotation.x = 0.3;
    group.add(tail);
    // Elástico
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.09, 0.02, 6, 12), new THREE.MeshStandardMaterial({ color: 0xff0000 }));
    band.position.set(0, 1.78, -0.27);
    band.rotation.x = Math.PI/2;
    group.add(band);
  } else if (style === 'afro') {
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.42, 16, 12), mat);
    h.position.y = 1.82;
    h.scale.set(1, 0.85, 1);
    group.add(h);
  } else if (style === 'bun') {
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.3, 16, 12, 0, Math.PI*2, 0, Math.PI/2), mat);
    h.position.y = 1.78;
    group.add(h);
    const bun = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 10), mat);
    bun.position.set(0, 2.05, -0.08);
    group.add(bun);
  }
}

function applyClothesPattern(group, type, c) {
  if (type === 'suit') {
    // Gravata + lapelas
    const tie = new THREE.Mesh(new THREE.ConeGeometry(0.06, 0.4, 4), new THREE.MeshStandardMaterial({ color: 0xaa0000 }));
    tie.position.set(0, 1.0, 0.22);
    tie.rotation.x = Math.PI;
    group.add(tie);
    const lapelL = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.4, 0.02), new THREE.MeshStandardMaterial({ color: 0x111111 }));
    lapelL.position.set(-0.13, 1.1, 0.21);
    lapelL.rotation.z = 0.2;
    const lapelR = lapelL.clone();
    lapelR.position.x = 0.13;
    lapelR.rotation.z = -0.2;
    group.add(lapelL, lapelR);
  } else if (type === 'hoodie') {
    const hood = new THREE.Mesh(new THREE.SphereGeometry(0.35, 12, 8, 0, Math.PI*2, 0, Math.PI/2),
      new THREE.MeshStandardMaterial({ color: c.clothesColor, roughness: 0.7 }));
    hood.position.set(0, 1.45, -0.15);
    hood.scale.set(1, 0.6, 1);
    group.add(hood);
    // Cordão
    const string = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.3), new THREE.MeshStandardMaterial({ color: 0xffffff }));
    string.position.set(0.08, 1.2, 0.23);
    const string2 = string.clone();
    string2.position.x = -0.08;
    group.add(string, string2);
  } else if (type === 'jacket') {
    const zip = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.6, 0.02), new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.8 }));
    zip.position.set(0, 1.05, 0.22);
    group.add(zip);
  } else if (type === 'armor') {
    // Peitoral metálico
    const plate = new THREE.Mesh(new THREE.SphereGeometry(0.32, 16, 12, 0, Math.PI*2, 0, Math.PI/2),
      new THREE.MeshStandardMaterial({ color: 0x888899, metalness: 0.8, roughness: 0.3 }));
    plate.position.set(0, 1.25, 0);
    plate.scale.set(1, 1.2, 0.9);
    group.add(plate);
    // Detalhes dourados
    const trim = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.02, 6, 16), new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9 }));
    trim.position.set(0, 1.1, 0.22);
    trim.rotation.x = Math.PI/2;
    group.add(trim);
  } else if (type === 'kimono') {
    // Faixa
    const belt = new THREE.Mesh(new THREE.BoxGeometry(0.65, 0.1, 0.36), new THREE.MeshStandardMaterial({ color: 0x000000 }));
    belt.position.set(0, 0.85, 0);
    group.add(belt);
    // Gola cruzada
    const collar = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 0.02), new THREE.MeshStandardMaterial({ color: 0xffffff }));
    collar.position.set(0, 1.35, 0.22);
    collar.rotation.z = 0.15;
    group.add(collar);
  }
}

function applyShoes(group, type, color) {
  const mat = new THREE.MeshStandardMaterial({ color, roughness: 0.6 });
  if (type === 'bare') {
    // Pés descalços (esferas)
    const leftFoot = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshStandardMaterial({ color: group.userData.skinColor || 0xffcc99 }));
    leftFoot.position.set(-0.15, 0.18, 0.05);
    leftFoot.scale.set(1, 0.6, 1.5);
    leftFoot.name = 'leftShoe';
    const rightFoot = leftFoot.clone();
    rightFoot.name = 'rightShoe';
    rightFoot.position.x = 0.15;
    group.add(leftFoot, rightFoot);
    return;
  }
  const leftShoe = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.12, 0.35), mat);
  leftShoe.position.set(-0.15, 0.18, 0.08);
  leftShoe.name = 'leftShoe';
  leftShoe.castShadow = true;
  const rightShoe = leftShoe.clone();
  rightShoe.name = 'rightShoe';
  rightShoe.position.x = 0.15;
  group.add(leftShoe, rightShoe);

  if (type === 'sneakers') {
    // Listras brancas
    const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.19, 0.03, 0.36), new THREE.MeshStandardMaterial({ color: 0xffffff }));
    stripe.position.set(-0.15, 0.16, 0.08);
    const stripe2 = stripe.clone();
    stripe2.position.x = 0.15;
    group.add(stripe, stripe2);
  } else if (type === 'boots') {
    // Cano alto
    const shaftL = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.2, 8), mat);
    shaftL.position.set(-0.15, 0.32, 0.08);
    const shaftR = shaftL.clone();
    shaftR.position.x = 0.15;
    group.add(shaftL, shaftR);
  } else if (type === 'heels') {
    // Salto
    const heelL = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.03, 0.1, 6), mat);
    heelL.position.set(-0.15, 0.05, -0.05);
    const heelR = heelL.clone();
    heelR.position.x = 0.15;
    group.add(heelL, heelR);
  }
}

function applyHat(group, type) {
  if (!type) return;
  const darkMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.6 });
  if (type === 'cap') {
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8, 0, Math.PI*2, 0, Math.PI/2), darkMat);
    cap.position.y = 1.92;
    group.add(cap);
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.04, 0.2), darkMat);
    visor.position.set(0, 1.9, 0.25);
    group.add(visor);
  } else if (type === 'helmet') {
    const h = new THREE.Mesh(new THREE.SphereGeometry(0.34, 16, 12), new THREE.MeshStandardMaterial({ color: 0xffaa00, metalness: 0.6, roughness: 0.4 }));
    h.position.y = 1.92;
    group.add(h);
    // Visor
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.1, 0.05), new THREE.MeshStandardMaterial({ color: 0x000033, metalness: 0.9, transparent: true, opacity: 0.7 }));
    visor.position.set(0, 1.85, 0.27);
    group.add(visor);
  } else if (type === 'tophat') {
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.05, 16), new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.4 }));
    brim.position.y = 1.92;
    const top = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.5, 16), new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.4 }));
    top.position.y = 2.2;
    // Fita vermelha
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.27, 0.27, 0.06, 16), new THREE.MeshStandardMaterial({ color: 0xaa0000 }));
    band.position.y = 2.0;
    group.add(brim, top, band);
  } else if (type === 'beanie') {
    const b = new THREE.Mesh(new THREE.SphereGeometry(0.32, 12, 8, 0, Math.PI*2, 0, Math.PI/2), new THREE.MeshStandardMaterial({ color: 0x8b3aaf, roughness: 0.9 }));
    b.position.y = 1.95;
    b.scale.set(1, 1.1, 1);
    group.add(b);
    // Pom-pom
    const pom = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1 }));
    pom.position.y = 2.2;
    group.add(pom);
  } else if (type === 'crown') {
    const cg = new THREE.ConeGeometry(0.07, 0.2, 4);
    const cm = new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, roughness: 0.2, emissive: 0x553300 });
    for (let i = 0; i < 6; i++) {
      const c = new THREE.Mesh(cg, cm);
      const ang = (i / 6) * Math.PI * 2;
      c.position.set(Math.cos(ang) * 0.22, 2.05, Math.sin(ang) * 0.22);
      group.add(c);
    }
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.04, 8, 16), cm);
    ring.position.y = 1.98;
    ring.rotation.x = Math.PI/2;
    group.add(ring);
  } else if (type === 'cowboy') {
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.4, 0.05, 16), new THREE.MeshStandardMaterial({ color: 0x6b3a1a, roughness: 0.8 }));
    brim.position.y = 1.92;
    const top = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.25, 0.25, 16), new THREE.MeshStandardMaterial({ color: 0x6b3a1a, roughness: 0.8 }));
    top.position.y = 2.07;
    const band = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.04, 16), new THREE.MeshStandardMaterial({ color: 0x000000 }));
    band.position.y = 1.95;
    group.add(brim, top, band);
  } else if (type === 'wizard') {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.7, 16), new THREE.MeshStandardMaterial({ color: 0x220044, roughness: 0.7 }));
    cone.position.y = 2.25;
    const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.4, 0.03, 16), new THREE.MeshStandardMaterial({ color: 0x220044, roughness: 0.7 }));
    brim.position.y = 1.92;
    // Estrela dourada
    const star = new THREE.Mesh(new THREE.OctahedronGeometry(0.05), new THREE.MeshStandardMaterial({ color: 0xffd700, emissive: 0x553300 }));
    star.position.set(0.1, 2.4, 0.25);
    group.add(cone, brim, star);
  }
}

function applyGlasses(group, type) {
  if (!type) return;
  const mat = new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.7, roughness: 0.3 });
  if (type === 'sunglasses') {
    const lens = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.09, 0.02), new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.9, roughness: 0.1 }));
    lens.position.set(-0.11, 1.78, 0.26);
    const r = lens.clone();
    r.position.x = 0.11;
    group.add(lens, r);
    const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.02, 0.02), mat);
    bridge.position.set(0, 1.78, 0.26);
    group.add(bridge);
  } else if (type === 'round') {
    const l = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.012, 8, 16), mat);
    l.position.set(-0.11, 1.78, 0.26);
    const r = l.clone();
    r.position.x = 0.11;
    group.add(l, r);
  } else if (type === 'vr') {
    const v = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.15, 0.12), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.4 }));
    v.position.set(0, 1.78, 0.22);
    group.add(v);
    // LEDs
    const led = new THREE.Mesh(new THREE.SphereGeometry(0.015, 6, 6), new THREE.MeshBasicMaterial({ color: 0x00ff00 }));
    led.position.set(0.15, 1.85, 0.25);
    group.add(led);
  } else if (type === 'visor') {
    const v = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.1, 0.05), new THREE.MeshStandardMaterial({ color: 0x00ffaa, metalness: 0.9, transparent: true, opacity: 0.7, emissive: 0x004422 }));
    v.position.set(0, 1.78, 0.26);
    group.add(v);
  } else if (type === 'cyber') {
    // Óculos cyber com LED rosa
    const lens = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.09, 0.02), new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.9 }));
    lens.position.set(-0.11, 1.78, 0.26);
    const r = lens.clone();
    r.position.x = 0.11;
    const led = new THREE.Mesh(new THREE.SphereGeometry(0.012, 6, 6), new THREE.MeshBasicMaterial({ color: 0xff00ff }));
    led.position.set(-0.11, 1.83, 0.27);
    const led2 = led.clone();
    led2.position.x = 0.11;
    group.add(lens, r, led, led2);
  }
}

function applyMask(group, type) {
  if (!type) return;
  if (type === 'clown') {
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), new THREE.MeshStandardMaterial({ color: 0xff0000, roughness: 0.4 }));
    nose.position.set(0, 1.7, 0.27);
    group.add(nose);
  } else if (type === 'ninja') {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.18, 0.02), new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.6 }));
    m.position.set(0, 1.65, 0.25);
    group.add(m);
  } else if (type === 'cyborg') {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.15, 0.05), new THREE.MeshStandardMaterial({ color: 0x444444, metalness: 0.8 }));
    m.position.set(0, 1.68, 0.23);
    group.add(m);
    const led = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), new THREE.MeshBasicMaterial({ color: 0xff0000 }));
    led.position.set(0.1, 1.7, 0.27);
    group.add(led);
    // Antena
    const ant = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.15), new THREE.MeshStandardMaterial({ color: 0x222222 }));
    ant.position.set(0.18, 1.95, 0);
    group.add(ant);
  } else if (type === 'skull') {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.27, 8, 8), new THREE.MeshStandardMaterial({ color: 0xeeeeee, roughness: 0.5 }));
    m.position.set(0, 1.72, 0.02);
    m.scale.set(1, 1, 0.7);
    group.add(m);
    // Olhos pretos
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 8), new THREE.MeshBasicMaterial({ color: 0x000000 }));
    eye.position.set(-0.1, 1.78, 0.18);
    const r = eye.clone();
    r.position.x = 0.1;
    group.add(eye, r);
  } else if (type === 'samurai') {
    // Mempo (máscara facial samurai vermelha)
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.25, 12, 8, 0, Math.PI*2, 0, Math.PI/2), new THREE.MeshStandardMaterial({ color: 0x8b0000, metalness: 0.6, roughness: 0.4 }));
    m.position.set(0, 1.7, 0.05);
    m.scale.set(1, 1, 0.5);
    group.add(m);
    // Dentes
    const teeth = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.04, 0.02), new THREE.MeshStandardMaterial({ color: 0xffffff }));
    teeth.position.set(0, 1.6, 0.23);
    group.add(teeth);
  } else if (type === 'gas') {
    // Máscara de gás com filtro
    const face = new THREE.Mesh(new THREE.SphereGeometry(0.27, 12, 10), new THREE.MeshStandardMaterial({ color: 0x333322, roughness: 0.7 }));
    face.position.set(0, 1.72, 0.05);
    face.scale.set(1, 1, 0.7);
    group.add(face);
    // Visor
    const visor = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.05, 12), new THREE.MeshStandardMaterial({ color: 0x003311, metalness: 0.5 }));
    visor.position.set(0, 1.75, 0.22);
    visor.rotation.x = Math.PI/2;
    group.add(visor);
    // Filtro
    const filter = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.15, 8), new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.6 }));
    filter.position.set(0, 1.62, 0.22);
    group.add(filter);
  }
}

function applyBack(group, type) {
  if (!type) return;
  if (type === 'backpack') {
    const bp = new THREE.Mesh(new THREE.BoxGeometry(0.45, 0.55, 0.22), new THREE.MeshStandardMaterial({ color: 0x8b4513, roughness: 0.8 }));
    bp.position.set(0, 1.15, -0.27);
    bp.castShadow = true;
    group.add(bp);
    // Alças
    const strap1 = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.6, 0.04), new THREE.MeshStandardMaterial({ color: 0x5a2f0c }));
    strap1.position.set(-0.18, 1.15, -0.15);
    const strap2 = strap1.clone();
    strap2.position.x = 0.18;
    group.add(bp, strap1, strap2);
  } else if (type === 'wings') {
    const wingMat = new THREE.MeshStandardMaterial({ color: 0xffffff, side: THREE.DoubleSide, roughness: 0.4, metalness: 0.3, emissive: 0x444466, emissiveIntensity: 0.2 });
    // Asa esquerda (várias penas)
    const lw = new THREE.Group();
    for (let i = 0; i < 5; i++) {
      const feather = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.6), wingMat);
      feather.position.set(-0.2 - i * 0.1, 1.3 - i * 0.05, -0.1);
      feather.rotation.y = 0.3 + i * 0.1;
      feather.rotation.z = 0.1;
      lw.add(feather);
    }
    lw.name = 'leftWing';
    const rw = lw.clone();
    rw.scale.x = -1;
    rw.name = 'rightWing';
    group.add(lw, rw);
  } else if (type === 'cape') {
    const cape = new THREE.Mesh(
      new THREE.PlaneGeometry(0.85, 1.4, 8, 8),
      new THREE.MeshStandardMaterial({ color: 0x660000, side: THREE.DoubleSide, roughness: 0.7 })
    );
    cape.position.set(0, 1.15, -0.22);
    cape.rotation.x = -0.1;
    cape.name = 'cape';
    group.add(cape);
  } else if (type === 'jetpack') {
    const jp = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.2, 0.7, 8), new THREE.MeshStandardMaterial({ color: 0x666666, metalness: 0.8, roughness: 0.3 }));
    jp.position.set(0, 1.25, -0.3);
    group.add(jp);
    // Bicos
    const nozzle1 = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.08, 0.1, 8), new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.9 }));
    nozzle1.position.set(-0.08, 0.85, -0.3);
    const nozzle2 = nozzle1.clone();
    nozzle2.position.x = 0.08;
    group.add(nozzle1, nozzle2);
    // Luz de propulsão
    const flame = new THREE.PointLight(0xff6600, 0, 3);
    flame.position.set(0, 0.8, -0.3);
    flame.name = 'jetpackFlame';
    group.add(flame);
  } else if (type === 'shield') {
    const shield = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.3, 0.05, 6),
      new THREE.MeshStandardMaterial({ color: 0x888899, metalness: 0.8, roughness: 0.3 })
    );
    shield.position.set(0, 1.1, -0.25);
    shield.rotation.x = Math.PI/2;
    shield.rotation.y = Math.PI/6;
    group.add(shield);
    // Emblema
    const emblem = new THREE.Mesh(new THREE.SphereGeometry(0.08, 8, 8), new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9, emissive: 0x553300 }));
    emblem.position.set(0, 1.1, -0.22);
    group.add(emblem);
  } else if (type === 'halo') {
    const halo = new THREE.Mesh(
      new THREE.TorusGeometry(0.32, 0.04, 8, 24),
      new THREE.MeshStandardMaterial({ color: 0xffd700, emissive: 0xffaa00, emissiveIntensity: 1, metalness: 0.5 })
    );
    halo.position.y = 2.15;
    halo.rotation.x = Math.PI/2;
    halo.name = 'halo';
    group.add(halo);
    // Luz
    const light = new THREE.PointLight(0xffd700, 0.8, 5);
    light.position.set(0, 2.15, 0);
    group.add(light);
  }
}

function createNameSprite(text) {
  const canvas = document.createElement('canvas');
  canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.font = 'bold 32px sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text || 'Jogador', 128, 32);
  const tex = new THREE.CanvasTexture(canvas);
  const mat = new THREE.SpriteMaterial({ map: tex, depthTest: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(1.2, 0.3, 1);
  sprite.userData.canvas = canvas;
  sprite.userData.ctx = ctx;
  sprite.userData.texture = tex;
  return sprite;
}

function updateNameSprite(sprite, text) {
  if (!sprite || !sprite.userData.canvas) return;
  const ctx = sprite.userData.ctx;
  ctx.clearRect(0, 0, 256, 64);
  ctx.fillStyle = 'rgba(0,0,0,0.6)';
  ctx.fillRect(0, 0, 256, 64);
  ctx.font = 'bold 32px sans-serif';
  ctx.fillStyle = '#ffffff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text || 'Jogador', 128, 32);
  sprite.userData.texture.needsUpdate = true;
}

function createHealthBar() {
  const group = new THREE.Group();
  const bg = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.1), new THREE.MeshBasicMaterial({ color: 0x000000 }));
  const fill = new THREE.Mesh(new THREE.PlaneGeometry(0.78, 0.08), new THREE.MeshBasicMaterial({ color: 0x00ff00 }));
  fill.position.z = 0.001;
  fill.name = 'healthFill';
  group.add(bg, fill);
  return group;
}

function updateHealthBar(group, health) {
  const fill = group.getObjectByName('healthFill');
  if (!fill) return;
  const pct = Math.max(0, health) / 100;
  fill.scale.x = pct;
  fill.position.x = -(0.78 * (1 - pct)) / 2;
  fill.material.color.setHex(pct > 0.5 ? 0x00ff00 : pct > 0.25 ? 0xffaa00 : 0xff0000);
}

function applyCustomization(mesh, customization, accessories) {
  if (!mesh) return;
  const parent = mesh.parent;
  const pos = mesh.position.clone();
  const rot = mesh.rotation.clone();
  if (parent) parent.remove(mesh);
  disposeAvatar(mesh);
  const newMesh = buildAvatarMesh(customization, accessories);
  newMesh.position.copy(pos);
  newMesh.rotation.copy(rot);
  if (parent) parent.add(newMesh);
  return newMesh;
}

function createRemoteAvatar(name) {
  const mesh = buildAvatarMesh(window.Save.getAvatar(), window.Save.getAccessories());
  updateNameSprite(mesh.getObjectByName('nameSprite'), name);
  return mesh;
}

function updateRemoteInfo(rp) {
  if (!rp.mesh) return;
  const sprite = rp.mesh.getObjectByName('nameSprite');
  if (sprite) updateNameSprite(sprite, rp.name);
  const hb = rp.mesh.getObjectByName('healthBar');
  if (hb) updateHealthBar(hb, rp.health);
}

function setRemoteAnimation(mesh, anim) {
  if (!mesh) return;
  mesh.userData.animState = anim;
}

function animateAvatar(mesh, anim, time, delta) {
  if (!mesh) return;
  const leftArm = mesh.getObjectByName('leftArm');
  const rightArm = mesh.getObjectByName('rightArm');
  const leftLeg = mesh.getObjectByName('leftLeg');
  const rightLeg = mesh.getObjectByName('rightLeg');
  if (!leftArm || !rightArm || !leftLeg || !rightLeg) return;
  const t = time;

  // Anima as asas se existirem
  const leftWing = mesh.getObjectByName('leftWing');
  const rightWing = mesh.getObjectByName('rightWing');
  if (leftWing) leftWing.rotation.y = Math.sin(t * 8) * 0.3 + 0.3;
  if (rightWing) rightWing.rotation.y = -Math.sin(t * 8) * 0.3 - 0.3;
  // Cape balança
  const cape = mesh.getObjectByName('cape');
  if (cape) cape.rotation.x = -0.1 + Math.sin(t * 4) * 0.05;
  // Halo gira
  const halo = mesh.getObjectByName('halo');
  if (halo) halo.rotation.z += delta * 2;
  // Jetpack flame
  const flame = mesh.getObjectByName('jetpackFlame');
  if (flame) flame.intensity = Math.random() * 2 + 1;

  if (anim === 'walk') {
    const swing = Math.sin(t * 8) * 0.6;
    leftLeg.rotation.x = swing; rightLeg.rotation.x = -swing;
    leftArm.rotation.x = -swing * 0.7; rightArm.rotation.x = swing * 0.7;
  } else if (anim === 'run') {
    const swing = Math.sin(t * 14) * 1.0;
    leftLeg.rotation.x = swing; rightLeg.rotation.x = -swing;
    leftArm.rotation.x = -swing * 0.9; rightArm.rotation.x = swing * 0.9;
    mesh.rotation.z = Math.sin(t * 14) * 0.05;
  } else if (anim === 'jump') {
    leftLeg.rotation.x = 0.3; rightLeg.rotation.x = 0.3;
    leftArm.rotation.x = -0.8; rightArm.rotation.x = -0.8;
  } else if (anim === 'crouch') {
    leftLeg.rotation.x = -0.7; rightLeg.rotation.x = 0.7;
    leftArm.rotation.x = 0.3; rightArm.rotation.x = 0.3;
    if (mesh.userData.baseY === undefined) mesh.userData.baseY = mesh.position.y;
  } else if (anim === 'swim') {
    const s = Math.sin(t * 4);
    leftArm.rotation.x = -0.5 + s * 0.5;
    rightArm.rotation.x = -0.5 - s * 0.5;
    leftLeg.rotation.x = s * 0.3;
    rightLeg.rotation.x = -s * 0.3;
  } else if (anim === 'climb') {
    const s = Math.sin(t * 6);
    leftArm.rotation.x = -s * 0.8;
    rightArm.rotation.x = s * 0.8;
    leftLeg.rotation.x = s * 0.5;
    rightLeg.rotation.x = -s * 0.5;
  } else if (anim === 'wave') {
    leftArm.rotation.x = 0; leftArm.rotation.z = 0;
    rightArm.rotation.x = -2.4;
    rightArm.rotation.z = Math.sin(t * 10) * 0.3 - 0.5;
  } else if (anim === 'dance') {
    const s = Math.sin(t * 8);
    leftArm.rotation.z = 0.8 + s * 0.5;
    rightArm.rotation.z = -0.8 - s * 0.5;
    leftArm.rotation.x = -0.5; rightArm.rotation.x = -0.5;
    leftLeg.rotation.x = 0; rightLeg.rotation.x = 0;
    mesh.rotation.y = Math.sin(t * 4) * 0.3;
  } else if (anim === 'sit') {
    leftLeg.rotation.x = -1.5; rightLeg.rotation.x = -1.5;
    leftArm.rotation.x = -0.5; rightArm.rotation.x = -0.5;
  } else if (anim === 'sleep') {
    leftArm.rotation.x = -1.2; rightArm.rotation.x = -1.2;
    leftLeg.rotation.x = 0; rightLeg.rotation.x = 0;
  } else if (anim === 'point') {
    rightArm.rotation.x = -1.5; rightArm.rotation.z = 0;
    leftArm.rotation.x = 0;
  } else if (anim === 'laugh') {
    const s = Math.sin(t * 15);
    leftArm.rotation.x = -0.3 + s * 0.2;
    rightArm.rotation.x = -0.3 - s * 0.2;
    if (mesh.userData.baseY === undefined) mesh.userData.baseY = mesh.position.y;
    mesh.position.y = mesh.userData.baseY + Math.abs(Math.sin(t * 15)) * 0.05;
  } else if (anim === 'throw') {
    const throwStart = mesh.userData.throwAnim || 0;
    const throwT = (performance.now() - throwStart) / 1000;
    if (throwT < 0.6) {
      if (throwT < 0.3) {
        const p = throwT / 0.3;
        rightArm.rotation.x = -0.5 - p * 1.5;
        rightArm.rotation.z = -0.3 - p * 0.5;
        leftArm.rotation.x = 0.3 + p * 0.5;
      } else {
        const p = (throwT - 0.3) / 0.3;
        rightArm.rotation.x = -2.0 + p * 3.0;
        rightArm.rotation.z = -0.8 + p * 0.8;
        leftArm.rotation.x = 0.8 - p * 0.5;
      }
      const torso = mesh.getObjectByName('torso');
      if (torso) {
        torso.rotation.x = throwT < 0.3 ? -throwT * 0.3 : -(0.3 - (throwT - 0.3)) * 0.3;
      }
    } else {
      rightArm.rotation.x = 0; rightArm.rotation.z = 0;
      leftArm.rotation.x = 0; leftArm.rotation.z = 0;
      const torso = mesh.getObjectByName('torso');
      if (torso) torso.rotation.x = 0;
      mesh.userData.throwAnim = null;
    }
  } else {
    const breath = Math.sin(t * 2) * 0.05;
    leftArm.rotation.x = breath; rightArm.rotation.x = breath;
    leftLeg.rotation.x = 0; rightLeg.rotation.x = 0;
    leftArm.rotation.z = 0.1; rightArm.rotation.z = -0.1;
    mesh.rotation.z = 0;
  }
}

function playEmote(mesh, emote) {
  if (!mesh) return;
  mesh.userData.emoteLock = true;
  mesh.userData.emote = emote;
  setTimeout(() => { mesh.userData.emoteLock = false; }, emote === 'dance' ? 5000 : emote === 'sleep' || emote === 'sit' ? 30000 : 3000);
}

function setRemoteWeapon(mesh, weaponId) {
  if (!mesh) return;
  const existing = mesh.getObjectByName('heldWeapon');
  if (existing) {
    mesh.remove(existing);
    if (existing.geometry) existing.geometry.dispose();
    if (existing.material) existing.material.dispose();
  }
  if (!weaponId) return;
  const rightArm = mesh.getObjectByName('rightArm');
  if (!rightArm) return;
  const wpn = buildWeaponMesh(weaponId);
  wpn.name = 'heldWeapon';
  wpn.position.set(0.05, -0.7, 0.1);
  rightArm.add(wpn);
}

function buildWeaponMesh(weaponId) {
  const group = new THREE.Group();
  const configs = {
    pistol:  { color: 0x2a2a2a, len: 0.3, w: 0.07, h: 0.16, metal: true },
    rifle:   { color: 0x3a2a1a, len: 0.7, w: 0.07, h: 0.13, metal: false },
    shotgun: { color: 0x5a3a1a, len: 0.7, w: 0.09, h: 0.15, metal: false },
    sniper:  { color: 0x1a1a2a, len: 0.9, w: 0.06, h: 0.1, metal: true },
    launcher:{ color: 0x4a4a4a, len: 0.7, w: 0.16, h: 0.18, metal: true },
    smg:     { color: 0x1a1a1a, len: 0.4, w: 0.08, h: 0.18, metal: true },
    crossbow:{ color: 0x5a3a1a, len: 0.6, w: 0.15, h: 0.08, metal: false },
    flame:   { color: 0x442211, len: 0.5, w: 0.1, h: 0.12, metal: false }
  };
  const c = configs[weaponId] || configs.pistol;
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(c.w, c.h, c.len),
    new THREE.MeshStandardMaterial({ color: c.color, metalness: c.metal ? 0.8 : 0.2, roughness: 0.4 })
  );
  body.position.z = -c.len / 2;
  group.add(body);
  // Barrel
  if (weaponId !== 'flame') {
    const barrel = new THREE.Mesh(
      new THREE.CylinderGeometry(c.w * 0.3, c.w * 0.3, c.len * 0.7, 8),
      new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.9, roughness: 0.2 })
    );
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, c.h * 0.3, -c.len * 0.6);
    group.add(barrel);
  }
  // Mira
  const sight = new THREE.Mesh(
    new THREE.BoxGeometry(0.02, 0.05, 0.02),
    new THREE.MeshStandardMaterial({ color: 0x111111 })
  );
  sight.position.set(0, c.h * 0.7, -c.len * 0.3);
  group.add(sight);

  // Detalhes específicos
  if (weaponId === 'crossbow') {
    // Braço da besta
    const arm = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.02, 0.05),
      new THREE.MeshStandardMaterial({ color: 0x222222 })
    );
    arm.position.set(0, c.h * 0.3, -c.len * 0.5);
    group.add(arm);
    // Corda
    const string = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.005, 0.005),
      new THREE.MeshStandardMaterial({ color: 0xeeeeee })
    );
    string.position.set(0, c.h * 0.2, -c.len * 0.4);
    group.add(string);
  } else if (weaponId === 'flame') {
    // Tanque de combustível
    const tank = new THREE.Mesh(
      new THREE.CylinderGeometry(0.1, 0.1, 0.25, 12),
      new THREE.MeshStandardMaterial({ color: 0xaa3322, metalness: 0.7 })
    );
    tank.position.set(0, -c.h * 0.5, -c.len * 0.3);
    group.add(tank);
    // Bico
    const nozzle = new THREE.Mesh(
      new THREE.ConeGeometry(0.04, 0.1, 8),
      new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.9 })
    );
    nozzle.position.set(0, 0, -c.len);
    nozzle.rotation.x = -Math.PI / 2;
    group.add(nozzle);
  } else if (weaponId === 'sniper') {
    // Luneta
    const scope = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.04, 0.2, 12),
      new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.9 })
    );
    scope.rotation.x = Math.PI / 2;
    scope.position.set(0, c.h * 0.9, -c.len * 0.4);
    group.add(scope);
  }
  return group;
}

function initPreview(canvas) {
  avatarPreviewScene = new THREE.Scene();
  avatarPreviewScene.background = new THREE.Color(0x1a2332);
  avatarPreviewCamera = new THREE.PerspectiveCamera(45, canvas.clientWidth / canvas.clientHeight, 0.1, 100);
  avatarPreviewCamera.position.set(0, 1.4, 3.2);
  avatarPreviewCamera.lookAt(0, 1.2, 0);
  avatarPreviewRenderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  avatarPreviewRenderer.setSize(canvas.clientWidth, canvas.clientHeight);
  avatarPreviewRenderer.shadowMap.enabled = true;
  avatarPreviewScene.add(new THREE.AmbientLight(0xffffff, 0.5));
  const dir = new THREE.DirectionalLight(0xffffff, 1.0);
  dir.position.set(2, 4, 3);
  dir.castShadow = true;
  avatarPreviewScene.add(dir);
  const rim = new THREE.DirectionalLight(0x66aaff, 0.6);
  rim.position.set(-2, 3, -3);
  avatarPreviewScene.add(rim);
  // Plataforma
  const ground = new THREE.Mesh(
    new THREE.CircleGeometry(2, 32),
    new THREE.MeshStandardMaterial({ color: 0x0d1117, metalness: 0.6, roughness: 0.3 })
  );
  ground.rotation.x = -Math.PI / 2;
  avatarPreviewScene.add(ground);
  avatarPreviewMesh = buildAvatarMesh(window.Save.getAvatar(), window.Save.getAccessories());
  avatarPreviewScene.add(avatarPreviewMesh);
}

function updatePreview(customization, accessories) {
  if (!avatarPreviewScene) return;
  if (avatarPreviewMesh) {
    avatarPreviewScene.remove(avatarPreviewMesh);
    disposeAvatar(avatarPreviewMesh);
  }
  avatarPreviewMesh = buildAvatarMesh(customization, accessories);
  avatarPreviewScene.add(avatarPreviewMesh);
}

function renderPreview(delta) {
  if (!avatarPreviewRenderer || !avatarPreviewMesh) return;
  avatarPreviewAnim += delta;
  avatarPreviewMesh.rotation.y = Math.sin(avatarPreviewAnim * 0.5) * 0.5;
  animateAvatar(avatarPreviewMesh, 'idle', avatarPreviewAnim, delta);
  avatarPreviewRenderer.render(avatarPreviewScene, avatarPreviewCamera);
}

function disposeAvatar(mesh) {
  if (!mesh) return;
  mesh.traverse(o => {
    if (o.geometry) o.geometry.dispose();
    if (o.material) {
      if (Array.isArray(o.material)) o.material.forEach(m => m.dispose());
      else o.material.dispose();
    }
  });
}

window.Avatar = {
  buildAvatarMesh, applyCustomization, createRemoteAvatar, updateRemoteInfo,
  setRemoteAnimation, animateAvatar, playEmote, setRemoteWeapon, buildWeaponMesh,
  initPreview, updatePreview, renderPreview, disposeAvatar,
  updateNameSprite, updateHealthBar,
  HAIR_STYLES, CLOTHES, SHOES, HATS, GLASSES, MASKS, BACKS, COLORS,
  CHARACTER_TYPES
};
})();
