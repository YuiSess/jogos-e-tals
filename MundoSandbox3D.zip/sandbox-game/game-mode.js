// ============================================================
// game-mode.js — Modos de jogo: Queimada, Futebol, Capture the Flag, Pega-Pega
// + sistema de bola com física + trail + animação de arremesso
// ============================================================
(function() {
'use strict';

let scene = null;
let camera = null;
let currentMode = 'free';    // 'free' | 'queimada' | 'futebol' | 'ctf' | 'pega'
let balls = [];              // bolas ativas { mesh, body, trail, holder, lastThrower }
let trailMaterial = null;
let throwAnimating = false;
let throwAnimStart = 0;
let team = 0;                // 0 = sem time, 1 = azul, 2 = vermelho
let scores = { team1: 0, team2: 0 };
let eliminated = new Set();  // peerIds eliminados na queimada
let flagCarrier = null;      // peerId carregando a bandeira
let flags = null;            // { flag1: mesh, flag2: mesh }
let catchCooldown = 0;       // cooldown para pegar bola
let lastBallHolder = null;

const TEAM_COLORS = { 1: 0x3b82f6, 2: 0xef4444 };

function GameModeInit(scn, cam) {
  scene = scn;
  camera = cam;
  trailMaterial = new THREE.LineBasicMaterial({
    color: 0xffff66, transparent: true, opacity: 0.8
  });
}

// ===== Sincronização de bola =====
function spawnBall(position, velocity, throwerId) {
  // Cria mesh da bola
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 16, 12),
    new THREE.MeshPhongMaterial({ color: 0xff6b35, emissive: 0x331100 })
  );
  mesh.position.copy(position);
  mesh.castShadow = true;
  scene.add(mesh);

  // Corpo físico (Cannon)
  const shape = new CANNON.Sphere(0.3);
  const body = new CANNON.Body({
    mass: 1,
    shape: shape,
    position: new CANNON.Vec3(position.x, position.y, position.z),
    material: window.Physics.getWorld().materials.objectMat,
    linearDamping: 0.1,
    angularDamping: 0.1
  });
  body.velocity.set(velocity.x, velocity.y, velocity.z);
  window.Physics.getWorld().addBody(body);

  // Trail (linha que segue a bola)
  const trailGeom = new THREE.BufferGeometry();
  const trailPositions = new Float32Array(60 * 3);  // 60 pontos
  trailGeom.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
  const trailMat = new THREE.LineBasicMaterial({
    color: 0xff6b35, transparent: true, opacity: 0.7, linewidth: 3
  });
  const trail = new THREE.Line(trailGeom, trailMat);
  trail.frustumCulled = false;
  scene.add(trail);

  const ball = {
    mesh, body, trail,
    trailPoints: [],
    holder: null,
    lastThrower: throwerId,
    spawnTime: performance.now(),
    active: true
  };
  balls.push(ball);

  // Detecção de colisão (quando a bola atinge um jogador)
  body.addEventListener('collide', (e) => {
    onBallCollide(ball, e);
  });

  // Broadcast
  if (window.Network) {
    window.Network.broadcast({
      type: 'ball',
      action: 'spawn',
      id: window.PeerAPI.getMyId(),
      x: position.x, y: position.y, z: position.z,
      vx: velocity.x, vy: velocity.y, vz: velocity.z,
      thrower: throwerId
    });
  }
  return ball;
}

// Jogador arremessa a bola
function throwBall() {
  if (currentMode !== 'queimada' && currentMode !== 'futebol') return false;
  // Procura bola segurada
  let held = null;
  for (const b of balls) {
    if (b.holder === 'me') { held = b; break; }
  }
  if (!held) return false;

  const camPos = window.Player.getCameraPosition();
  const camDir = window.Player.getCameraDirection();
  // Velocidade do arremesso
  const vel = camDir.clone().multiplyScalar(35);
  vel.y += 3;  // leve arco

  held.body.velocity.set(vel.x, vel.y, vel.z);
  held.body.angularVelocity.set(Math.random() * 10, Math.random() * 10, Math.random() * 10);
  held.holder = null;
  held.lastThrower = window.PeerAPI.getMyId();
  held.mesh.position.copy(camPos.clone().add(camDir.clone().multiplyScalar(1)));

  // Animação de arremesso na mão
  startThrowAnimation();

  // Broadcast
  if (window.Network) {
    window.Network.broadcast({
      type: 'ball',
      action: 'throw',
      id: window.PeerAPI.getMyId(),
      x: held.mesh.position.x, y: held.mesh.position.y, z: held.mesh.position.z,
      vx: vel.x, vy: vel.y, vz: vel.z,
      thrower: window.PeerAPI.getMyId()
    });
  }

  if (window.Audio && window.Audio.playSound) window.Audio.playSound('throw', { volume: 0.4 });
  return true;
}

// Tenta pegar bola (no chão ou em voo)
function tryCatchBall() {
  if (catchCooldown > 0) return false;
  // Já está segurando uma?
  for (const b of balls) {
    if (b.holder === 'me') return false;
  }
  const playerPos = window.Player.getPosition();
  let closest = null;
  let closestDist = 1.5;
  for (const b of balls) {
    if (b.holder) continue;
    const dist = b.mesh.position.distanceTo(playerPos);
    if (dist < closestDist) {
      closestDist = dist;
      closest = b;
    }
  }
  if (closest) {
    closest.holder = 'me';
    catchCooldown = 0.5;
    if (window.Audio && window.Audio.playSound) window.Audio.playSound('catch', { volume: 0.4 });
    if (window.Network) {
      window.Network.broadcast({
        type: 'ball',
        action: 'catch',
        id: window.PeerAPI.getMyId(),
        ballIndex: balls.indexOf(closest)
      });
    }
    return true;
  }
  return false;
}

// Quando a bola colide com algo
function onBallCollide(ball, event) {
  if (!ball.active) return;
  if (ball.holder) return;
  // Verifica se atingiu um jogador remoto
  if (window.Network) {
    const remote = window.Network.getRemotePlayers();
    const ballPos = ball.mesh.position;
    for (const [id, rp] of remote) {
      if (!rp.mesh) continue;
      if (id === ball.lastThrower) continue;  // não atinge quem arremessou
      const dist = rp.mesh.position.distanceTo(ballPos);
      if (dist < 1.0) {
        // Atingiu!
        if (currentMode === 'queimada') {
          eliminatePlayer(id, ball.lastThrower);
        }
        if (window.Effects) window.Effects.createImpact(ballPos.x, ballPos.y, ballPos.z, 0, 1, 0, 0xff6b35);
        if (window.Audio && window.Audio.playSound) window.Audio.playSound('hit_player', { volume: 0.6 });
        break;
      }
    }
  }
}

function eliminatePlayer(peerId, byPeerId) {
  if (eliminated.has(peerId)) return;
  eliminated.add(peerId);
  const rp = window.Network ? window.Network.getRemotePlayer(peerId) : null;
  const name = rp ? rp.name : 'Jogador';
  if (window.UI) window.UI.addNotification(`${name} foi queimado!`, 'warn');
  if (window.Chat) window.Chat.addSystem(`${name} foi queimado por outro jogador!`);
  // Se fui eu, aplico dano visual
  if (peerId === window.PeerAPI.getMyId()) {
    if (window.Player) window.Player.takeDamage(50, 'queimada');
    if (window.UI) window.UI.addNotification('Você foi queimado! Voltando em 3s...', 'error');
    setTimeout(() => {
      eliminated.delete(peerId);
      if (window.Player) window.Player.respawn();
      if (window.UI) window.UI.updateHealth(100);
    }, 3000);
  }
  // Broadcast
  if (window.Network) {
    window.Network.broadcast({
      type: 'mode',
      action: 'eliminate',
      id: window.PeerAPI.getMyId(),
      peerId: peerId,
      byPeerId: byPeerId
    });
  }
}

// Animação de arremesso (move o braço direito)
function startThrowAnimation() {
  throwAnimating = true;
  throwAnimStart = performance.now();
  // Aplica no avatar local
  if (window.Player && window.Avatar) {
    const mesh = window.Player.getPlayerMesh();
    if (mesh) mesh.userData.throwAnim = throwAnimStart;
  }
  // Broadcast emote
  if (window.Network) {
    window.Network.broadcast({
      type: 'emote',
      id: window.PeerAPI.getMyId(),
      emote: 'throw'
    });
  }
}

// Recebe dados de bola da rede
function receiveBallData(data) {
  if (data.id === window.PeerAPI.getMyId()) return;
  if (data.action === 'spawn') {
    // Cria bola remota
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.3, 16, 12),
      new THREE.MeshPhongMaterial({ color: 0xff6b35, emissive: 0x331100 })
    );
    mesh.position.set(data.x, data.y, data.z);
    scene.add(mesh);
    const shape = new CANNON.Sphere(0.3);
    const body = new CANNON.Body({
      mass: 1, shape,
      position: new CANNON.Vec3(data.x, data.y, data.z),
      material: window.Physics.getWorld().materials.objectMat,
      linearDamping: 0.1
    });
    body.velocity.set(data.vx, data.vy, data.vz);
    window.Physics.getWorld().addBody(body);

    const trailGeom = new THREE.BufferGeometry();
    const trailPositions = new Float32Array(60 * 3);
    trailGeom.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
    const trail = new THREE.Line(trailGeom, new THREE.LineBasicMaterial({
      color: 0xff6b35, transparent: true, opacity: 0.7
    }));
    trail.frustumCulled = false;
    scene.add(trail);

    balls.push({
      mesh, body, trail, trailPoints: [],
      holder: null, lastThrower: data.thrower,
      spawnTime: performance.now(), active: true
    });
  } else if (data.action === 'throw') {
    // Encontra a bola mais próxima da posição de throw e atualiza
    let closest = null;
    let closestDist = 5;
    for (const b of balls) {
      const d = b.mesh.position.distanceTo(new THREE.Vector3(data.x, data.y, data.z));
      if (d < closestDist) { closestDist = d; closest = b; }
    }
    if (closest) {
      closest.holder = null;
      closest.lastThrower = data.thrower;
      closest.body.velocity.set(data.vx, data.vy, data.vz);
      closest.mesh.position.set(data.x, data.y, data.z);
    }
    // Animação de arremesso no avatar remoto
    const rp = window.Network ? window.Network.getRemotePlayer(data.id) : null;
    if (rp && rp.mesh) {
      rp.mesh.userData.throwAnim = performance.now();
    }
  } else if (data.action === 'catch') {
    const ball = balls[data.ballIndex];
    if (ball) ball.holder = data.id;
  } else if (data.action === 'sync') {
    // Sincroniza posição da bola
    const ball = balls[data.ballIndex];
    if (ball && !ball.holder) {
      ball.body.position.set(data.x, data.y, data.z);
      ball.body.velocity.set(data.vx, data.vy, data.vz);
    }
  }
}

function receiveModeData(data) {
  if (data.action === 'eliminate') {
    eliminatePlayer(data.peerId, data.byPeerId);
  } else if (data.action === 'score') {
    if (data.team === 1) scores.team1++;
    else if (data.team === 2) scores.team2++;
    if (window.UI) window.UI.addNotification(`Ponto! Time ${data.team}: ${data.team === 1 ? scores.team1 : scores.team2}`, 'success');
  }
}

// ===== Update =====
function GameModeUpdate(delta) {
  catchCooldown = Math.max(0, catchCooldown - delta);

  // Atualiza todas as bolas
  for (let i = balls.length - 1; i >= 0; i--) {
    const ball = balls[i];
    if (!ball.active) continue;

    if (ball.holder === 'me') {
      // Bola segue na mão do jogador (em frente à câmera)
      const camPos = window.Player.getCameraPosition();
      const camDir = window.Player.getCameraDirection();
      const handPos = camPos.clone().add(camDir.clone().multiplyScalar(1.0));
      handPos.y -= 0.3;
      ball.mesh.position.copy(handPos);
      ball.body.position.set(handPos.x, handPos.y, handPos.z);
      ball.body.velocity.set(0, 0, 0);
      ball.body.angularVelocity.set(0, 0, 0);
    } else if (ball.holder) {
      // Bola segue jogador remoto (na mão)
      const rp = window.Network.getRemotePlayer(ball.holder);
      if (rp && rp.mesh) {
        const handPos = rp.mesh.position.clone();
        handPos.y += 1.2;
        handPos.x += Math.cos(rp.currentRot.y) * 0.5;
        handPos.z -= Math.sin(rp.currentRot.y) * 0.5;
        ball.mesh.position.copy(handPos);
        ball.body.position.set(handPos.x, handPos.y, handPos.z);
        ball.body.velocity.set(0, 0, 0);
      }
    } else {
      // Bola livre — sincroniza mesh com body
      ball.mesh.position.copy(ball.body.position);
      ball.mesh.quaternion.copy(ball.body.quaternion);
    }

    // Atualiza trail
    ball.trailPoints.push(ball.mesh.position.clone());
    if (ball.trailPoints.length > 60) ball.trailPoints.shift();
    const positions = ball.trail.geometry.attributes.position.array;
    for (let j = 0; j < 60; j++) {
      if (j < ball.trailPoints.length) {
        const p = ball.trailPoints[j];
        positions[j*3] = p.x;
        positions[j*3+1] = p.y;
        positions[j*3+2] = p.z;
      } else {
        positions[j*3] = ball.mesh.position.x;
        positions[j*3+1] = ball.mesh.position.y;
        positions[j*3+2] = ball.mesh.position.z;
      }
    }
    ball.trail.geometry.attributes.position.needsUpdate = true;
    ball.trail.geometry.setDrawRange(0, ball.trailPoints.length);

    // Remove bolas antigas (30s) ou que caíram fora do mapa
    if (performance.now() - ball.spawnTime > 30000 || ball.body.position.y < -20) {
      removeBall(i);
    }
  }

  // Sincroniza bolas que estou segurando (20Hz implícito — envia posição)
  // (omitido para não floodar a rede)
}

function removeBall(index) {
  const ball = balls[index];
  if (!ball) return;
  if (ball.mesh && ball.mesh.parent) ball.mesh.parent.remove(ball.mesh);
  if (ball.mesh.geometry) ball.mesh.geometry.dispose();
  if (ball.mesh.material) ball.mesh.material.dispose();
  if (ball.trail && ball.trail.parent) ball.trail.parent.remove(ball.trail);
  if (ball.trail.geometry) ball.trail.geometry.dispose();
  if (window.Physics && ball.body) {
    try { window.Physics.getWorld().removeBody(ball.body); } catch(e){}
  }
  balls.splice(index, 1);
}

function clearAllBalls() {
  for (let i = balls.length - 1; i >= 0; i--) removeBall(i);
}

// ===== Modos específicos =====
function setupQueimada() {
  currentMode = 'queimada';
  scores = { team1: 0, team2: 0 };
  eliminated.clear();
  // Divide times baseado no peerId hash
  const myId = window.PeerAPI.getMyId();
  team = (myId.charCodeAt(0) + myId.charCodeAt(1)) % 2 === 0 ? 1 : 2;
  // Spawna 3 bolas no centro
  if (window.PeerAPI.isHost()) {
    setTimeout(() => {
      for (let i = 0; i < 3; i++) {
        spawnBall(
          new THREE.Vector3(-2 + i * 2, 5, 0),
          new THREE.Vector3(0, 0, 0),
          null
        );
      }
    }, 1000);
  }
  if (window.UI) {
    window.UI.addNotification(`QUEIMADA! Você é do Time ${team === 1 ? 'Azul' : 'Vermelho'}`, 'info');
    window.UI.addNotification('Q: Pegar bola · Botão Esq: Arremessar', 'info');
  }
}

function setupFutebol() {
  currentMode = 'futebol';
  scores = { team1: 0, team2: 0 };
  const myId = window.PeerAPI.getMyId();
  team = (myId.charCodeAt(0) + myId.charCodeAt(1)) % 2 === 0 ? 1 : 2;
  if (window.PeerAPI.isHost()) {
    setTimeout(() => {
      spawnBall(new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 0, 0), null);
    }, 1000);
  }
  if (window.UI) {
    window.UI.addNotification(`FUTEBOL! Você é do Time ${team === 1 ? 'Azul' : 'Vermelho'}`, 'info');
    window.UI.addNotification('Q: Chutar (aproxima da bola)', 'info');
  }
}

function setupCTF() {
  currentMode = 'ctf';
  scores = { team1: 0, team2: 0 };
  flagCarrier = null;
  const myId = window.PeerAPI.getMyId();
  team = (myId.charCodeAt(0) + myId.charCodeAt(1)) % 2 === 0 ? 1 : 2;
  // Cria bandeiras
  flags = {
    flag1: createFlag(new THREE.Vector3(-30, 0, 0), 0x3b82f6),
    flag2: createFlag(new THREE.Vector3(30, 0, 0), 0xef4444)
  };
  if (window.UI) {
    window.UI.addNotification(`CAPTURE THE FLAG! Você é do Time ${team === 1 ? 'Azul' : 'Vermelho'}`, 'info');
    window.UI.addNotification('Pegue a bandeira inimiga e leve para sua base', 'info');
  }
}

function createFlag(position, color) {
  const group = new THREE.Group();
  const pole = new THREE.Mesh(
    new THREE.CylinderGeometry(0.05, 0.05, 3, 8),
    new THREE.MeshLambertMaterial({ color: 0x666666 })
  );
  pole.position.y = 1.5;
  group.add(pole);
  const flag = new THREE.Mesh(
    new THREE.PlaneGeometry(1, 0.6),
    new THREE.MeshLambertMaterial({ color, side: THREE.DoubleSide })
  );
  flag.position.set(0.5, 2.5, 0);
  group.add(flag);
  group.position.copy(position);
  scene.add(group);
  return group;
}

function setupFree() {
  currentMode = 'free';
  scores = { team1: 0, team2: 0 };
  eliminated.clear();
  flagCarrier = null;
  if (flags) {
    if (flags.flag1 && flags.flag1.parent) flags.flag1.parent.remove(flags.flag1);
    if (flags.flag2 && flags.flag2.parent) flags.flag2.parent.remove(flags.flag2);
    flags = null;
  }
}

function setMode(mode) {
  clearAllBalls();
  setupFree();
  if (mode === 'queimada') setupQueimada();
  else if (mode === 'futebol') setupFutebol();
  else if (mode === 'ctf') setupCTF();
}

function getMode() { return currentMode; }
function getTeam() { return team; }
function getScores() { return scores; }

window.GameMode = {
  init: GameModeInit,
  update: GameModeUpdate,
  spawnBall, throwBall, tryCatchBall,
  receiveBall: receiveBallData,
  receiveMode: receiveModeData,
  setMode, getMode, getTeam, getScores,
  clearAllBalls,
  TEAM_COLORS
};
})();
