// ============================================================
// save.js — Persistência local (LocalStorage)
// Sem imports — usa window.Save
// ============================================================
(function() {
'use strict';

const STORAGE_KEY = 'sandbox3d_save_v2';

let data = {
  avatar: {
    headColor: '#ffcc99',
    bodyColor: '#3b82f6',
    armsColor: '#ffcc99',
    legsColor: '#1e293b',
    hairStyle: 'short',
    hairColor: '#3a2a1a',
    clothes: 'tshirt',
    clothesColor: '#10b981',
    shoes: 'sneakers',
    shoesColor: '#0f172a'
  },
  accessories: {
    hat: null, glasses: null, mask: null, back: null, cape: null
  },
  inventory: {
    items: ['pistol', 'rifle', 'shotgun', 'sniper', 'launcher', 'grenade', 'smg', 'crossbow', 'flame',
            'cap', 'sunglasses', 'backpack'],
    equipped: { weapon1: 'pistol', weapon2: 'rifle', weapon3: null, hat: null, mask: null, back: null }
  },
  shop: {
    coins: 1000,
    owned: ['pistol', 'rifle', 'shotgun', 'sniper', 'launcher', 'grenade', 'smg', 'crossbow', 'flame',
            'cap', 'sunglasses', 'backpack']
  },
  settings: {
    sensitivity: 1, volume: 0.7, fov: 75,
    shadows: true, particles: true, bloom: true, fpMode: true
  },
  playerName: 'Jogador',
  savedMaps: {}
};

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      data = { ...data, ...parsed };
      data.avatar = { ...data.avatar, ...parsed.avatar };
      data.accessories = { ...data.accessories, ...parsed.accessories };
      data.inventory = { ...data.inventory, ...parsed.inventory };
      data.shop = { ...data.shop, ...parsed.shop };
      data.settings = { ...data.settings, ...parsed.settings };
    }
  } catch (e) { console.warn('[SAVE] Falha ao carregar:', e); }
}

function save() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
  catch (e) { console.warn('[SAVE] Falha ao salvar:', e); }
}

window.Save = {
  getAvatar: () => data.avatar,
  setAvatar: (av) => { data.avatar = { ...data.avatar, ...av }; save(); },
  getAccessories: () => data.accessories,
  setAccessories: (acc) => { data.accessories = { ...data.accessories, ...acc }; save(); },
  getInventory: () => data.inventory,
  setInventory: (inv) => { data.inventory = { ...data.inventory, ...inv }; save(); },
  getShop: () => data.shop,
  setShop: (s) => { data.shop = { ...data.shop, ...s }; save(); },
  getSettings: () => data.settings,
  setSettings: (s) => { data.settings = { ...data.settings, ...s }; save(); },
  getPlayerName: () => data.playerName,
  setPlayerName: (name) => { data.playerName = name.substring(0, 16); save(); },
  getSavedMaps: () => data.savedMaps,
  saveMap: (name, mapData) => { data.savedMaps[name] = mapData; save(); },
  loadMap: (name) => data.savedMaps[name] || null,
  deleteMap: (name) => { delete data.savedMaps[name]; save(); },
  save
};

load();
})();
