// ============================================================
// effects.js — VFX turbinados: partículas, bloom, trails, explosões
// ============================================================
(function() {
'use strict';

let scene = null;
let particleSystems = [];
let particlesEnabled = true;
let bloomEnabled = true;
let glowSprites = [];

function EffectsInit(scn) {
  scene = scn;
  const settings = window.Save ? window.Save.getSettings() : {};
  particlesEnabled = settings.particles !== false;
  bloomEnabled = settings.bloom !== false;
}

// ===== Material para partículas com glow (shader custom) =====
function makeGlowParticleMaterial(color, opacity) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(color) },
      uOpacity: { value: opacity || 1.0 }
    },
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    vertexShader: `
      varying vec3 vPos;
      void main() {
        vPos = position;
        vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = 12.0 * (1.0 / -mvPos.z) * 30.0;
        gl_Position = projectionMatrix * mvPos;
      }
    `,
    fragmentShader: `
      uniform vec3 uColor;
      uniform float uOpacity;
      void main() {
        vec2 c = gl_PointCoord - 0.5;
        float d = length(c);
        float alpha = smoothstep(0.5, 0.0, d);
        alpha *= alpha;
        gl_FragColor = vec4(uColor, alpha * uOpacity);
      }
    `
  });
}

// ===== Muzzle flash melhorado =====
function createMuzzleFlash(x, y, z, dx, dy, dz) {
  if (!scene) return;
  // Luz flash
  const flash = new THREE.PointLight(0xffaa33, 12, 12);
  flash.position.set(x, y, z);
  scene.add(flash);
  particleSystems.push({ mesh: null, light: flash, life: 0.1, maxLife: 0.1, type: 'flash' });

  if (particlesEnabled) {
    // Cone de faíscas
    for (let i = 0; i < 12; i++) {
      const spark = new THREE.Mesh(
        new THREE.SphereGeometry(0.035, 6, 6),
        new THREE.MeshBasicMaterial({ color: i % 2 === 0 ? 0xffee66 : 0xff7700, transparent: true })
      );
      spark.position.set(x, y, z);
      scene.add(spark);
      const spread = 0.15;
      particleSystems.push({
        mesh: spark, life: 0.4, maxLife: 0.4,
        velocity: new THREE.Vector3(
          dx + (Math.random() - 0.5) * spread,
          dy + (Math.random() - 0.5) * spread,
          dz + (Math.random() - 0.5) * spread
        ).multiplyScalar(2 + Math.random() * 3),
        gravity: true, fade: true, type: 'spark'
      });
    }
    // Fumaça cinza
    for (let i = 0; i < 4; i++) {
      const smoke = new THREE.Mesh(
        new THREE.SphereGeometry(0.1 + Math.random() * 0.1, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0x999999, transparent: true, opacity: 0.6 })
      );
      smoke.position.set(x, y, z);
      scene.add(smoke);
      particleSystems.push({
        mesh: smoke, life: 0.8, maxLife: 0.8,
        velocity: new THREE.Vector3((Math.random() - 0.5) * 0.5, Math.random() * 0.5 + 0.3, (Math.random() - 0.5) * 0.5),
        gravity: false, fade: true, scale: true, type: 'smoke'
      });
    }
    // Flash visual (esfera brilhante)
    const flashSphere = new THREE.Mesh(
      new THREE.SphereGeometry(0.15, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xffee88, transparent: true, opacity: 1.0, blending: THREE.AdditiveBlending })
    );
    flashSphere.position.set(x, y, z);
    scene.add(flashSphere);
    particleSystems.push({
      mesh: flashSphere, life: 0.08, maxLife: 0.08,
      fade: true, scale: true, scaleTo: 3, type: 'flashSphere'
    });
  }
}

// ===== Impacto melhorado =====
function createImpact(x, y, z, nx, ny, nz, color) {
  if (!scene) return;
  color = color || 0x888888;
  // Buraco de bala (decal)
  const hole = new THREE.Mesh(
    new THREE.CircleGeometry(0.07, 10),
    new THREE.MeshBasicMaterial({ color: 0x111111, transparent: true, opacity: 0.9 })
  );
  hole.position.set(x, y, z);
  hole.lookAt(x + nx, y + ny, z + nz);
  scene.add(hole);
  particleSystems.push({ mesh: hole, life: 8, maxLife: 8, fade: true, type: 'hole' });

  if (particlesEnabled) {
    // Faíscas douradas brilhantes
    for (let i = 0; i < 14; i++) {
      const spark = new THREE.Mesh(
        new THREE.SphereGeometry(0.025, 4, 4),
        new THREE.MeshBasicMaterial({
          color: i % 3 === 0 ? 0xffffff : (i % 3 === 1 ? 0xffcc44 : 0xff5500),
          transparent: true,
          blending: THREE.AdditiveBlending
        })
      );
      spark.position.set(x, y, z);
      scene.add(spark);
      particleSystems.push({
        mesh: spark, life: 0.5 + Math.random() * 0.3, maxLife: 0.5,
        velocity: new THREE.Vector3(
          nx * 2 + (Math.random() - 0.5) * 4,
          ny * 2 + (Math.random() - 0.5) * 4 + 1,
          nz * 2 + (Math.random() - 0.5) * 4
        ),
        gravity: true, fade: true, type: 'spark'
      });
    }
    // Fumaça de impacto
    for (let i = 0; i < 3; i++) {
      const smoke = new THREE.Mesh(
        new THREE.SphereGeometry(0.12, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0x555555, transparent: true, opacity: 0.5 })
      );
      smoke.position.set(x, y, z);
      scene.add(smoke);
      particleSystems.push({
        mesh: smoke, life: 1.0, maxLife: 1.0,
        velocity: new THREE.Vector3(nx * 0.3 + (Math.random() - 0.5) * 0.3, ny * 0.3 + 0.3 + Math.random() * 0.2, nz * 0.3 + (Math.random() - 0.5) * 0.3),
        gravity: false, fade: true, scale: true, type: 'smoke'
      });
    }
    // Anel de choque (ring expanding)
    const ring = new THREE.Mesh(
      new THREE.RingGeometry(0.05, 0.08, 16),
      new THREE.MeshBasicMaterial({ color: 0xffaa44, transparent: true, opacity: 0.9, side: THREE.DoubleSide, blending: THREE.AdditiveBlending })
    );
    ring.position.set(x, y, z);
    ring.lookAt(x + nx, y + ny, z + nz);
    scene.add(ring);
    particleSystems.push({
      mesh: ring, life: 0.3, maxLife: 0.3,
      fade: true, scale: true, scaleTo: 4, type: 'ring'
    });
  }
}

// ===== Explosão turbinada =====
function createExplosion(x, y, z, radius) {
  if (!scene) return;
  radius = radius || 5;
  // Luz forte
  const light = new THREE.PointLight(0xff6600, 35, radius * 6);
  light.position.set(x, y, z);
  scene.add(light);
  particleSystems.push({ mesh: null, light, life: 0.5, maxLife: 0.5, type: 'flash' });

  // Bola de fogo expandindo (com material glow)
  const fire = new THREE.Mesh(
    new THREE.SphereGeometry(radius * 0.4, 24, 16),
    new THREE.MeshBasicMaterial({
      color: 0xff5500, transparent: true, opacity: 1.0,
      blending: THREE.AdditiveBlending
    })
  );
  fire.position.set(x, y, z);
  scene.add(fire);
  particleSystems.push({
    mesh: fire, life: 0.6, maxLife: 0.6,
    fade: true, scale: true, scaleTo: radius * 1.8, type: 'fire'
  });

  // Núcleo branco
  const core = new THREE.Mesh(
    new THREE.SphereGeometry(radius * 0.2, 16, 12),
    new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 1.0, blending: THREE.AdditiveBlending })
  );
  core.position.set(x, y, z);
  scene.add(core);
  particleSystems.push({
    mesh: core, life: 0.25, maxLife: 0.25,
    fade: true, scale: true, scaleTo: radius * 0.8, type: 'fire'
  });

  // Onda de choque (anel horizontal)
  const shockwave = new THREE.Mesh(
    new THREE.RingGeometry(0.3, 0.5, 32),
    new THREE.MeshBasicMaterial({ color: 0xffaa66, transparent: true, opacity: 0.9, side: THREE.DoubleSide, blending: THREE.AdditiveBlending })
  );
  shockwave.position.set(x, y, z);
  shockwave.rotation.x = -Math.PI / 2;
  scene.add(shockwave);
  particleSystems.push({
    mesh: shockwave, life: 0.8, maxLife: 0.8,
    fade: true, scale: true, scaleTo: radius * 3, type: 'shockwave'
  });

  if (particlesEnabled) {
    // Fumaça escura densa
    for (let i = 0; i < 40; i++) {
      const smoke = new THREE.Mesh(
        new THREE.SphereGeometry(0.3 + Math.random() * 0.6, 8, 6),
        new THREE.MeshBasicMaterial({
          color: new THREE.Color().setHSL(0, 0, 0.15 + Math.random() * 0.2),
          transparent: true, opacity: 0.7
        })
      );
      smoke.position.set(x, y, z);
      scene.add(smoke);
      const ang = Math.random() * Math.PI * 2;
      const elev = Math.random() * Math.PI * 0.5;
      const spd = 4 + Math.random() * 8;
      particleSystems.push({
        mesh: smoke, life: 2 + Math.random(), maxLife: 2,
        velocity: new THREE.Vector3(
          Math.cos(ang) * Math.cos(elev) * spd,
          Math.sin(elev) * spd + 3,
          Math.sin(ang) * Math.cos(elev) * spd
        ),
        gravity: false, fade: true, scale: true, type: 'smoke'
      });
    }
    // Faíscas brilhantes
    for (let i = 0; i < 50; i++) {
      const spark = new THREE.Mesh(
        new THREE.SphereGeometry(0.06, 6, 6),
        new THREE.MeshBasicMaterial({
          color: i % 4 === 0 ? 0xffffff : (i % 4 === 1 ? 0xffaa00 : 0xff4400),
          transparent: true, blending: THREE.AdditiveBlending
        })
      );
      spark.position.set(x, y, z);
      scene.add(spark);
      const ang = Math.random() * Math.PI * 2;
      const elev = Math.random() * Math.PI - Math.PI/2;
      const spd = 10 + Math.random() * 15;
      particleSystems.push({
        mesh: spark, life: 1 + Math.random() * 0.5, maxLife: 1,
        velocity: new THREE.Vector3(
          Math.cos(ang) * Math.cos(elev) * spd,
          Math.sin(elev) * spd + 3,
          Math.sin(ang) * Math.cos(elev) * spd
        ),
        gravity: true, fade: true, type: 'spark',
        trail: true, trailColor: 0xffaa00
      });
    }
    // Fragmentos (cinzas voando)
    for (let i = 0; i < 15; i++) {
      const frag = new THREE.Mesh(
        new THREE.BoxGeometry(0.1, 0.1, 0.1),
        new THREE.MeshStandardMaterial({ color: 0x222222 })
      );
      frag.position.set(x, y, z);
      scene.add(frag);
      const ang = Math.random() * Math.PI * 2;
      const spd = 5 + Math.random() * 8;
      particleSystems.push({
        mesh: frag, life: 2, maxLife: 2,
        velocity: new THREE.Vector3(
          Math.cos(ang) * spd,
          5 + Math.random() * 8,
          Math.sin(ang) * spd
        ),
        gravity: true, fade: true, angularVelocity: new THREE.Vector3(Math.random() * 10, Math.random() * 10, Math.random() * 10),
        type: 'fragment'
      });
    }
  }
}

// ===== Trail de bala =====
function createBulletTrail(from, to, color) {
  if (!scene) return;
  color = color || 0xffff88;
  // Trail brilhante principal
  const geom = new THREE.BufferGeometry().setFromPoints([from, to]);
  const mat = new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.95, linewidth: 3, blending: THREE.AdditiveBlending });
  const line = new THREE.Line(geom, mat);
  scene.add(line);
  particleSystems.push({ mesh: line, life: 0.12, maxLife: 0.12, fade: true, type: 'trail' });
  // Trail secundário (mais grosso, glow)
  const glowMat = new THREE.LineBasicMaterial({ color: 0xff8800, transparent: true, opacity: 0.5, blending: THREE.AdditiveBlending });
  const glowLine = new THREE.Line(geom.clone(), glowMat);
  scene.add(glowLine);
  particleSystems.push({ mesh: glowLine, life: 0.18, maxLife: 0.18, fade: true, type: 'trail' });
}

function createHitMarker(position) {
  if (!scene) return;
  const marker = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 12, 10),
    new THREE.MeshBasicMaterial({ color: 0xff0044, transparent: true, opacity: 1.0, blending: THREE.AdditiveBlending })
  );
  marker.position.copy(position);
  scene.add(marker);
  particleSystems.push({
    mesh: marker, life: 0.4, maxLife: 0.4,
    fade: true, scale: true, scaleTo: 3, type: 'marker'
  });
  // Anel de impacto vermelho
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.2, 0.3, 16),
    new THREE.MeshBasicMaterial({ color: 0xff0044, transparent: true, opacity: 1.0, side: THREE.DoubleSide, blending: THREE.AdditiveBlending })
  );
  ring.position.copy(position);
  // Olha para a câmera se disponível
  const cam = window.GameState && window.GameState.camera;
  if (cam) ring.lookAt(cam.position);
  scene.add(ring);
  particleSystems.push({
    mesh: ring, life: 0.4, maxLife: 0.4,
    fade: true, scale: true, scaleTo: 4, type: 'ring'
  });
}

function createBlood(x, y, z, dir) {
  if (!scene || !particlesEnabled) return;
  for (let i = 0; i < 20; i++) {
    const drop = new THREE.Mesh(
      new THREE.SphereGeometry(0.06, 6, 6),
      new THREE.MeshBasicMaterial({ color: 0xaa0000, transparent: true })
    );
    drop.position.set(x, y, z);
    scene.add(drop);
    particleSystems.push({
      mesh: drop, life: 0.7, maxLife: 0.7,
      velocity: new THREE.Vector3(
        dir.x * 3 + (Math.random() - 0.5) * 5,
        dir.y * 3 + Math.random() * 3,
        dir.z * 3 + (Math.random() - 0.5) * 5
      ),
      gravity: true, fade: true, type: 'blood'
    });
  }
  // Pulso vermelho central
  const pulse = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xff0000, transparent: true, opacity: 0.7, blending: THREE.AdditiveBlending })
  );
  pulse.position.set(x, y, z);
  scene.add(pulse);
  particleSystems.push({
    mesh: pulse, life: 0.3, maxLife: 0.3,
    fade: true, scale: true, scaleTo: 2, type: 'pulse'
  });
}

// ===== Partículas ambientais (poeira, neve, chuva) =====
function createAmbientParticles(count, type) {
  if (!scene || !particlesEnabled) return null;
  type = type || 'dust';
  const geometry = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  const velocities = [];
  const colors = new Float32Array(count * 3);
  const sizes = new Float32Array(count);

  for (let i = 0; i < count; i++) {
    positions[i*3] = (Math.random() - 0.5) * 100;
    positions[i*3+1] = Math.random() * 30;
    positions[i*3+2] = (Math.random() - 0.5) * 100;
    if (type === 'snow') {
      velocities.push(new THREE.Vector3((Math.random() - 0.5) * 0.5, -Math.random() * 1 - 0.5, (Math.random() - 0.5) * 0.5));
      colors[i*3] = 1; colors[i*3+1] = 1; colors[i*3+2] = 1;
      sizes[i] = 0.15 + Math.random() * 0.1;
    } else if (type === 'rain') {
      velocities.push(new THREE.Vector3(0.2, -25, 0));
      colors[i*3] = 0.5; colors[i*3+1] = 0.7; colors[i*3+2] = 1.0;
      sizes[i] = 0.04;
    } else if (type === 'leaves') {
      velocities.push(new THREE.Vector3((Math.random() - 0.5) * 1.5, -Math.random() * 0.5 - 0.1, (Math.random() - 0.5) * 1.5));
      const c = new THREE.Color().setHSL(0.08 + Math.random() * 0.05, 0.7, 0.4);
      colors[i*3] = c.r; colors[i*3+1] = c.g; colors[i*3+2] = c.b;
      sizes[i] = 0.15;
    } else {
      velocities.push(new THREE.Vector3((Math.random() - 0.5) * 0.3, -Math.random() * 0.5 - 0.1, (Math.random() - 0.5) * 0.3));
      colors[i*3] = 0.9; colors[i*3+1] = 0.85; colors[i*3+2] = 0.6;
      sizes[i] = 0.04 + Math.random() * 0.06;
    }
  }
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

  const material = new THREE.PointsMaterial({
    size: type === 'rain' ? 0.06 : 0.15,
    vertexColors: true,
    transparent: true, opacity: type === 'rain' ? 0.7 : 0.6,
    blending: type === 'dust' ? THREE.AdditiveBlending : THREE.NormalBlending,
    depthWrite: false
  });
  const points = new THREE.Points(geometry, material);
  points.userData.velocities = velocities;
  points.userData.type = type;
  scene.add(points);
  return points;
}

function updateAmbientParticles(points, delta) {
  if (!points) return;
  const positions = points.geometry.attributes.position.array;
  const velocities = points.userData.velocities;
  const type = points.userData.type;
  const camPos = (window.GameState && window.GameState.camera) ? window.GameState.camera.position : { x: 0, z: 0 };
  for (let i = 0; i < velocities.length; i++) {
    positions[i*3] += velocities[i].x * delta;
    positions[i*3+1] += velocities[i].y * delta;
    positions[i*3+2] += velocities[i].z * delta;
    // Folhas giram
    if (type === 'leaves') {
      positions[i*3] += Math.sin(performance.now() * 0.001 + i) * 0.05;
    }
    // Reset
    if (positions[i*3+1] < 0) {
      positions[i*3] = (Math.random() - 0.5) * 100 + camPos.x;
      positions[i*3+1] = 30;
      positions[i*3+2] = (Math.random() - 0.5) * 100 + camPos.z;
    }
  }
  points.geometry.attributes.position.needsUpdate = true;
}

// ===== Glow sprite (para luzes mágicas, fadas, etc) =====
function createGlowSprite(position, color, size) {
  if (!scene) return null;
  size = size || 1;
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({
    map: makeGlowTexture(color),
    blending: THREE.AdditiveBlending,
    transparent: true,
    depthWrite: false
  }));
  sprite.position.copy(position);
  sprite.scale.set(size, size, 1);
  scene.add(sprite);
  glowSprites.push(sprite);
  return sprite;
}

function makeGlowTexture(color) {
  const canvas = document.createElement('canvas');
  canvas.width = 64; canvas.height = 64;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  const c = new THREE.Color(color);
  const hex = '#' + c.getHexString();
  grad.addColorStop(0, hex);
  grad.addColorStop(0.5, hex + '88');
  grad.addColorStop(1, hex + '00');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(canvas);
}

// ===== Trail de movimento para objetos =====
function createMovingTrail(position, color) {
  if (!scene) return;
  const geom = new THREE.SphereGeometry(0.1, 6, 6);
  const mat = new THREE.MeshBasicMaterial({ color: color || 0xff6b35, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending });
  const trail = new THREE.Mesh(geom, mat);
  trail.position.copy(position);
  scene.add(trail);
  particleSystems.push({
    mesh: trail, life: 0.4, maxLife: 0.4,
    fade: true, scale: true, scaleTo: 0.5, type: 'trailDot'
  });
}

// ===== Update todos os sistemas =====
function EffectsUpdate(delta) {
  for (let i = particleSystems.length - 1; i >= 0; i--) {
    const p = particleSystems[i];
    p.life -= delta;

    if (p.light) p.light.intensity *= 0.85;

    if (p.mesh) {
      if (p.velocity) {
        p.mesh.position.x += p.velocity.x * delta;
        p.mesh.position.y += p.velocity.y * delta;
        p.mesh.position.z += p.velocity.z * delta;
        if (p.gravity) p.velocity.y -= 18 * delta;
      }
      if (p.angularVelocity) {
        p.mesh.rotation.x += p.angularVelocity.x * delta;
        p.mesh.rotation.y += p.angularVelocity.y * delta;
        p.mesh.rotation.z += p.angularVelocity.z * delta;
      }
      if (p.fade && p.mesh.material) {
        const t = Math.max(0, p.life / p.maxLife);
        p.mesh.material.opacity = t;
      }
      if (p.scale) {
        const t = p.life / p.maxLife;
        const s = p.scaleTo ? Math.max(0.01, 1 + (1 - t) * (p.scaleTo)) : Math.max(0.01, 1 + (1 - t) * 1.5);
        p.mesh.scale.setScalar(s);
      }
    }
    if (p.life <= 0) {
      if (p.mesh) {
        scene.remove(p.mesh);
        if (p.mesh.geometry) p.mesh.geometry.dispose();
        if (p.mesh.material) p.mesh.material.dispose();
      }
      if (p.light) scene.remove(p.light);
      particleSystems.splice(i, 1);
    }
  }
}

function ClearAllEffects() {
  for (const p of particleSystems) {
    if (p.mesh) {
      scene.remove(p.mesh);
      if (p.mesh.geometry) p.mesh.geometry.dispose();
      if (p.mesh.material) p.mesh.material.dispose();
    }
    if (p.light) scene.remove(p.light);
  }
  particleSystems = [];
  for (const s of glowSprites) {
    scene.remove(s);
    if (s.material) {
      if (s.material.map) s.material.map.dispose();
      s.material.dispose();
    }
  }
  glowSprites = [];
}

window.Effects = {
  init: EffectsInit,
  createMuzzleFlash, createImpact, createExplosion,
  createBulletTrail, createHitMarker, createBlood,
  createAmbientParticles, updateAmbientParticles,
  createGlowSprite, createMovingTrail,
  update: EffectsUpdate, clearAll: ClearAllEffects
};
})();
