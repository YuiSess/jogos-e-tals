// ============================================================
// extras.js — Recursos extras: NPCs animados, veículos, minimapa, XP
// ============================================================
(function() {
'use strict';

let scene = null;
let camera = null;
let npcs = [];        // { mesh, type, target, speed, radius, origin }
let vehicles = [];   // { mesh, body, type, driver, maxSpeed, currentSpeed }
let minimapCanvas = null;
let minimapCtx = null;
let minimapEnabled = false;
let xp = 0;
let level = 1;

// ===== Init =====
function ExtrasInit(scn, cam) {
  scene = scn;
  camera = cam;
  // Carrega XP do save
  if (window.Save) {
    const s = window.Save.getSettings();
    xp = s.xp || 0;
    level = s.level || 1;
  }
  setupMinimap();
}

// ===== NPCs animados =====
function createNPC(position, type, color) {
  const npcGroup = new THREE.Group();
  type = type || 'walker';
  color = color || 0x88aaff;

  // Corpo
  const body = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.3, 0.8, 8, 12),
    new THREE.MeshStandardMaterial({ color, roughness: 0.7 })
  );
  body.position.y = 1;
  body.castShadow = true;
  npcGroup.add(body);
  // Cabeça
  const head = new THREE.Mesh(
    new THREE.SphereGeometry(0.25, 16, 12),
    new THREE.MeshStandardMaterial({ color: 0xffcc99, roughness: 0.7 })
  );
  head.position.y = 1.65;
  npcGroup.add(head);
  // Olhos
  for (const x of [-0.1, 0.1]) {
    const eye = new THREE.Mesh(
      new THREE.SphereGeometry(0.025, 6, 6),
      new THREE.MeshBasicMaterial({ color: 0x111111 })
    );
    eye.position.set(x, 1.7, 0.22);
    npcGroup.add(eye);
  }
  // Nome flutuante
  const nameCanvas = document.createElement('canvas');
  nameCanvas.width = 256; nameCanvas.height = 64;
  const nctx = nameCanvas.getContext('2d');
  nctx.fillStyle = 'rgba(0,0,0,0.6)';
  nctx.fillRect(0, 0, 256, 64);
  nctx.font = 'bold 26px sans-serif';
  nctx.fillStyle = '#aaaaff';
  nctx.textAlign = 'center';
  nctx.textBaseline = 'middle';
  const names = ['Bob', 'Ana', 'Carlos', 'Lia', 'Max', 'Eva', 'Tom', 'Zoe', 'Iris', 'Leo'];
  const npcName = names[Math.floor(Math.random() * names.length)];
  nctx.fillText('NPC ' + npcName, 128, 32);
  const nameTex = new THREE.CanvasTexture(nameCanvas);
  const nameSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: nameTex, depthTest: false }));
  nameSprite.position.set(0, 2.2, 0);
  nameSprite.scale.set(1.2, 0.3, 1);
  npcGroup.add(nameSprite);

  // Braços
  for (const x of [-0.35, 0.35]) {
    const arm = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.08, 0.6, 6, 8),
      new THREE.MeshStandardMaterial({ color: 0xffcc99 })
    );
    arm.position.set(x, 1.0, 0);
    arm.name = x < 0 ? 'leftArm' : 'rightArm';
    arm.geometry.translate(0, -0.3, 0);
    arm.position.y = 1.3;
    npcGroup.add(arm);
  }
  // Pernas
  for (const x of [-0.15, 0.15]) {
    const leg = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.1, 0.6, 6, 8),
      new THREE.MeshStandardMaterial({ color: 0x444466 })
    );
    leg.position.set(x, 0.5, 0);
    leg.name = x < 0 ? 'leftLeg' : 'rightLeg';
    leg.geometry.translate(0, -0.3, 0);
    leg.position.y = 0.6;
    npcGroup.add(leg);
  }

  npcGroup.position.copy(position);
  scene.add(npcGroup);

  const npc = {
    mesh: npcGroup,
    type,
    origin: position.clone(),
    radius: 15 + Math.random() * 10,
    angle: Math.random() * Math.PI * 2,
    speed: 1.5 + Math.random() * 1,
    animTime: 0,
    name: 'NPC ' + npcName
  };
  npcs.push(npc);
  return npc;
}

function ExtrasUpdate(delta) {
  const t = performance.now() / 1000;

  // Atualiza NPCs (andam em círculos ou patrulham)
  for (const npc of npcs) {
    npc.angle += delta * 0.3 * npc.speed;
    const x = npc.origin.x + Math.cos(npc.angle) * npc.radius;
    const z = npc.origin.z + Math.sin(npc.angle) * npc.radius;
    npc.mesh.position.x = x;
    npc.mesh.position.z = z;
    npc.mesh.rotation.y = -npc.angle + Math.PI / 2;

    // Anima braços e pernas
    npc.animTime += delta * npc.speed * 5;
    const leftArm = npc.mesh.getObjectByName('leftArm');
    const rightArm = npc.mesh.getObjectByName('rightArm');
    const leftLeg = npc.mesh.getObjectByName('leftLeg');
    const rightLeg = npc.mesh.getObjectByName('rightLeg');
    if (leftArm) leftArm.rotation.x = Math.sin(npc.animTime) * 0.5;
    if (rightArm) rightArm.rotation.x = -Math.sin(npc.animTime) * 0.5;
    if (leftLeg) leftLeg.rotation.x = -Math.sin(npc.animTime) * 0.5;
    if (rightLeg) rightLeg.rotation.x = Math.sin(npc.animTime) * 0.5;
  }

  // Atualiza minimapa
  if (minimapEnabled) updateMinimap();
}

// ===== Veículos =====
function createCar(position, color) {
  color = color || 0xff3333;
  const carGroup = new THREE.Group();

  // Corpo
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(2, 0.6, 4),
    new THREE.MeshStandardMaterial({ color, metalness: 0.6, roughness: 0.3 })
  );
  body.position.y = 0.6;
  body.castShadow = true;
  carGroup.add(body);
  // Cabine
  const cabin = new THREE.Mesh(
    new THREE.BoxGeometry(1.8, 0.5, 2),
    new THREE.MeshStandardMaterial({ color: 0x222244, metalness: 0.8, roughness: 0.1, transparent: true, opacity: 0.7 })
  );
  cabin.position.set(0, 1.1, -0.3);
  carGroup.add(cabin);
  // Rodas
  const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111 });
  const wheelGeo = new THREE.CylinderGeometry(0.4, 0.4, 0.3, 12);
  const wheels = [];
  for (const [x, z] of [[-1, 1.3], [1, 1.3], [-1, -1.3], [1, -1.3]]) {
    const wheel = new THREE.Mesh(wheelGeo, wheelMat);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(x, 0.4, z);
    wheel.name = 'wheel';
    carGroup.add(wheel);
    wheels.push(wheel);
  }
  // Faróis
  for (const x of [-0.6, 0.6]) {
    const light = new THREE.Mesh(
      new THREE.SphereGeometry(0.15, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xffffaa })
    );
    light.position.set(x, 0.7, 2);
    carGroup.add(light);
  }

  carGroup.position.copy(position);
  scene.add(carGroup);

  const vehicle = {
    mesh: carGroup,
    wheels,
    driver: null,
    maxSpeed: 15,
    currentSpeed: 0,
    rotation: 0,
    velocity: new THREE.Vector3()
  };
  vehicles.push(vehicle);
  return vehicle;
}

function tryEnterVehicle() {
  if (!window.Player) return false;
  const playerPos = window.Player.getPosition();
  for (const v of vehicles) {
    if (v.driver) continue;
    const dist = v.mesh.position.distanceTo(playerPos);
    if (dist < 2.5) {
      v.driver = 'me';
      if (window.UI) window.UI.addNotification('🚗 Você entrou no carro! WASD para dirigir, F para sair', 'success', 3000);
      return true;
    }
  }
  return false;
}

function exitVehicle() {
  for (const v of vehicles) {
    if (v.driver === 'me') {
      v.driver = null;
      v.currentSpeed = 0;
      // Move jogador para fora do carro
      if (window.Player && window.Player.getPlayerMesh) {
        const offset = new THREE.Vector3(2, 1, 0).applyEuler(v.mesh.rotation);
        if (window.Player.setRespawnPoint) {
          window.Player.setRespawnPoint(v.mesh.position.clone().add(offset));
        }
      }
      if (window.UI) window.UI.addNotification('🚗 Você saiu do carro', 'info');
      return true;
    }
  }
  return false;
}

function updateVehicles(delta, keys) {
  for (const v of vehicles) {
    if (v.driver === 'me') {
      // Inputs de direção
      let throttle = 0;
      let steer = 0;
      if (keys['KeyW']) throttle = 1;
      if (keys['KeyS']) throttle = -0.6;
      if (keys['KeyA']) steer = 1;
      if (keys['KeyD']) steer = -1;
      // Aceleração
      v.currentSpeed += throttle * delta * 10;
      v.currentSpeed *= 0.96;  // atrito
      v.currentSpeed = Math.max(-v.maxSpeed * 0.5, Math.min(v.maxSpeed, v.currentSpeed));
      // Curva
      if (Math.abs(v.currentSpeed) > 0.1) {
        v.rotation += steer * delta * 2 * (v.currentSpeed > 0 ? 1 : -1);
      }
      v.mesh.rotation.y = v.rotation;
      // Movimento
      const dx = Math.sin(v.rotation) * v.currentSpeed * delta;
      const dz = Math.cos(v.rotation) * v.currentSpeed * delta;
      v.mesh.position.x += dx;
      v.mesh.position.z += dz;
      // Rodas giram
      const wheelRot = v.currentSpeed * delta * 2;
      for (const w of v.wheels) {
        w.rotation.x += wheelRot;
      }
      // Jogador segue o carro
      if (window.Player && window.Player.getPlayerMesh) {
        const pm = window.Player.getPlayerMesh();
        if (pm) {
          pm.position.copy(v.mesh.position);
          pm.position.y = v.mesh.position.y + 0.7;
          pm.rotation.y = v.rotation;
          pm.visible = false;  // esconde dentro do carro
        }
        // Move o body físico também
        // (player body é kinematic)
        // O Player.update vai sobrescrever a posição, mas como o FP camera segue o body,
        // precisamos setar o body position
      }
      // Câmera segue o carro (em FP)
      if (window.Player && window.Player.isFP && window.Player.isFP()) {
        // Posiciona câmera no carro
        const cam = window.GameState.camera;
        if (cam) {
          cam.position.set(v.mesh.position.x, v.mesh.position.y + 1.5, v.mesh.position.z);
          // Aponta para frente do carro
          const lookX = v.mesh.position.x + Math.sin(v.rotation) * 10;
          const lookZ = v.mesh.position.z + Math.cos(v.rotation) * 10;
          cam.lookAt(lookX, v.mesh.position.y + 1, lookZ);
        }
      }
    }
  }
}

function isInVehicle() {
  for (const v of vehicles) {
    if (v.driver === 'me') return true;
  }
  return false;
}

// ===== Minimapa =====
function setupMinimap() {
  minimapCanvas = document.getElementById('minimapCanvas');
  if (!minimapCanvas) {
    minimapCanvas = document.createElement('canvas');
    minimapCanvas.id = 'minimapCanvas';
    minimapCanvas.width = 180;
    minimapCanvas.height = 180;
    minimapCanvas.style.cssText = 'position:fixed;bottom:90px;right:20px;border:2px solid #30363d;border-radius:50%;background:rgba(13,17,23,0.85);backdrop-filter:blur(6px);z-index:60;pointer-events:none;';
    document.body.appendChild(minimapCanvas);
  }
  minimapCtx = minimapCanvas.getContext('2d');
  minimapEnabled = true;
}

function updateMinimap() {
  if (!minimapCtx || !minimapCanvas) return;
  if (!window.GameState || !window.GameState.inGame) return;
  const ctx = minimapCtx;
  const w = minimapCanvas.width;
  const h = minimapCanvas.height;
  // Limpa
  ctx.clearRect(0, 0, w, h);
  // Fundo
  ctx.fillStyle = 'rgba(13,17,23,0.6)';
  ctx.beginPath();
  ctx.arc(w/2, h/2, w/2 - 4, 0, Math.PI * 2);
  ctx.fill();
  // Borda
  ctx.strokeStyle = '#58a6ff';
  ctx.lineWidth = 2;
  ctx.stroke();
  // Corta para o círculo
  ctx.save();
  ctx.beginPath();
  ctx.arc(w/2, h/2, w/2 - 4, 0, Math.PI * 2);
  ctx.clip();

  // Escala: 50 unidades do mundo = raio do minimapa
  const scale = (w/2 - 4) / 50;
  const cx = w / 2;
  const cy = h / 2;
  const playerPos = window.Player ? window.Player.getPosition() : { x: 0, z: 0 };
  const playerYaw = window.Player ? window.Player.getYaw() : 0;

  // NPCs (pontos verdes)
  for (const npc of npcs) {
    const dx = (npc.mesh.position.x - playerPos.x) * scale;
    const dz = (npc.mesh.position.z - playerPos.z) * scale;
    ctx.fillStyle = '#3fb950';
    ctx.beginPath();
    ctx.arc(cx + dx, cy + dz, 2, 0, Math.PI * 2);
    ctx.fill();
  }
  // Veículos (pontos laranjas)
  for (const v of vehicles) {
    const dx = (v.mesh.position.x - playerPos.x) * scale;
    const dz = (v.mesh.position.z - playerPos.z) * scale;
    ctx.fillStyle = '#ff6b35';
    ctx.beginPath();
    ctx.arc(cx + dx, cy + dz, 3, 0, Math.PI * 2);
    ctx.fill();
  }
  // Jogadores remotos (azul/vermelho)
  if (window.Network && window.Network.getRemotePlayers) {
    const remote = window.Network.getRemotePlayers();
    for (const [id, rp] of remote) {
      if (!rp.mesh) continue;
      const dx = (rp.mesh.position.x - playerPos.x) * scale;
      const dz = (rp.mesh.position.z - playerPos.z) * scale;
      const dist = Math.hypot(dx, dz);
      if (dist > w/2 - 4) continue;
      ctx.fillStyle = rp.health > 0 ? '#58a6ff' : '#666666';
      ctx.beginPath();
      ctx.arc(cx + dx, cy + dz, 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  // Jogador local (amarelo com direção)
  ctx.fillStyle = '#fbbf24';
  ctx.beginPath();
  ctx.arc(cx, cy, 4, 0, Math.PI * 2);
  ctx.fill();
  // Seta de direção
  ctx.strokeStyle = '#fbbf24';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  const arrowLen = 12;
  ctx.lineTo(cx - Math.sin(playerYaw) * arrowLen, cy - Math.cos(playerYaw) * arrowLen);
  ctx.stroke();
  ctx.restore();
}

// ===== Sistema de XP =====
function addXp(amount) {
  xp += amount;
  const needed = level * 100;
  if (xp >= needed) {
    xp -= needed;
    level++;
    if (window.UI) window.UI.addNotification(`🌟 Level Up! Você atingiu o nível ${level}!`, 'success', 4000);
    if (window.Chat) window.Chat.addSystem(`Nível up! Agora é nível ${level}.`);
    // VFX de level up
    if (window.Effects && window.Player) {
      const pos = window.Player.getPosition();
      for (let i = 0; i < 20; i++) {
        window.Effects.createExplosion(
          pos.x + (Math.random() - 0.5) * 6,
          pos.y + Math.random() * 3 + 2,
          pos.z + (Math.random() - 0.5) * 6,
          1.5
        );
      }
    }
  }
  // Salva
  if (window.Save) {
    const s = window.Save.getSettings();
    s.xp = xp;
    s.level = level;
    window.Save.setSettings(s);
  }
  if (window.UI) window.UI.updateXP(xp, level);
}

function getXp() { return xp; }
function getLevel() { return level; }

// ===== Modo espectador =====
let spectatorTarget = null;
let spectatorIndex = 0;

function enterSpectator() {
  spectatorMode = true;
  if (window.UI) window.UI.addNotification('👁️ Modo Espectador — assista os outros jogarem', 'info', 4000);
  // Esconde avatar
  if (window.Player && window.Player.getPlayerMesh) {
    const pm = window.Player.getPlayerMesh();
    if (pm) pm.visible = false;
  }
}

function exitSpectator() {
  spectatorMode = false;
  spectatorTarget = null;
  if (window.Player && window.Player.getPlayerMesh) {
    const pm = window.Player.getPlayerMesh();
    if (pm) pm.visible = !window.Player.isFP();
  }
}

function updateSpectator(delta) {
  if (!spectatorMode) return false;
  if (!window.Network) return true;
  const remote = window.Network.getRemotePlayers();
  const alivePlayers = [];
  for (const [id, rp] of remote) {
    if (rp.mesh && rp.health > 0) alivePlayers.push(rp);
  }
  if (alivePlayers.length === 0) {
    // Ninguém vivo — câmera livre aérea
    if (window.GameState && window.GameState.camera) {
      const t = performance.now() / 1000;
      const cam = window.GameState.camera;
      cam.position.set(Math.cos(t * 0.2) * 30, 20, Math.sin(t * 0.2) * 30);
      cam.lookAt(0, 0, 0);
    }
    return true;
  }
  // Segue o jogador atual
  if (!spectatorTarget || !alivePlayers.includes(spectatorTarget)) {
    spectatorTarget = alivePlayers[spectatorIndex % alivePlayers.length];
  }
  if (spectatorTarget && spectatorTarget.mesh && window.GameState && window.GameState.camera) {
    const cam = window.GameState.camera;
    const target = spectatorTarget.mesh.position;
    // Câmera atrás e acima do alvo
    const yaw = spectatorTarget.currentRot.y;
    const offset = new THREE.Vector3(
      Math.sin(yaw) * 4,
      2,
      Math.cos(yaw) * 4
    );
    cam.position.lerp(target.clone().add(offset), 0.1);
    cam.lookAt(target.x, target.y + 1.5, target.z);
  }
  return true;
}

function nextSpectatorTarget() {
  if (!spectatorMode) return;
  spectatorIndex++;
  spectatorTarget = null;
  if (window.UI) window.UI.addNotification('👁️ Trocando de jogador...', 'info', 1000);
}

function isSpectator() { return spectatorMode; }

// ===== Limpa tudo =====
function clearExtras() {
  for (const npc of npcs) {
    if (npc.mesh && npc.mesh.parent) npc.mesh.parent.remove(npc.mesh);
  }
  npcs = [];
  for (const v of vehicles) {
    if (v.mesh && v.mesh.parent) v.mesh.parent.remove(v.mesh);
  }
  vehicles = [];
}

window.Extras = {
  init: ExtrasInit,
  update: ExtrasUpdate,
  createNPC, createCar,
  tryEnterVehicle, exitVehicle, updateVehicles, isInVehicle,
  setupMinimap, updateMinimap,
  addXp, getXp, getLevel,
  enterSpectator, exitSpectator, updateSpectator, nextSpectatorTarget, isSpectator,
  clearAll: clearExtras,
  getNPCs: () => npcs,
  getVehicles: () => vehicles
};
})();
