// ============================================================
// peer.js — Gerenciamento de conexões PeerJS (P2P)
// ============================================================
(function() {
'use strict';

let peer = null;
let connections = [];
let myId = null;
let isHost = false;
let hostId = null;
let onPeerOpen = null;
let onPeerError = null;
let onPeerDisconnected = null;
let onDataReceived = null;
let onPeerJoined = null;
let onPeerLeft = null;

function PeerInit(options) {
  options = options || {};
  onPeerOpen = options.onOpen;
  onPeerError = options.onError;
  onPeerDisconnected = options.onDisconnected;
  onDataReceived = options.onData;
  onPeerJoined = options.onPeerJoined;
  onPeerLeft = options.onPeerLeft;

  if (peer && !peer.destroyed) {
    console.log('[PEER] Reutilizando peer existente:', myId);
    if (onPeerOpen && myId) onPeerOpen(myId, isHost);
    return;
  }

  console.log('[PEER] Criando novo peer...');
  peer = new Peer({
    config: {
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
        { urls: 'stun:stun2.l.google.com:19302' },
        { urls: 'stun:stun3.l.google.com:19302' }
      ]
    },
    debug: 1
  });

  peer.on('open', (id) => {
    myId = id;
    isHost = true;
    console.log('[PEER] ✅ Meu ID:', id);
    if (onPeerOpen) onPeerOpen(id, true);
  });

  peer.on('connection', (conn) => {
    console.log('[PEER] 📥 Conexão recebida de:', conn.peer);
    setupConnection(conn);
  });

  peer.on('error', (err) => {
    console.error('[PEER] ❌ Erro:', err.type, err.message || err);
    if (err.type === 'server-error' || err.type === 'network') {
      setTimeout(() => { if (peer && !peer.destroyed) { try { peer.reconnect(); } catch(e){} } }, 3000);
    }
    if (onPeerError) onPeerError(err);
  });

  peer.on('disconnected', () => {
    console.warn('[PEER] ⚠️ Desconectado do servidor. Reconectando...');
    if (peer && !peer.destroyed) {
      setTimeout(() => { try { peer.reconnect(); } catch(e){} }, 1000);
    }
    if (onPeerDisconnected) onPeerDisconnected();
  });
}

function PeerConnect(host) {
  if (!peer || peer.destroyed) {
    console.log('[PEER] Criando peer como cliente...');
    peer = new Peer({
      config: {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
          { urls: 'stun:stun2.l.google.com:19302' },
          { urls: 'stun:stun3.l.google.com:19302' }
        ]
      },
      debug: 1
    });
    peer.on('open', (id) => {
      myId = id;
      isHost = false;
      hostId = host;
      console.log('[PEER] ✅ Cliente ID:', id, '→ host:', host);
      if (onPeerOpen) onPeerOpen(id, false);
      _openConn(host);
    });
    peer.on('connection', (conn) => { setupConnection(conn); });
    peer.on('error', (err) => {
      console.error('[PEER] ❌ Erro cliente:', err.type, err.message || err);
      if (err.type === 'peer-unavailable') {
        if (onPeerError) onPeerError(err);
      } else if (err.type === 'server-error' || err.type === 'network') {
        setTimeout(() => { if (peer && !peer.destroyed) { try { peer.reconnect(); } catch(e){} } }, 3000);
      }
      if (onPeerError) onPeerError(err);
    });
    peer.on('disconnected', () => {
      if (peer && !peer.destroyed) {
        setTimeout(() => { try { peer.reconnect(); } catch(e){} }, 1000);
      }
    });
  } else {
    hostId = host;
    isHost = false;
    console.log('[PEER] Conectando ao host:', host);
    _openConn(host);
  }
}

function _openConn(host) {
  const conn = peer.connect(host, { reliable: true });
  setupConnection(conn);
}

function setupConnection(conn) {
  conn.on('open', () => {
    connections.push(conn);
    console.log('[PEER] ✅ Conectado a:', conn.peer);
    if (onPeerJoined) onPeerJoined(conn.peer);
    // Avisa que sou um novo peer
    conn.send({ type: 'join', id: myId, name: (window.Save ? window.Save.getPlayerName() : 'Jogador') });
  });
  conn.on('data', (data) => {
    if (onDataReceived) onDataReceived(data, conn.peer);
  });
  conn.on('close', () => {
    const idx = connections.indexOf(conn);
    if (idx !== -1) connections.splice(idx, 1);
    console.log('[PEER] ❌ Desconectado de:', conn.peer);
    if (onPeerLeft) onPeerLeft(conn.peer);
  });
  conn.on('error', (err) => {
    console.error('[PEER] Erro conn:', err.type || err);
    // Tenta reconectar se for erro recuperável
    if (err.type === 'network' || err.type === 'server-error') {
      setTimeout(() => {
        if (peer && !peer.destroyed && hostId) {
          console.log('[PEER] Tentando reconectar...');
          _openConn(hostId);
        }
      }, 2000);
    }
  });
}

function Broadcast(data) {
  for (const c of connections) {
    if (c && c.open) {
      try { c.send(data); } catch(e) { console.warn('[PEER] Falha:', e); }
    }
  }
}

function SendTo(peerId, data) {
  for (const c of connections) {
    if (c && c.open && c.peer === peerId) {
      try { c.send(data); } catch(e) { console.warn('[PEER] SendTo:', e); }
      return;
    }
  }
}

function PeerDisconnect() {
  for (const c of connections) { try { c.close(); } catch(e){} }
  connections = [];
  if (peer) { try { peer.destroy(); } catch(e){} peer = null; }
  myId = null; hostId = null; isHost = false;
}

window.PeerAPI = {
  init: PeerInit,
  connect: PeerConnect,
  disconnect: PeerDisconnect,
  broadcast: Broadcast,
  sendTo: SendTo,
  getMyId: () => myId,
  isHost: () => isHost,
  getHostId: () => hostId,
  getConnections: () => connections,
  getConnectedPeerIds: () => connections.filter(c => c.open).map(c => c.peer)
};
})();
