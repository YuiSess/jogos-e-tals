// ============================================================
// audio.js — Estrutura Web Audio API (sem placeholders)
// ============================================================
(function() {
'use strict';

let audioCtx = null;
let masterGain = null;
let sounds = {};
let enabled = false;
let volume = 0.7;

function AudioInit() {
  try {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    masterGain = audioCtx.createGain();
    masterGain.gain.value = window.Save ? window.Save.getSettings().volume : 0.7;
    masterGain.connect(audioCtx.destination);
    enabled = true;
  } catch (e) {
    console.warn('[AUDIO] Indisponível:', e);
    enabled = false;
  }
}

function loadSound(name, url) {
  if (!enabled) return Promise.resolve();
  return fetch(url)
    .then(r => r.arrayBuffer())
    .then(buf => audioCtx.decodeAudioData(buf))
    .then(decoded => { sounds[name] = decoded; })
    .catch(err => console.warn('[AUDIO] Falha', name, err));
}

function playSound(name, options) {
  options = options || {};
  if (!enabled || !sounds[name]) return;
  const src = audioCtx.createBufferSource();
  src.buffer = sounds[name];
  const gain = audioCtx.createGain();
  gain.gain.value = (options.volume || 1) * volume;
  if (options.fade) {
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + options.fade);
  }
  src.connect(gain);
  gain.connect(masterGain);
  if (options.loop) src.loop = true;
  if (options.pitch) src.playbackRate.value = options.pitch;
  src.start();
  return src;
}

function playShot(weaponId) { return playSound('shot_' + (weaponId || 'pistol'), { volume: 0.6 }); }
function playReload(weaponId) { return playSound('reload_' + (weaponId || 'pistol'), { volume: 0.5 }); }
function playHit() { return playSound('hit', { volume: 0.7 }); }
function playExplosion() { return playSound('explosion', { volume: 1.0 }); }
function playFootstep() { return playSound('footstep', { volume: 0.2, pitch: 0.9 + Math.random() * 0.2 }); }
function playEmote(emote) { return playSound('emote_' + emote, { volume: 0.5 }); }

function setVolume(v) { volume = v; if (masterGain) masterGain.gain.value = v; }
function resume() { if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume(); }

window.Audio = {
  init: AudioInit, loadSound, playSound,
  playShot, playReload, playHit, playExplosion, playFootstep, playEmote,
  setVolume, resume
};
})();
