// ============================================================
// loader.js — Mapas com SHADERS: água animada, grama, neblina volumétrica
// ============================================================
(function() {
'use strict';

const MAPS = {
  lobby:    { name: 'Lobby',         groundColor: 0x3a5f7d, groundSize: 60,  waterLevel: null },
  city:     { name: 'Cidade',        groundColor: 0x4a4a4a, groundSize: 200, waterLevel: null },
  park:     { name: 'Parque',        groundColor: 0x4a8c3a, groundSize: 120, waterLevel: null },
  sandbox:  { name: 'Sandbox',       groundColor: 0xc4a86a, groundSize: 200, waterLevel: null },
  range:    { name: 'Campo de Tiro', groundColor: 0x6b5a3a, groundSize: 150, waterLevel: null },
  pvp:      { name: 'Mapa PvP',      groundColor: 0x5a3a3a, groundSize: 100, waterLevel: null },
  arena:    { name: 'Arena',         groundColor: 0x3a3a4a, groundSize: 80,  waterLevel: null },
  house:    { name: 'Casa',          groundColor: 0x8a6a4a, groundSize: 40,  waterLevel: null },
  apartment:{ name: 'Apartamento',   groundColor: 0x6a6a7a, groundSize: 30,  waterLevel: null },
  forest:   { name: 'Floresta',      groundColor: 0x2a5a2a, groundSize: 200, waterLevel: null },
  beach:    { name: 'Praia',         groundColor: 0xe8d090, groundSize: 150, waterLevel: 1.5 },
  island:   { name: 'Ilha',          groundColor: 0xe8d090, groundSize: 100, waterLevel: 0.8 },
  queimada: { name: 'Quadra de Queimada', groundColor: 0x9a6b3a, groundSize: 50, waterLevel: null, mode: 'queimada' },
  futebol:  { name: 'Campo de Futebol',  groundColor: 0x2a7a2a, groundSize: 100, waterLevel: null, mode: 'futebol' },
  ctf:      { name: 'Capture the Flag',  groundColor: 0x4a4a5a, groundSize: 80,  waterLevel: null, mode: 'ctf' }
};

let currentMapMeshes = [];
let waterMesh = null;
let waterUniforms = null;
let grassMeshes = [];
let ambientParticles = null;
let rainParticles = null;
let weatherType = 'clear';   // 'clear' | 'rain' | 'snow' | 'leaves' | 'fog'
let timeOfDay = 0.5;          // 0 = meia-noite, 0.5 = meio-dia
let dayNightSpeed = 0.005;    // velocidade do ciclo (por frame)
let sunMesh = null;
let moonMesh = null;
let dayNightLights = null;
let fogEnabled = false;

// ===== Shader de água animada =====
function createWater(size, level) {
  const geo = new THREE.PlaneGeometry(size, size, 64, 64);
  waterUniforms = {
    time: { value: 0 },
    waterColor: { value: new THREE.Color(0x1166aa) },
    deepColor: { value: new THREE.Color(0x062a4a) },
    opacity: { value: 0.85 }
  };
  const mat = new THREE.ShaderMaterial({
    uniforms: waterUniforms,
    transparent: true,
    side: THREE.DoubleSide,
    vertexShader: `
      uniform float time;
      varying vec3 vPos;
      varying float vWave;
      void main() {
        vec3 p = position;
        float w1 = sin(p.x * 0.3 + time * 1.5) * 0.2;
        float w2 = cos(p.y * 0.3 + time * 1.2) * 0.2;
        float w3 = sin((p.x + p.y) * 0.15 + time * 0.8) * 0.15;
        p.z += w1 + w2 + w3;
        vWave = w1 + w2 + w3;
        vPos = p;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 waterColor;
      uniform vec3 deepColor;
      uniform float opacity;
      uniform float time;
      varying vec3 vPos;
      varying float vWave;
      void main() {
        // Mistura cor profunda / rasa baseado na altura da onda
        float t = (vWave + 0.5) * 0.5;
        vec3 col = mix(deepColor, waterColor, t);
        // Brilho especular fake
        float spec = pow(max(0.0, sin(vPos.x * 0.5 + time * 2.0)), 16.0);
        col += vec3(spec * 0.6);
        // Linhas de espuma
        float foam = smoothstep(0.25, 0.35, vWave);
        col = mix(col, vec3(1.0), foam * 0.4);
        gl_FragColor = vec4(col, opacity);
      }
    `
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = level;
  mesh.name = 'water';
  return mesh;
}

// ===== Shader de céu dinâmico (atmosphere scattering simplificado) =====
function createSky() {
  const skyGeo = new THREE.SphereGeometry(400, 32, 16);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    uniforms: {
      topColor:    { value: new THREE.Color(0x0077ff) },
      midColor:    { value: new THREE.Color(0x88ccff) },
      bottomColor: { value: new THREE.Color(0xffe0b3) },
      sunDir:      { value: new THREE.Vector3(0.5, 0.7, 0.3).normalize() },
      time:        { value: 0 }
    },
    vertexShader: `
      varying vec3 vWorldPosition;
      void main() {
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPosition.xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 topColor;
      uniform vec3 midColor;
      uniform vec3 bottomColor;
      uniform vec3 sunDir;
      uniform float time;
      varying vec3 vWorldPosition;
      void main() {
        vec3 dir = normalize(vWorldPosition);
        float h = dir.y;
        vec3 col;
        if (h > 0.0) {
          col = mix(midColor, topColor, pow(h, 0.6));
        } else {
          col = mix(midColor, bottomColor, pow(-h, 0.4));
        }
        // Halo do sol
        float sunDot = max(0.0, dot(dir, sunDir));
        col += vec3(1.0, 0.9, 0.6) * pow(sunDot, 32.0) * 0.6;
        col += vec3(1.0, 0.7, 0.4) * pow(sunDot, 4.0) * 0.15;
        gl_FragColor = vec4(col, 1.0);
      }
    `
  });
  const mesh = new THREE.Mesh(skyGeo, skyMat);
  mesh.name = 'sky';
  return mesh;
}

// ===== Grama animada (instanced) =====
function createGrassField(count, area, color) {
  const geo = new THREE.PlaneGeometry(0.1, 0.6);
  geo.translate(0, 0.3, 0);
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      time: { value: 0 },
      color: { value: new THREE.Color(color || 0x2a8a2a) },
      windStrength: { value: 0.15 }
    },
    side: THREE.DoubleSide,
    vertexShader: `
      uniform float time;
      uniform float windStrength;
      void main() {
        vec3 p = position;
        // Apenas o topo da grama se move
        float bendFactor = pow(p.y / 0.6, 2.0);
        p.x += sin(time * 2.0 + instanceMatrix[3].x * 0.5 + instanceMatrix[3].z * 0.3) * windStrength * bendFactor;
        p.z += cos(time * 1.5 + instanceMatrix[3].z * 0.4) * windStrength * bendFactor * 0.5;
        gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4(p, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 color;
      void main() { gl_FragColor = vec4(color, 1.0); }
    `
  });
  const mesh = new THREE.InstancedMesh(geo, mat, count);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < count; i++) {
    dummy.position.set(
      (Math.random() - 0.5) * area,
      0,
      (Math.random() - 0.5) * area
    );
    dummy.rotation.y = Math.random() * Math.PI;
    dummy.scale.setScalar(0.5 + Math.random() * 0.8);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
  }
  mesh.instanceMatrix.needsUpdate = true;
  mesh.name = 'grass';
  return mesh;
}

function LoadMap(scene, mapId) {
  ClearMap(scene);
  const cfg = MAPS[mapId] || MAPS.lobby;
  const group = new THREE.Group();
  group.name = 'map_' + mapId;

  // Chão principal
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(cfg.groundSize, cfg.groundSize, 32, 32),
    new THREE.MeshLambertMaterial({ color: cfg.groundColor })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  group.add(ground);
  window.Physics.addStaticPlane(0);

  switch (mapId) {
    case 'lobby': buildLobby(group); break;
    case 'city': buildCity(group); break;
    case 'park': buildPark(group); break;
    case 'sandbox': buildSandbox(group); break;
    case 'range': buildRange(group); break;
    case 'pvp': buildPvP(group); break;
    case 'arena': buildArena(group); break;
    case 'house': buildHouse(group); break;
    case 'apartment': buildApartment(group); break;
    case 'forest': buildForest(group); break;
    case 'beach': buildBeach(group); break;
    case 'island': buildIsland(group); break;
    case 'queimada': buildQueimada(group); break;
    case 'futebol': buildFutebol(group); break;
    case 'ctf': buildCTF(group); break;
  }

  // Água com shader
  if (cfg.waterLevel !== null) {
    waterMesh = createWater(cfg.groundSize * 1.5, cfg.waterLevel);
    group.add(waterMesh);
    if (window.Player) window.Player.setWaterLevel(cfg.waterLevel + 0.3);
  } else {
    if (window.Player) window.Player.setWaterLevel(-1000);
  }

  // Grama animada em mapas verdes
  if (mapId === 'park' || mapId === 'forest' || mapId === 'island' || mapId === 'sandbox') {
    const grass = createGrassField(800, cfg.groundSize * 0.9, mapId === 'forest' ? 0x1a5a1a : 0x3a8a3a);
    grassMeshes.push(grass);
    group.add(grass);
  }

  // === Paredes invisíveis ao redor do mapa (anti-void) ===
  // Impede o jogador de cair fora
  buildInvisibleWalls(cfg.groundSize, mapId);

  // Partículas ambientais (poeira flutuante)
  if (window.Effects) {
    ambientParticles = window.Effects.createAmbientParticles(200, 'dust');
    if (ambientParticles) group.add(ambientParticles);
  }

  scene.add(group);
  currentMapMeshes.push(group);
  return group;
}

// ===== Paredes invisíveis anti-void =====
function buildInvisibleWalls(size, mapId) {
  const halfSize = size / 2;
  const wallHeight = 8;
  const wallThickness = 1;
  // Tamanho específico por mapa
  let bound = halfSize - 1;
  if (mapId === 'queimada') {
    bound = 23;  // quadra 44x24 → paredes em ±23 e ±12
  } else if (mapId === 'futebol') {
    bound = 41;
  } else if (mapId === 'lobby') {
    bound = 25;
  } else if (mapId === 'house' || mapId === 'apartment') {
    return;  // mapas internos, paredes próprias
  }

  const wallsConfig = mapId === 'queimada' ? [
    // 4 paredes ao redor da quadra
    { pos: [0, wallHeight/2, 11.5], half: [bound, wallHeight, wallThickness] },   // sul
    { pos: [0, wallHeight/2, -11.5], half: [bound, wallHeight, wallThickness] }, // norte
    { pos: [22, wallHeight/2, 0], half: [wallThickness, wallHeight, 12] },        // leste
    { pos: [-22, wallHeight/2, 0], half: [wallThickness, wallHeight, 12] }        // oeste
  ] : [
    // Paredes dos 4 lados
    { pos: [0, wallHeight/2, bound], half: [bound, wallHeight, wallThickness] },
    { pos: [0, wallHeight/2, -bound], half: [bound, wallHeight, wallThickness] },
    { pos: [bound, wallHeight/2, 0], half: [wallThickness, wallHeight, bound] },
    { pos: [-bound, wallHeight/2, 0], half: [wallThickness, wallHeight, bound] }
  ];

  for (const w of wallsConfig) {
    window.Physics.addStaticBox(w.pos, w.half);
  }
}

function buildLobby(group) {
  // === Plataforma central elevada ===
  addBox(group, 0, 0.1, 0, 8, 0.2, 8, 0x4488cc);
  // Detalhe dourado no centro
  const centerRing = new THREE.Mesh(
    new THREE.TorusGeometry(2, 0.05, 8, 32),
    new THREE.MeshBasicMaterial({ color: 0xffd700, blending: THREE.AdditiveBlending })
  );
  centerRing.position.set(0, 0.22, 0);
  centerRing.rotation.x = Math.PI / 2;
  group.add(centerRing);

  // === Pilares com luzes ===
  for (let i = 0; i < 4; i++) {
    const ang = (i / 4) * Math.PI * 2;
    const x = Math.cos(ang) * 6, z = Math.sin(ang) * 6;
    addCylinder(group, x, 3, z, 0.3, 6, 0x888888);
    const light = new THREE.PointLight(0xffaa66, 1.5, 15);
    light.position.set(x, 6, z);
    group.add(light);
    // Topo decorativo
    addSphere(group, x, 6.2, z, 0.4, 0xffaa66);
  }

  // === Banner superior ===
  const bannerCanvas = document.createElement('canvas');
  bannerCanvas.width = 1024; bannerCanvas.height = 128;
  const bctx = bannerCanvas.getContext('2d');
  bctx.fillStyle = '#1a1a2e';
  bctx.fillRect(0, 0, 1024, 128);
  bctx.font = 'bold 80px sans-serif';
  bctx.textAlign = 'center';
  bctx.textBaseline = 'middle';
  bctx.fillStyle = '#58a6ff';
  bctx.fillText('🎮 LOBBY 🎮', 512, 64);
  const bannerTex = new THREE.CanvasTexture(bannerCanvas);
  const banner = new THREE.Mesh(
    new THREE.PlaneGeometry(8, 1),
    new THREE.MeshBasicMaterial({ map: bannerTex, transparent: true })
  );
  banner.position.set(0, 5, -8);
  group.add(banner);

  // === Portais coloridos para minigames ===
  const portals = [
    { x: -15, z: 0, color: 0x3b82f6, label: 'Cidade' },
    { x: 15, z: 0, color: 0x10b981, label: 'Parque' },
    { x: 0, z: -15, color: 0xfbbf24, label: 'Arena' },
    { x: 0, z: 15, color: 0xef4444, label: 'PvP' }
  ];
  for (const p of portals) {
    // Arco do portal
    addBox(group, p.x, 1.5, p.z, 2, 3, 0.5, p.color);
    // Brilho
    const glow = new THREE.Mesh(
      new THREE.PlaneGeometry(2.2, 3.2),
      new THREE.MeshBasicMaterial({ color: p.color, transparent: true, opacity: 0.3, blending: THREE.AdditiveBlending, side: THREE.DoubleSide })
    );
    glow.position.set(p.x, 1.5, p.z);
    glow.lookAt(0, 1.5, 0);
    group.add(glow);
    // Label
    const labelCanvas = document.createElement('canvas');
    labelCanvas.width = 256; labelCanvas.height = 64;
    const lctx = labelCanvas.getContext('2d');
    lctx.fillStyle = '#' + p.color.toString(16).padStart(6, '0');
    lctx.fillRect(0, 0, 256, 64);
    lctx.font = 'bold 36px sans-serif';
    lctx.fillStyle = '#ffffff';
    lctx.textAlign = 'center';
    lctx.textBaseline = 'middle';
    lctx.fillText(p.label, 128, 32);
    const labelTex = new THREE.CanvasTexture(labelCanvas);
    const labelSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: labelTex, depthTest: false }));
    labelSprite.position.set(p.x, 3.5, p.z);
    labelSprite.scale.set(2, 0.5, 1);
    group.add(labelSprite);
  }

  // === NPC: Receptionist (no centro) ===
  const npcGroup = new THREE.Group();
  // Corpo
  const npcBody = new THREE.Mesh(
    new THREE.CapsuleGeometry(0.3, 0.8, 8, 12),
    new THREE.MeshStandardMaterial({ color: 0xff6b35, roughness: 0.7 })
  );
  npcBody.position.y = 1;
  npcBody.castShadow = true;
  npcGroup.add(npcBody);
  // Cabeça
  const npcHead = new THREE.Mesh(
    new THREE.SphereGeometry(0.28, 16, 12),
    new THREE.MeshStandardMaterial({ color: 0xffcc99, roughness: 0.7 })
  );
  npcHead.position.y = 1.7;
  npcGroup.add(npcHead);
  // Chapéu de recepção
  const npcHat = new THREE.Mesh(
    new THREE.CylinderGeometry(0.25, 0.3, 0.1, 12),
    new THREE.MeshStandardMaterial({ color: 0xaa0000 })
  );
  npcHat.position.y = 1.95;
  npcGroup.add(npcHat);
  // Nome flutuante
  const npcName = document.createElement('canvas');
  npcName.width = 256; npcName.height = 64;
  const nctx = npcName.getContext('2d');
  nctx.fillStyle = 'rgba(0,0,0,0.7)';
  nctx.fillRect(0, 0, 256, 64);
  nctx.font = 'bold 28px sans-serif';
  nctx.fillStyle = '#fbbf24';
  nctx.textAlign = 'center';
  nctx.textBaseline = 'middle';
  nctx.fillText('Recepcionista', 128, 32);
  const npcNameTex = new THREE.CanvasTexture(npcName);
  const npcNameSprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: npcNameTex, depthTest: false }));
  npcNameSprite.position.set(0, 2.4, 0);
  npcNameSprite.scale.set(1.5, 0.4, 1);
  npcGroup.add(npcNameSprite);
  npcGroup.position.set(0, 0.2, 4);
  npcGroup.rotation.y = Math.PI;
  group.add(npcGroup);

  // === Bancos de descanso ===
  for (const x of [-5, 5]) {
    for (const z of [-5, 5]) {
      addBox(group, x, 0.25, z, 1.5, 0.1, 0.5, 0x8a6a4a);
      addBox(group, x - 0.6, 0.5, z, 0.1, 0.5, 0.5, 0x8a6a4a);
      addBox(group, x + 0.6, 0.5, z, 0.1, 0.5, 0.5, 0x8a6a4a);
    }
  }

  // === Plantas decorativas ===
  for (const pos of [[-3, -3], [3, -3], [-3, 3], [3, 3]]) {
    const pot = new THREE.Mesh(
      new THREE.CylinderGeometry(0.3, 0.25, 0.4, 8),
      new THREE.MeshStandardMaterial({ color: 0x8a6a4a })
    );
    pot.position.set(pos[0], 0.2, pos[1]);
    group.add(pot);
    const plant = new THREE.Mesh(
      new THREE.SphereGeometry(0.4, 8, 8),
      new THREE.MeshStandardMaterial({ color: 0x2a8a2a, roughness: 0.8 })
    );
    plant.position.set(pos[0], 0.7, pos[1]);
    group.add(plant);
  }

  // === Fonte de água decorativa (atrás do banner) ===
  const fountainBase = new THREE.Mesh(
    new THREE.CylinderGeometry(2, 2.2, 0.4, 24),
    new THREE.MeshStandardMaterial({ color: 0x666677, roughness: 0.7 })
  );
  fountainBase.position.set(0, 0.2, -12);
  group.add(fountainBase);
  const fountainWater = new THREE.Mesh(
    new THREE.CylinderGeometry(1.8, 1.8, 0.1, 24),
    new THREE.MeshStandardMaterial({ color: 0x2266aa, transparent: true, opacity: 0.8, metalness: 0.5 })
  );
  fountainWater.position.set(0, 0.4, -12);
  group.add(fountainWater);
  // Jato de água (cilindro)
  const jet = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.3, 2, 8),
    new THREE.MeshBasicMaterial({ color: 0x88ccff, transparent: true, opacity: 0.6 })
  );
  jet.position.set(0, 1.5, -12);
  group.add(jet);

  // === Letras "PLAY" no chão (estrelas decorativas) ===
  for (let i = 0; i < 8; i++) {
    const ang = (i / 8) * Math.PI * 2;
    const r = 12;
    const star = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.3),
      new THREE.MeshBasicMaterial({ color: 0xffd700, blending: THREE.AdditiveBlending })
    );
    star.position.set(Math.cos(ang) * r, 0.5 + Math.sin(i) * 0.3, Math.sin(ang) * r);
    group.add(star);
  }

  // === Luzes penduradas no teto (string lights) ===
  for (let i = 0; i < 10; i++) {
    const x = -15 + i * 3;
    const light = new THREE.PointLight(
      [0xff6b35, 0x3b82f6, 0x10b981, 0xfbbf24][i % 4],
      0.5, 12
    );
    light.position.set(x, 8, 0);
    group.add(light);
    // Bulb
    const bulb = new THREE.Mesh(
      new THREE.SphereGeometry(0.1, 8, 8),
      new THREE.MeshBasicMaterial({ color: [0xff6b35, 0x3b82f6, 0x10b981, 0xfbbf24][i % 4] })
    );
    bulb.position.set(x, 8, 0);
    group.add(bulb);
  }
}

function buildCity(group) {
  for (let i = 0; i < 30; i++) {
    const x = (Math.random() - 0.5) * 180;
    const z = (Math.random() - 0.5) * 180;
    if (Math.abs(x) < 8 && Math.abs(z) < 8) continue;
    const w = 4 + Math.random() * 6;
    const h = 10 + Math.random() * 40;
    const d = 4 + Math.random() * 6;
    addBox(group, x, h/2, z, w, h, d, 0x666666 + Math.floor(Math.random() * 0x222222));
    if (Math.random() > 0.3) addBox(group, x, h/2, z + d/2 + 0.01, w * 0.9, h * 0.9, 0.05, 0xffff99);
  }
  addBox(group, 0, 0.02, 0, 6, 0.01, 200, 0x222222);
  addBox(group, 0, 0.02, 0, 200, 0.01, 6, 0x222222);
}

function buildPark(group) {
  for (let i = 0; i < 50; i++) {
    const x = (Math.random() - 0.5) * 110;
    const z = (Math.random() - 0.5) * 110;
    if (Math.abs(x) < 4 && Math.abs(z) < 4) continue;
    addCylinder(group, x, 1.5, z, 0.3, 3, 0x5a3a1a);
    addSphere(group, x, 4, z, 2, 0x2a6a2a);
  }
  addBox(group, 8, 0.5, 8, 2, 0.1, 0.6, 0x8a6a4a);
  addBox(group, 7.4, 0.8, 8, 0.1, 0.5, 0.6, 0x8a6a4a);
  addBox(group, 8.6, 0.8, 8, 0.1, 0.5, 0.6, 0x8a6a4a);
}

function buildSandbox(group) {
  for (let i = 0; i < 8; i++) {
    const x = (Math.random() - 0.5) * 100;
    const z = (Math.random() - 0.5) * 100;
    const y = 1 + Math.random() * 3;
    addBox(group, x, y, z, 4, 0.5, 4, 0xa86a3a);
  }
  addBox(group, 0, 1, 8, 4, 0.3, 6, 0xc4a86a);
}

function buildRange(group) {
  for (let i = 0; i < 20; i++) {
    const z = -20 - Math.random() * 80;
    const x = (Math.random() - 0.5) * 40;
    addSphere(group, x, 1.5, z, 0.8, 0xff4444);
    addBox(group, x, 0.5, z, 0.1, 1, 0.1, 0x666666);
  }
  addBox(group, 0, 5, -100, 100, 10, 1, 0x888888);
  addBox(group, 0, 0.5, 0, 10, 1, 5, 0x444444);
}

function buildPvP(group) {
  for (let i = 0; i < 30; i++) {
    const x = (Math.random() - 0.5) * 80;
    const z = (Math.random() - 0.5) * 80;
    if (Math.abs(x) < 5 && Math.abs(z) < 5) continue;
    const h = 1 + Math.random() * 3;
    addBox(group, x, h/2, z, 2, h, 2, 0x664444);
  }
  addBox(group, -40, 0.5, 0, 8, 1, 8, 0x4444aa);
  addBox(group, 40, 0.5, 0, 8, 1, 8, 0xaa4444);
}

function buildArena(group) {
  const wall = new THREE.Mesh(
    new THREE.TorusGeometry(35, 1, 8, 64),
    new THREE.MeshLambertMaterial({ color: 0x666666 })
  );
  wall.rotation.x = Math.PI / 2;
  wall.position.y = 4;
  group.add(wall);
  window.Physics.addStaticCylinder([0, 4, 0], 36, 8);
  for (let i = 0; i < 6; i++) {
    const ang = (i / 6) * Math.PI * 2;
    addBox(group, Math.cos(ang) * 15, 2, Math.sin(ang) * 15, 3, 0.4, 3, 0x4a4a5a);
  }
}

function buildHouse(group) {
  addBox(group, 0, 1.5, -8, 16, 3, 0.2, 0x8a6a4a);
  addBox(group, 0, 1.5, 8, 16, 3, 0.2, 0x8a6a4a);
  addBox(group, -8, 1.5, 0, 0.2, 3, 16, 0x8a6a4a);
  addBox(group, 8, 1.5, 0, 0.2, 3, 16, 0x8a6a4a);
  addBox(group, 0, 4, 0, 16, 0.4, 16, 0x5a3a2a);
  addBox(group, 0, 0.7, 0, 2, 0.1, 1.5, 0x6a4a3a);
}

function buildApartment(group) {
  addBox(group, 0, 1.5, -7, 12, 3, 0.2, 0x7a7a8a);
  addBox(group, 0, 1.5, 7, 12, 3, 0.2, 0x7a7a8a);
  addBox(group, -7, 1.5, 0, 0.2, 3, 12, 0x7a7a8a);
  addBox(group, 7, 1.5, 0, 0.2, 3, 12, 0x7a7a8a);
  addBox(group, 0, 4.5, 0, 12, 0.2, 14, 0x666677);
  for (let i = 0; i < 5; i++) {
    addBox(group, -3 + i * 0.5, 0.5 + i * 0.7, 3, 1, 0.1, 1, 0xaaaaaa);
  }
}

function buildForest(group) {
  for (let i = 0; i < 200; i++) {
    const x = (Math.random() - 0.5) * 190;
    const z = (Math.random() - 0.5) * 190;
    if (Math.abs(x) < 4 && Math.abs(z) < 4) continue;
    const h = 5 + Math.random() * 10;
    addCylinder(group, x, h/2, z, 0.4, h, 0x5a3a1a);
    addSphere(group, x, h + 1.5, z, 2 + Math.random() * 1.5, 0x1a4a1a);
  }
  for (let i = 0; i < 30; i++) {
    addSphere(group, (Math.random() - 0.5) * 180, 0.5, (Math.random() - 0.5) * 180, 0.8, 0x777777);
  }
}

function buildBeach(group) {
  const sea = new THREE.Mesh(
    new THREE.PlaneGeometry(300, 300),
    new THREE.MeshLambertMaterial({ color: 0x1199dd, transparent: true, opacity: 0.8 })
  );
  sea.rotation.x = -Math.PI / 2;
  sea.position.y = 1.5;
  group.add(sea);
  for (let i = 0; i < 15; i++) {
    const x = (Math.random() - 0.5) * 100;
    const z = (Math.random() - 0.5) * 100;
    addCylinder(group, x, 3, z, 0.3, 6, 0x8a6a3a);
    addSphere(group, x, 7, z, 2, 0x2a8a2a);
  }
  addCylinder(group, 5, 1.5, 5, 0.1, 3, 0xaaaaaa);
  addSphere(group, 5, 3, 5, 2, 0xff4444);
}

function buildIsland(group) {
  const sand = new THREE.Mesh(
    new THREE.CircleGeometry(30, 32),
    new THREE.MeshLambertMaterial({ color: 0xe8d090 })
  );
  sand.rotation.x = -Math.PI / 2;
  sand.position.y = 0.1;
  group.add(sand);
  const sea = new THREE.Mesh(
    new THREE.PlaneGeometry(200, 200),
    new THREE.MeshLambertMaterial({ color: 0x1199dd, transparent: true, opacity: 0.8 })
  );
  sea.rotation.x = -Math.PI / 2;
  sea.position.y = 0.5;
  group.add(sea);
  for (let i = 0; i < 8; i++) {
    const ang = (i / 8) * Math.PI * 2;
    const r = 15 + Math.random() * 10;
    addCylinder(group, Math.cos(ang) * r, 3, Math.sin(ang) * r, 0.3, 6, 0x8a6a3a);
    addSphere(group, Math.cos(ang) * r, 7, Math.sin(ang) * r, 2, 0x2a8a2a);
  }
}

// ===== QUEIMADA (Dodgeball) — Quadra profissional =====
function buildQueimada(group) {
  // Chão da quadra com cor de madeira/gimnásio
  const courtFloor = new THREE.Mesh(
    new THREE.PlaneGeometry(44, 24),
    new THREE.MeshStandardMaterial({ color: 0xc8893a, roughness: 0.6 })
  );
  courtFloor.rotation.x = -Math.PI / 2;
  courtFloor.position.y = 0.01;
  courtFloor.receiveShadow = true;
  group.add(courtFloor);

  // === Linhas da quadra (brancas) ===
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const lineY = 0.02;

  // Linha central
  const centerLine = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 22), lineMat);
  centerLine.rotation.x = -Math.PI / 2;
  centerLine.position.y = lineY;
  group.add(centerLine);

  // Círculo central
  const centerCircle = new THREE.Mesh(new THREE.RingGeometry(2.9, 3, 32), lineMat);
  centerCircle.rotation.x = -Math.PI / 2;
  centerCircle.position.y = lineY;
  group.add(centerCircle);

  // Linhas laterais (esquerda/direita)
  for (const z of [11, -11]) {
    const line = new THREE.Mesh(new THREE.PlaneGeometry(44, 0.15), lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(0, lineY, z);
    group.add(line);
  }

  // Linhas de fundo
  for (const x of [-22, 22]) {
    const line = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 22), lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(x, lineY, 0);
    group.add(line);
  }

  // Linhas de ataque (a 8m do centro de cada lado)
  for (const x of [-8, 8]) {
    const line = new THREE.Mesh(new THREE.PlaneGeometry(0.1, 22), lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(x, lineY, 0);
    group.add(line);
  }

  // === Zonas dos times (azul e vermelho) ===
  const blueZone = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 22),
    new THREE.MeshBasicMaterial({ color: 0x3b82f6, transparent: true, opacity: 0.15 })
  );
  blueZone.rotation.x = -Math.PI / 2;
  blueZone.position.set(-15, 0.015, 0);
  group.add(blueZone);

  const redZone = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 22),
    new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.15 })
  );
  redZone.rotation.x = -Math.PI / 2;
  redZone.position.set(15, 0.015, 0);
  group.add(redZone);

  // === Paredes de vidro laterais (para bola não sair) ===
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0x88ccff, transparent: true, opacity: 0.2,
    metalness: 0.8, roughness: 0.1, side: THREE.DoubleSide
  });
  for (const z of [11, -11]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(44, 3, 0.1), glassMat);
    wall.position.set(0, 1.5, z);
    group.add(wall);
    // Física da parede
    window.Physics.addStaticBox([0, 1.5, z], [22, 1.5, 0.05]);
  }
  // Paredes de fundo (atrás dos times)
  for (const x of [-22, 22]) {
    const wall = new THREE.Mesh(new THREE.BoxGeometry(0.1, 3, 22), glassMat);
    wall.position.set(x, 1.5, 0);
    group.add(wall);
    window.Physics.addStaticBox([x, 1.5, 0], [0.05, 1.5, 11]);
  }

  // === Cestas de bolas decorativas (cantos) ===
  const ballMat = new THREE.MeshStandardMaterial({ color: 0xff6b35, roughness: 0.5 });
  for (const x of [-20, 20]) {
    for (const z of [-9, 9]) {
      // Cone (cesta)
      const basket = new THREE.Mesh(
        new THREE.CylinderGeometry(0.6, 0.4, 0.8, 12),
        new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.6 })
      );
      basket.position.set(x, 0.4, z);
      group.add(basket);
      // Bolas dentro
      for (let i = 0; i < 3; i++) {
        const ball = new THREE.Mesh(new THREE.SphereGeometry(0.25, 12, 10), ballMat);
        ball.position.set(x + (Math.random() - 0.5) * 0.3, 0.7 + i * 0.2, z + (Math.random() - 0.5) * 0.3);
        group.add(ball);
      }
    }
  }

  // === Plataforma central (onde as bolas spawnam) ===
  const platform = new THREE.Mesh(
    new THREE.CylinderGeometry(2.5, 2.5, 0.3, 24),
    new THREE.MeshStandardMaterial({ color: 0xffaa00, metalness: 0.3, roughness: 0.5, emissive: 0x442200 })
  );
  platform.position.y = 0.15;
  group.add(platform);
  // Anel brilhante ao redor
  const ring = new THREE.Mesh(
    new THREE.TorusGeometry(2.5, 0.08, 8, 32),
    new THREE.MeshBasicMaterial({ color: 0xffdd00, blending: THREE.AdditiveBlending, transparent: true, opacity: 0.8 })
  );
  ring.position.y = 0.35;
  ring.rotation.x = Math.PI / 2;
  group.add(ring);

  // === Postes de luz com luzes pontuais ===
  for (const x of [-18, 18]) {
    for (const z of [-12, 12]) {
      // Poste
      addCylinder(group, x, 6, z, 0.15, 12, 0x333333);
      // Lâmpada
      const lamp = new THREE.Mesh(
        new THREE.SphereGeometry(0.3, 12, 10),
        new THREE.MeshBasicMaterial({ color: 0xffffaa })
      );
      lamp.position.set(x, 12, z);
      group.add(lamp);
      // Luz
      const light = new THREE.PointLight(0xffffcc, 1.2, 35);
      light.position.set(x, 11.5, z);
      group.add(light);
    }
  }

  // === Bancadas (plateia) ===
  const bleacherMat = new THREE.MeshStandardMaterial({ color: 0x555566, roughness: 0.8 });
  for (const z of [-14, 14]) {
    for (let i = 0; i < 4; i++) {
      const seat = new THREE.Mesh(
        new THREE.BoxGeometry(40, 0.4, 1.5),
        bleacherMat
      );
      seat.position.set(0, 0.3 + i * 0.5, z + (z > 0 ? i * 1.2 : -i * 1.2));
      seat.castShadow = true;
      group.add(seat);
    }
  }

  // === Placar eletrônico (caixa preta com display) ===
  const scoreboardBase = new THREE.Mesh(
    new THREE.BoxGeometry(6, 0.3, 0.3),
    new THREE.MeshStandardMaterial({ color: 0x222222 })
  );
  scoreboardBase.position.set(0, 14, -13);
  group.add(scoreboardBase);
  const scoreboard = new THREE.Mesh(
    new THREE.BoxGeometry(5, 2, 0.2),
    new THREE.MeshStandardMaterial({ color: 0x111111, emissive: 0x001100 })
  );
  scoreboard.position.set(0, 15, -13);
  group.add(scoreboard);
  // Display do placar (canvas texture)
  const scoreCanvas = document.createElement('canvas');
  scoreCanvas.width = 512; scoreCanvas.height = 128;
  const scoreCtx = scoreCanvas.getContext('2d');
  scoreCtx.fillStyle = '#000000';
  scoreCtx.fillRect(0, 0, 512, 128);
  scoreCtx.fillStyle = '#ff4444';
  scoreCtx.font = 'bold 80px monospace';
  scoreCtx.textAlign = 'center';
  scoreCtx.fillText('0 : 0', 256, 90);
  const scoreTex = new THREE.CanvasTexture(scoreCanvas);
  const scoreDisplay = new THREE.Mesh(
    new THREE.PlaneGeometry(4.5, 1.5),
    new THREE.MeshBasicMaterial({ map: scoreTex })
  );
  scoreDisplay.position.set(0, 15, -12.85);
  group.add(scoreDisplay);

  // === Banner "QUEIMADA" ===
  const bannerCanvas = document.createElement('canvas');
  bannerCanvas.width = 1024; bannerCanvas.height = 128;
  const bctx = bannerCanvas.getContext('2d');
  bctx.fillStyle = '#1a1a2e';
  bctx.fillRect(0, 0, 1024, 128);
  bctx.font = 'bold 80px sans-serif';
  bctx.textAlign = 'center';
  bctx.textBaseline = 'middle';
  bctx.fillStyle = '#ff6b35';
  bctx.fillText('🏐 QUEIMADA 🏐', 512, 64);
  const bannerTex = new THREE.CanvasTexture(bannerCanvas);
  const banner = new THREE.Mesh(
    new THREE.PlaneGeometry(10, 1.2),
    new THREE.MeshBasicMaterial({ map: bannerTex })
  );
  banner.position.set(0, 8, 13);
  group.add(banner);
}

// ===== FUTEBOL =====
function buildFutebol(group) {
  // Campo 80x50 com marcações
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  // Linhas laterais
  for (const z of [25, -25]) {
    const line = new THREE.Mesh(new THREE.PlaneGeometry(80, 0.2), lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(0, 0.02, z);
    group.add(line);
  }
  // Linhas de fundo
  for (const x of [-40, 40]) {
    const line = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 50), lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(x, 0.02, 0);
    group.add(line);
  }
  // Linha central
  const centerLine = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 50), lineMat);
  centerLine.rotation.x = -Math.PI / 2;
  centerLine.position.set(0, 0.02, 0);
  group.add(centerLine);
  // Círculo central
  const circle = new THREE.Mesh(
    new THREE.RingGeometry(4.8, 5, 32),
    lineMat
  );
  circle.rotation.x = -Math.PI / 2;
  circle.position.y = 0.03;
  group.add(circle);

  // Gols (com rede simulada)
  for (const x of [-40, 40]) {
    buildGoal(group, x, 0);
  }

  // Áreas
  for (const x of [-32, 32]) {
    const area = new THREE.Mesh(
      new THREE.PlaneGeometry(8, 22),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.15 })
    );
    area.rotation.x = -Math.PI / 2;
    area.position.set(x, 0.025, 0);
    group.add(area);
  }

  // Bancadas ao redor
  for (const z of [-30, 30]) {
    for (let i = 0; i < 4; i++) {
      addBox(group, -30 + i * 20, 1 + i * 0.5, z, 12, 0.5, 2, 0x888888);
    }
  }

  // Refletores
  for (const x of [-30, 30]) {
    for (const z of [-30, 30]) {
      const light = new THREE.SpotLight(0xffffff, 2, 100, Math.PI / 4, 0.5);
      light.position.set(x, 25, z);
      light.target.position.set(0, 0, 0);
      group.add(light);
      group.add(light.target);
      addCylinder(group, x, 12, z, 0.3, 25, 0x333333);
    }
  }
}

function buildGoal(group, x, z) {
  // Postes
  addBox(group, x, 1.5, z - 4, 0.2, 3, 0.2, 0xffffff);
  addBox(group, x, 1.5, z + 4, 0.2, 3, 0.2, 0xffffff);
  // Trave superior
  addBox(group, x, 3, z, 0.2, 0.2, 8, 0xffffff);
  // Rede (simulada com plano transparente)
  const net = new THREE.Mesh(
    new THREE.PlaneGeometry(0.5, 8),
    new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.3, wireframe: true })
  );
  net.position.set(x + (x > 0 ? 0.5 : -0.5), 1.5, z);
  net.rotation.y = Math.PI / 2;
  group.add(net);
}

// ===== CAPTURE THE FLAG =====
function buildCTF(group) {
  // Duas bases opostas
  // Base azul
  addBox(group, -35, 0.1, 0, 10, 0.2, 10, 0x3b82f6);
  // Torre azul
  addCylinder(group, -35, 3, 0, 1, 6, 0x4a4a8a);
  addBox(group, -35, 6.5, 0, 2, 1, 2, 0x3b82f6);

  // Base vermelha
  addBox(group, 35, 0.1, 0, 10, 0.2, 10, 0xef4444);
  addCylinder(group, 35, 3, 0, 1, 6, 0x8a4a4a);
  addBox(group, 35, 6.5, 0, 2, 1, 2, 0xef4444);

  // Caminho central com obstáculos
  for (let i = -2; i <= 2; i++) {
    addBox(group, i * 8, 1, 8, 3, 2, 1, 0x666666);
    addBox(group, i * 8, 1, -8, 3, 2, 1, 0x666666);
  }
  // Ponte central
  addBox(group, 0, 0.5, 0, 6, 1, 4, 0x8a6a4a);
  // Água abaixo da ponte
  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(8, 6),
    new THREE.MeshLambertMaterial({ color: 0x1166aa, transparent: true, opacity: 0.7 })
  );
  water.rotation.x = -Math.PI / 2;
  water.position.y = -0.5;
  group.add(water);

  // Muros laterais
  addBox(group, 0, 2, 18, 70, 4, 1, 0x555555);
  addBox(group, 0, 2, -18, 70, 4, 1, 0x555555);
}

function addBox(group, x, y, z, w, h, d, color) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshLambertMaterial({ color })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true; mesh.receiveShadow = true;
  group.add(mesh);
  window.Physics.addStaticBox([x, y, z], [w/2, h/2, d/2]);
}

function addCylinder(group, x, y, z, r, h, color) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(r, r, h, 12),
    new THREE.MeshLambertMaterial({ color })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  group.add(mesh);
  window.Physics.addStaticCylinder([x, y, z], r, h);
}

function addSphere(group, x, y, z, r, color) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(r, 16, 12),
    new THREE.MeshLambertMaterial({ color })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  group.add(mesh);
  window.Physics.addStaticSphere([x, y, z], r);
}

function ClearMap(scene) {
  for (const g of currentMapMeshes) {
    scene.remove(g);
    g.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        if (Array.isArray(o.material)) o.material.forEach(m => m.dispose());
        else o.material.dispose();
      }
    });
  }
  currentMapMeshes = [];
  waterMesh = null;
  waterUniforms = null;
  grassMeshes = [];
  ambientParticles = null;
}

// Atualiza shaders (chamado a cada frame)
function UpdateShaders(delta) {
  const t = performance.now() / 1000;
  if (waterUniforms) waterUniforms.time.value = t;
  for (const g of grassMeshes) {
    if (g.material && g.material.uniforms) g.material.uniforms.time.value = t;
  }
  if (ambientParticles && window.Effects) {
    window.Effects.updateAmbientParticles(ambientParticles, delta);
  }
  if (rainParticles && window.Effects) {
    window.Effects.updateAmbientParticles(rainParticles, delta);
  }
  // Atualiza ciclo dia/noite
  updateDayNight(delta);
}

// ===== Ciclo dia/noite =====
function updateDayNight(delta) {
  timeOfDay += dayNightSpeed * delta * 0.5;
  if (timeOfDay > 1) timeOfDay = 0;
  // Ângulo do sol (0 = nascente, 0.5 = meio-dia, 1 = poente)
  const sunAngle = timeOfDay * Math.PI * 2 - Math.PI / 2;
  const sunY = Math.sin(sunAngle);
  const sunX = Math.cos(sunAngle);

  // Atualiza luz solar
  if (window.GameState && window.GameState.scene) {
    const sunLight = window.GameState.scene.children.find(c => c.type === 'DirectionalLight');
    if (sunLight) {
      sunLight.position.set(sunX * 80, sunY * 80 + 20, 30);
      // Cor do sol varia (laranja no nascer/pôr, branco ao meio-dia, escuro à noite)
      const dayFactor = Math.max(0, sunY);
      const sunsetFactor = Math.max(0, 1 - Math.abs(sunY) * 2);
      const r = 1.0;
      const g = 0.93 - sunsetFactor * 0.3;
      const b = 0.8 - sunsetFactor * 0.5;
      const intensity = 0.3 + dayFactor * 1.0;
      sunLight.color.setRGB(r, g, b);
      sunLight.intensity = intensity;
    }
    // Ambient
    const ambient = window.GameState.scene.children.find(c => c.type === 'AmbientLight');
    if (ambient) {
      const dayFactor = Math.max(0, sunY);
      ambient.intensity = 0.2 + dayFactor * 0.5;
      ambient.color.setRGB(0.6 + dayFactor * 0.4, 0.7 + dayFactor * 0.3, 0.8 + dayFactor * 0.2);
    }
  }

  // Atualiza céu (uniforms)
  const skyMesh = window.GameState && window.GameState.sky;
  if (skyMesh && skyMesh.material && skyMesh.material.uniforms) {
    const dayFactor = Math.max(0, sunY);
    const sunsetFactor2 = Math.max(0, 1 - Math.abs(sunY) * 2);
    skyMesh.material.uniforms.topColor.value.setRGB(
      0.05 + dayFactor * 0.45,
      0.1 + dayFactor * 0.55,
      0.3 + dayFactor * 0.7
    );
    skyMesh.material.uniforms.midColor.value.setRGB(
      0.4 + dayFactor * 0.5,
      0.5 + dayFactor * 0.4,
      0.7 + dayFactor * 0.3
    );
    skyMesh.material.uniforms.bottomColor.value.setRGB(
      0.8 + sunsetFactor2 * 0.2,
      0.5 + sunsetFactor2 * 0.3,
      0.3 + sunsetFactor2 * 0.2
    );
    if (skyMesh.material.uniforms.sunDir) {
      skyMesh.material.uniforms.sunDir.value.set(sunX, sunY, 0.3).normalize();
    }
    if (skyMesh.material.uniforms.time) {
      skyMesh.material.uniforms.time.value = timeOfDay;
    }
  }
}

// ===== Sistema de clima =====
function setWeather(type) {
  weatherType = type;
  if (rainParticles && rainParticles.parent) {
    rainParticles.parent.remove(rainParticles);
    rainParticles = null;
  }
  if (type === 'rain') {
    rainParticles = window.Effects.createAmbientParticles(500, 'rain');
  } else if (type === 'snow') {
    rainParticles = window.Effects.createAmbientParticles(400, 'snow');
  } else if (type === 'leaves') {
    rainParticles = window.Effects.createAmbientParticles(150, 'leaves');
  }
}

function toggleWeather() {
  const types = ['clear', 'rain', 'snow', 'leaves'];
  const idx = types.indexOf(weatherType);
  const next = types[(idx + 1) % types.length];
  setWeather(next);
  return next;
}

function toggleDayNight() {
  // Pula para próximo momento do dia
  if (timeOfDay < 0.25) timeOfDay = 0.25;       // manhã → meio-dia
  else if (timeOfDay < 0.5) timeOfDay = 0.5;     // meio-dia
  else if (timeOfDay < 0.75) timeOfDay = 0.75;   // pôr do sol
  else timeOfDay = 0;                              // noite
  return timeOfDay;
}

function setTimeOfDay(t) {
  timeOfDay = t;
}

window.Loader = {
  loadMap: LoadMap,
  clearMap: ClearMap,
  getMapList: () => Object.keys(MAPS).map(k => ({ id: k, name: MAPS[k].name })),
  createSky,
  UpdateShaders,
  setWeather, toggleWeather, toggleDayNight, setTimeOfDay,
  getTimeOfDay: () => timeOfDay,
  getWeather: () => weatherType,
  MAPS
};
})();
