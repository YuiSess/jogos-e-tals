// ============================================================
// loader.js — Mapas com SHADERS: água animada, grama, neblina volumétrica
// ============================================================
(function() {
'use strict';

const MAPS = {
  lobby:    { name: 'Lobby',         groundColor: 0x3a5f7d, groundSize: 60,  waterLevel: null },
  city:     { name: 'Cidade',        groundColor: 0x4a4a4a, groundSize: 200, waterLevel: null },
  park:     { name: 'Parque',        groundColor: 0x4a8c3a, groundSize: 120, waterLevel: null },
  sandbox:  { name: 'Sandbox',       groundColor: 0xc4a86a, groundSize: 200, waterLevel: null },
  range:    { name: 'Campo de Tiro', groundColor: 0x6b5a3a, groundSize: 150, waterLevel: null },
  pvp:      { name: 'Mapa PvP',      groundColor: 0x5a3a3a, groundSize: 100, waterLevel: null },
  arena:    { name: 'Arena',         groundColor: 0x3a3a4a, groundSize: 80,  waterLevel: null },
  house:    { name: 'Casa',          groundColor: 0x8a6a4a, groundSize: 40,  waterLevel: null },
  apartment:{ name: 'Apartamento',   groundColor: 0x6a6a7a, groundSize: 30,  waterLevel: null },
  forest:   { name: 'Floresta',      groundColor: 0x2a5a2a, groundSize: 200, waterLevel: null },
  beach:    { name: 'Praia',         groundColor: 0xe8d090, groundSize: 150, waterLevel: 1.5 },
  island:   { name: 'Ilha',          groundColor: 0xe8d090, groundSize: 100, waterLevel: 0.8 },
  queimada: { name: 'Quadra de Queimada', groundColor: 0x9a6b3a, groundSize: 50, waterLevel: null, mode: 'queimada' },
  futebol:  { name: 'Campo de Futebol',  groundColor: 0x2a7a2a, groundSize: 100, waterLevel: null, mode: 'futebol' },
  ctf:      { name: 'Capture the Flag',  groundColor: 0x4a4a5a, groundSize: 80,  waterLevel: null, mode: 'ctf' }
};

let currentMapMeshes = [];
let waterMesh = null;
let waterUniforms = null;
let grassMeshes = [];
let ambientParticles = null;

// ===== Shader de água animada =====
function createWater(size, level) {
  const geo = new THREE.PlaneGeometry(size, size, 64, 64);
  waterUniforms = {
    time: { value: 0 },
    waterColor: { value: new THREE.Color(0x1166aa) },
    deepColor: { value: new THREE.Color(0x062a4a) },
    opacity: { value: 0.85 }
  };
  const mat = new THREE.ShaderMaterial({
    uniforms: waterUniforms,
    transparent: true,
    side: THREE.DoubleSide,
    vertexShader: `
      uniform float time;
      varying vec3 vPos;
      varying float vWave;
      void main() {
        vec3 p = position;
        float w1 = sin(p.x * 0.3 + time * 1.5) * 0.2;
        float w2 = cos(p.y * 0.3 + time * 1.2) * 0.2;
        float w3 = sin((p.x + p.y) * 0.15 + time * 0.8) * 0.15;
        p.z += w1 + w2 + w3;
        vWave = w1 + w2 + w3;
        vPos = p;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 waterColor;
      uniform vec3 deepColor;
      uniform float opacity;
      uniform float time;
      varying vec3 vPos;
      varying float vWave;
      void main() {
        // Mistura cor profunda / rasa baseado na altura da onda
        float t = (vWave + 0.5) * 0.5;
        vec3 col = mix(deepColor, waterColor, t);
        // Brilho especular fake
        float spec = pow(max(0.0, sin(vPos.x * 0.5 + time * 2.0)), 16.0);
        col += vec3(spec * 0.6);
        // Linhas de espuma
        float foam = smoothstep(0.25, 0.35, vWave);
        col = mix(col, vec3(1.0), foam * 0.4);
        gl_FragColor = vec4(col, opacity);
      }
    `
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = level;
  mesh.name = 'water';
  return mesh;
}

// ===== Shader de céu dinâmico (atmosphere scattering simplificado) =====
function createSky() {
  const skyGeo = new THREE.SphereGeometry(400, 32, 16);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide,
    uniforms: {
      topColor:    { value: new THREE.Color(0x0077ff) },
      midColor:    { value: new THREE.Color(0x88ccff) },
      bottomColor: { value: new THREE.Color(0xffe0b3) },
      sunDir:      { value: new THREE.Vector3(0.5, 0.7, 0.3).normalize() },
      time:        { value: 0 }
    },
    vertexShader: `
      varying vec3 vWorldPosition;
      void main() {
        vec4 worldPosition = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPosition.xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 topColor;
      uniform vec3 midColor;
      uniform vec3 bottomColor;
      uniform vec3 sunDir;
      uniform float time;
      varying vec3 vWorldPosition;
      void main() {
        vec3 dir = normalize(vWorldPosition);
        float h = dir.y;
        vec3 col;
        if (h > 0.0) {
          col = mix(midColor, topColor, pow(h, 0.6));
        } else {
          col = mix(midColor, bottomColor, pow(-h, 0.4));
        }
        // Halo do sol
        float sunDot = max(0.0, dot(dir, sunDir));
        col += vec3(1.0, 0.9, 0.6) * pow(sunDot, 32.0) * 0.6;
        col += vec3(1.0, 0.7, 0.4) * pow(sunDot, 4.0) * 0.15;
        gl_FragColor = vec4(col, 1.0);
      }
    `
  });
  const mesh = new THREE.Mesh(skyGeo, skyMat);
  mesh.name = 'sky';
  return mesh;
}

// ===== Grama animada (instanced) =====
function createGrassField(count, area, color) {
  const geo = new THREE.PlaneGeometry(0.1, 0.6);
  geo.translate(0, 0.3, 0);
  const mat = new THREE.ShaderMaterial({
    uniforms: {
      time: { value: 0 },
      color: { value: new THREE.Color(color || 0x2a8a2a) },
      windStrength: { value: 0.15 }
    },
    side: THREE.DoubleSide,
    vertexShader: `
      uniform float time;
      uniform float windStrength;
      void main() {
        vec3 p = position;
        // Apenas o topo da grama se move
        float bendFactor = pow(p.y / 0.6, 2.0);
        p.x += sin(time * 2.0 + instanceMatrix[3].x * 0.5 + instanceMatrix[3].z * 0.3) * windStrength * bendFactor;
        p.z += cos(time * 1.5 + instanceMatrix[3].z * 0.4) * windStrength * bendFactor * 0.5;
        gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4(p, 1.0);
      }
    `,
    fragmentShader: `
      uniform vec3 color;
      void main() { gl_FragColor = vec4(color, 1.0); }
    `
  });
  const mesh = new THREE.InstancedMesh(geo, mat, count);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < count; i++) {
    dummy.position.set(
      (Math.random() - 0.5) * area,
      0,
      (Math.random() - 0.5) * area
    );
    dummy.rotation.y = Math.random() * Math.PI;
    dummy.scale.setScalar(0.5 + Math.random() * 0.8);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
  }
  mesh.instanceMatrix.needsUpdate = true;
  mesh.name = 'grass';
  return mesh;
}

function LoadMap(scene, mapId) {
  ClearMap(scene);
  const cfg = MAPS[mapId] || MAPS.lobby;
  const group = new THREE.Group();
  group.name = 'map_' + mapId;

  // Chão principal
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(cfg.groundSize, cfg.groundSize, 32, 32),
    new THREE.MeshLambertMaterial({ color: cfg.groundColor })
  );
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  group.add(ground);
  window.Physics.addStaticPlane(0);

  switch (mapId) {
    case 'lobby': buildLobby(group); break;
    case 'city': buildCity(group); break;
    case 'park': buildPark(group); break;
    case 'sandbox': buildSandbox(group); break;
    case 'range': buildRange(group); break;
    case 'pvp': buildPvP(group); break;
    case 'arena': buildArena(group); break;
    case 'house': buildHouse(group); break;
    case 'apartment': buildApartment(group); break;
    case 'forest': buildForest(group); break;
    case 'beach': buildBeach(group); break;
    case 'island': buildIsland(group); break;
    case 'queimada': buildQueimada(group); break;
    case 'futebol': buildFutebol(group); break;
    case 'ctf': buildCTF(group); break;
  }

  // Água com shader
  if (cfg.waterLevel !== null) {
    waterMesh = createWater(cfg.groundSize * 1.5, cfg.waterLevel);
    group.add(waterMesh);
    if (window.Player) window.Player.setWaterLevel(cfg.waterLevel + 0.3);
  } else {
    if (window.Player) window.Player.setWaterLevel(-1000);
  }

  // Grama animada em mapas verdes
  if (mapId === 'park' || mapId === 'forest' || mapId === 'island' || mapId === 'sandbox') {
    const grass = createGrassField(800, cfg.groundSize * 0.9, mapId === 'forest' ? 0x1a5a1a : 0x3a8a3a);
    grassMeshes.push(grass);
    group.add(grass);
  }

  // Partículas ambientais (poeira flutuante)
  if (window.Effects) {
    ambientParticles = window.Effects.createAmbientParticles(200, 'dust');
    if (ambientParticles) group.add(ambientParticles);
  }

  scene.add(group);
  currentMapMeshes.push(group);
  return group;
}

function buildLobby(group) {
  addBox(group, 0, 0.1, 0, 8, 0.2, 8, 0x4488cc);
  for (let i = 0; i < 4; i++) {
    const ang = (i / 4) * Math.PI * 2;
    const x = Math.cos(ang) * 6, z = Math.sin(ang) * 6;
    addCylinder(group, x, 3, z, 0.3, 6, 0x888888);
    const light = new THREE.PointLight(0xffaa66, 1.5, 15);
    light.position.set(x, 6, z);
    group.add(light);
  }
  addBox(group, 0, 5, -8, 8, 1.5, 0.3, 0x222222);
  const portals = [
    { x: -15, z: 0, color: 0x3b82f6 },
    { x: 15, z: 0, color: 0x10b981 },
    { x: 0, z: -15, color: 0xfbbf24 },
    { x: 0, z: 15, color: 0xef4444 }
  ];
  for (const p of portals) addBox(group, p.x, 1.5, p.z, 2, 3, 0.5, p.color);
}

function buildCity(group) {
  for (let i = 0; i < 30; i++) {
    const x = (Math.random() - 0.5) * 180;
    const z = (Math.random() - 0.5) * 180;
    if (Math.abs(x) < 8 && Math.abs(z) < 8) continue;
    const w = 4 + Math.random() * 6;
    const h = 10 + Math.random() * 40;
    const d = 4 + Math.random() * 6;
    addBox(group, x, h/2, z, w, h, d, 0x666666 + Math.floor(Math.random() * 0x222222));
    if (Math.random() > 0.3) addBox(group, x, h/2, z + d/2 + 0.01, w * 0.9, h * 0.9, 0.05, 0xffff99);
  }
  addBox(group, 0, 0.02, 0, 6, 0.01, 200, 0x222222);
  addBox(group, 0, 0.02, 0, 200, 0.01, 6, 0x222222);
}

function buildPark(group) {
  for (let i = 0; i < 50; i++) {
    const x = (Math.random() - 0.5) * 110;
    const z = (Math.random() - 0.5) * 110;
    if (Math.abs(x) < 4 && Math.abs(z) < 4) continue;
    addCylinder(group, x, 1.5, z, 0.3, 3, 0x5a3a1a);
    addSphere(group, x, 4, z, 2, 0x2a6a2a);
  }
  addBox(group, 8, 0.5, 8, 2, 0.1, 0.6, 0x8a6a4a);
  addBox(group, 7.4, 0.8, 8, 0.1, 0.5, 0.6, 0x8a6a4a);
  addBox(group, 8.6, 0.8, 8, 0.1, 0.5, 0.6, 0x8a6a4a);
}

function buildSandbox(group) {
  for (let i = 0; i < 8; i++) {
    const x = (Math.random() - 0.5) * 100;
    const z = (Math.random() - 0.5) * 100;
    const y = 1 + Math.random() * 3;
    addBox(group, x, y, z, 4, 0.5, 4, 0xa86a3a);
  }
  addBox(group, 0, 1, 8, 4, 0.3, 6, 0xc4a86a);
}

function buildRange(group) {
  for (let i = 0; i < 20; i++) {
    const z = -20 - Math.random() * 80;
    const x = (Math.random() - 0.5) * 40;
    addSphere(group, x, 1.5, z, 0.8, 0xff4444);
    addBox(group, x, 0.5, z, 0.1, 1, 0.1, 0x666666);
  }
  addBox(group, 0, 5, -100, 100, 10, 1, 0x888888);
  addBox(group, 0, 0.5, 0, 10, 1, 5, 0x444444);
}

function buildPvP(group) {
  for (let i = 0; i < 30; i++) {
    const x = (Math.random() - 0.5) * 80;
    const z = (Math.random() - 0.5) * 80;
    if (Math.abs(x) < 5 && Math.abs(z) < 5) continue;
    const h = 1 + Math.random() * 3;
    addBox(group, x, h/2, z, 2, h, 2, 0x664444);
  }
  addBox(group, -40, 0.5, 0, 8, 1, 8, 0x4444aa);
  addBox(group, 40, 0.5, 0, 8, 1, 8, 0xaa4444);
}

function buildArena(group) {
  const wall = new THREE.Mesh(
    new THREE.TorusGeometry(35, 1, 8, 64),
    new THREE.MeshLambertMaterial({ color: 0x666666 })
  );
  wall.rotation.x = Math.PI / 2;
  wall.position.y = 4;
  group.add(wall);
  window.Physics.addStaticCylinder([0, 4, 0], 36, 8);
  for (let i = 0; i < 6; i++) {
    const ang = (i / 6) * Math.PI * 2;
    addBox(group, Math.cos(ang) * 15, 2, Math.sin(ang) * 15, 3, 0.4, 3, 0x4a4a5a);
  }
}

function buildHouse(group) {
  addBox(group, 0, 1.5, -8, 16, 3, 0.2, 0x8a6a4a);
  addBox(group, 0, 1.5, 8, 16, 3, 0.2, 0x8a6a4a);
  addBox(group, -8, 1.5, 0, 0.2, 3, 16, 0x8a6a4a);
  addBox(group, 8, 1.5, 0, 0.2, 3, 16, 0x8a6a4a);
  addBox(group, 0, 4, 0, 16, 0.4, 16, 0x5a3a2a);
  addBox(group, 0, 0.7, 0, 2, 0.1, 1.5, 0x6a4a3a);
}

function buildApartment(group) {
  addBox(group, 0, 1.5, -7, 12, 3, 0.2, 0x7a7a8a);
  addBox(group, 0, 1.5, 7, 12, 3, 0.2, 0x7a7a8a);
  addBox(group, -7, 1.5, 0, 0.2, 3, 12, 0x7a7a8a);
  addBox(group, 7, 1.5, 0, 0.2, 3, 12, 0x7a7a8a);
  addBox(group, 0, 4.5, 0, 12, 0.2, 14, 0x666677);
  for (let i = 0; i < 5; i++) {
    addBox(group, -3 + i * 0.5, 0.5 + i * 0.7, 3, 1, 0.1, 1, 0xaaaaaa);
  }
}

function buildForest(group) {
  for (let i = 0; i < 200; i++) {
    const x = (Math.random() - 0.5) * 190;
    const z = (Math.random() - 0.5) * 190;
    if (Math.abs(x) < 4 && Math.abs(z) < 4) continue;
    const h = 5 + Math.random() * 10;
    addCylinder(group, x, h/2, z, 0.4, h, 0x5a3a1a);
    addSphere(group, x, h + 1.5, z, 2 + Math.random() * 1.5, 0x1a4a1a);
  }
  for (let i = 0; i < 30; i++) {
    addSphere(group, (Math.random() - 0.5) * 180, 0.5, (Math.random() - 0.5) * 180, 0.8, 0x777777);
  }
}

function buildBeach(group) {
  const sea = new THREE.Mesh(
    new THREE.PlaneGeometry(300, 300),
    new THREE.MeshLambertMaterial({ color: 0x1199dd, transparent: true, opacity: 0.8 })
  );
  sea.rotation.x = -Math.PI / 2;
  sea.position.y = 1.5;
  group.add(sea);
  for (let i = 0; i < 15; i++) {
    const x = (Math.random() - 0.5) * 100;
    const z = (Math.random() - 0.5) * 100;
    addCylinder(group, x, 3, z, 0.3, 6, 0x8a6a3a);
    addSphere(group, x, 7, z, 2, 0x2a8a2a);
  }
  addCylinder(group, 5, 1.5, 5, 0.1, 3, 0xaaaaaa);
  addSphere(group, 5, 3, 5, 2, 0xff4444);
}

function buildIsland(group) {
  const sand = new THREE.Mesh(
    new THREE.CircleGeometry(30, 32),
    new THREE.MeshLambertMaterial({ color: 0xe8d090 })
  );
  sand.rotation.x = -Math.PI / 2;
  sand.position.y = 0.1;
  group.add(sand);
  const sea = new THREE.Mesh(
    new THREE.PlaneGeometry(200, 200),
    new THREE.MeshLambertMaterial({ color: 0x1199dd, transparent: true, opacity: 0.8 })
  );
  sea.rotation.x = -Math.PI / 2;
  sea.position.y = 0.5;
  group.add(sea);
  for (let i = 0; i < 8; i++) {
    const ang = (i / 8) * Math.PI * 2;
    const r = 15 + Math.random() * 10;
    addCylinder(group, Math.cos(ang) * r, 3, Math.sin(ang) * r, 0.3, 6, 0x8a6a3a);
    addSphere(group, Math.cos(ang) * r, 7, Math.sin(ang) * r, 2, 0x2a8a2a);
  }
}

// ===== QUEIMADA (Dodgeball) =====
function buildQueimada(group) {
  // Quadra retangular 40x20 com paredes baixas laterais
  // Linhas da quadra
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  // Linha central
  const centerLine = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 20), lineMat);
  centerLine.rotation.x = -Math.PI / 2;
  centerLine.position.y = 0.02;
  group.add(centerLine);
  // Linhas laterais
  const sideLine1 = new THREE.Mesh(new THREE.PlaneGeometry(40, 0.2), lineMat);
  sideLine1.rotation.x = -Math.PI / 2;
  sideLine1.position.set(0, 0.02, 10);
  group.add(sideLine1);
  const sideLine2 = sideLine1.clone();
  sideLine2.position.z = -10;
  group.add(sideLine2);
  // Linhas de fundo (gol)
  const backLine1 = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 20), lineMat);
  backLine1.rotation.x = -Math.PI / 2;
  backLine1.position.set(-20, 0.02, 0);
  group.add(backLine1);
  const backLine2 = backLine1.clone();
  backLine2.position.x = 20;
  group.add(backLine2);

  // Paredes laterais baixas (para bola não sair)
  for (const z of [10, -10]) {
    addBox(group, 0, 1, z, 40, 2, 0.2, 0x444444);
  }
  // Áreas de recuo (zonas seguras)
  const blueZone = new THREE.Mesh(
    new THREE.PlaneGeometry(5, 18),
    new THREE.MeshBasicMaterial({ color: 0x3b82f6, transparent: true, opacity: 0.3 })
  );
  blueZone.rotation.x = -Math.PI / 2;
  blueZone.position.set(-17.5, 0.03, 0);
  group.add(blueZone);
  const redZone = blueZone.clone();
  redZone.material = new THREE.MeshBasicMaterial({ color: 0xef4444, transparent: true, opacity: 0.3 });
  redZone.position.x = 17.5;
  group.add(redZone);

  // Cestas com bolas (decorativas, em cada canto)
  for (const x of [-18, 18]) {
    for (const z of [-8, 8]) {
      addCylinder(group, x, 0.5, z, 0.5, 1, 0xff6b35);
    }
  }

  // Plataforma central elevada (onde as bolas spawnam)
  addBox(group, 0, 0.1, 0, 4, 0.2, 4, 0xffaa00);

  // Luzes da quadra
  for (const x of [-15, 15]) {
    const light = new THREE.PointLight(0xffffff, 1.5, 30);
    light.position.set(x, 12, 0);
    group.add(light);
    addCylinder(group, x, 6, 0, 0.1, 12, 0x333333);
  }

  // Bancadas
  for (const z of [-12, 12]) {
    for (let i = 0; i < 3; i++) {
      addBox(group, -10 + i * 10, 0.5 + i * 0.4, z, 6, 0.3, 1.5, 0x666666);
    }
  }
}

// ===== FUTEBOL =====
function buildFutebol(group) {
  // Campo 80x50 com marcações
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  // Linhas laterais
  for (const z of [25, -25]) {
    const line = new THREE.Mesh(new THREE.PlaneGeometry(80, 0.2), lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(0, 0.02, z);
    group.add(line);
  }
  // Linhas de fundo
  for (const x of [-40, 40]) {
    const line = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 50), lineMat);
    line.rotation.x = -Math.PI / 2;
    line.position.set(x, 0.02, 0);
    group.add(line);
  }
  // Linha central
  const centerLine = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 50), lineMat);
  centerLine.rotation.x = -Math.PI / 2;
  centerLine.position.set(0, 0.02, 0);
  group.add(centerLine);
  // Círculo central
  const circle = new THREE.Mesh(
    new THREE.RingGeometry(4.8, 5, 32),
    lineMat
  );
  circle.rotation.x = -Math.PI / 2;
  circle.position.y = 0.03;
  group.add(circle);

  // Gols (com rede simulada)
  for (const x of [-40, 40]) {
    buildGoal(group, x, 0);
  }

  // Áreas
  for (const x of [-32, 32]) {
    const area = new THREE.Mesh(
      new THREE.PlaneGeometry(8, 22),
      new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.15 })
    );
    area.rotation.x = -Math.PI / 2;
    area.position.set(x, 0.025, 0);
    group.add(area);
  }

  // Bancadas ao redor
  for (const z of [-30, 30]) {
    for (let i = 0; i < 4; i++) {
      addBox(group, -30 + i * 20, 1 + i * 0.5, z, 12, 0.5, 2, 0x888888);
    }
  }

  // Refletores
  for (const x of [-30, 30]) {
    for (const z of [-30, 30]) {
      const light = new THREE.SpotLight(0xffffff, 2, 100, Math.PI / 4, 0.5);
      light.position.set(x, 25, z);
      light.target.position.set(0, 0, 0);
      group.add(light);
      group.add(light.target);
      addCylinder(group, x, 12, z, 0.3, 25, 0x333333);
    }
  }
}

function buildGoal(group, x, z) {
  // Postes
  addBox(group, x, 1.5, z - 4, 0.2, 3, 0.2, 0xffffff);
  addBox(group, x, 1.5, z + 4, 0.2, 3, 0.2, 0xffffff);
  // Trave superior
  addBox(group, x, 3, z, 0.2, 0.2, 8, 0xffffff);
  // Rede (simulada com plano transparente)
  const net = new THREE.Mesh(
    new THREE.PlaneGeometry(0.5, 8),
    new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.3, wireframe: true })
  );
  net.position.set(x + (x > 0 ? 0.5 : -0.5), 1.5, z);
  net.rotation.y = Math.PI / 2;
  group.add(net);
}

// ===== CAPTURE THE FLAG =====
function buildCTF(group) {
  // Duas bases opostas
  // Base azul
  addBox(group, -35, 0.1, 0, 10, 0.2, 10, 0x3b82f6);
  // Torre azul
  addCylinder(group, -35, 3, 0, 1, 6, 0x4a4a8a);
  addBox(group, -35, 6.5, 0, 2, 1, 2, 0x3b82f6);

  // Base vermelha
  addBox(group, 35, 0.1, 0, 10, 0.2, 10, 0xef4444);
  addCylinder(group, 35, 3, 0, 1, 6, 0x8a4a4a);
  addBox(group, 35, 6.5, 0, 2, 1, 2, 0xef4444);

  // Caminho central com obstáculos
  for (let i = -2; i <= 2; i++) {
    addBox(group, i * 8, 1, 8, 3, 2, 1, 0x666666);
    addBox(group, i * 8, 1, -8, 3, 2, 1, 0x666666);
  }
  // Ponte central
  addBox(group, 0, 0.5, 0, 6, 1, 4, 0x8a6a4a);
  // Água abaixo da ponte
  const water = new THREE.Mesh(
    new THREE.PlaneGeometry(8, 6),
    new THREE.MeshLambertMaterial({ color: 0x1166aa, transparent: true, opacity: 0.7 })
  );
  water.rotation.x = -Math.PI / 2;
  water.position.y = -0.5;
  group.add(water);

  // Muros laterais
  addBox(group, 0, 2, 18, 70, 4, 1, 0x555555);
  addBox(group, 0, 2, -18, 70, 4, 1, 0x555555);
}

function addBox(group, x, y, z, w, h, d, color) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(w, h, d),
    new THREE.MeshLambertMaterial({ color })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true; mesh.receiveShadow = true;
  group.add(mesh);
  window.Physics.addStaticBox([x, y, z], [w/2, h/2, d/2]);
}

function addCylinder(group, x, y, z, r, h, color) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(r, r, h, 12),
    new THREE.MeshLambertMaterial({ color })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  group.add(mesh);
  window.Physics.addStaticCylinder([x, y, z], r, h);
}

function addSphere(group, x, y, z, r, color) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(r, 16, 12),
    new THREE.MeshLambertMaterial({ color })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  group.add(mesh);
  window.Physics.addStaticSphere([x, y, z], r);
}

function ClearMap(scene) {
  for (const g of currentMapMeshes) {
    scene.remove(g);
    g.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        if (Array.isArray(o.material)) o.material.forEach(m => m.dispose());
        else o.material.dispose();
      }
    });
  }
  currentMapMeshes = [];
  waterMesh = null;
  waterUniforms = null;
  grassMeshes = [];
  ambientParticles = null;
}

// Atualiza shaders (chamado a cada frame)
function UpdateShaders(delta) {
  const t = performance.now() / 1000;
  if (waterUniforms) waterUniforms.time.value = t;
  for (const g of grassMeshes) {
    if (g.material && g.material.uniforms) g.material.uniforms.time.value = t;
  }
  if (ambientParticles && window.Effects) {
    window.Effects.updateAmbientParticles(ambientParticles, delta);
  }
}

window.Loader = {
  loadMap: LoadMap,
  clearMap: ClearMap,
  getMapList: () => Object.keys(MAPS).map(k => ({ id: k, name: MAPS[k].name })),
  createSky,
  UpdateShaders,
  MAPS
};
})();
