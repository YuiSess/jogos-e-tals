// ============================================================
// ui.js — Interface
// ============================================================
(function() {
'use strict';

let currentTab = 'head';
let previewCanvas = null;

function UIInit() {
  setupMenuNavigation();
  setupMainButtons();
  setupCustomize();
  setupEmotes();
  setupSettings();
  if (window.PeerAPI && window.PeerAPI.getMyId()) {
    document.getElementById('myPeerId').textContent = 'ID: ' + window.PeerAPI.getMyId();
  }
}

function setupMenuNavigation() {
  document.querySelectorAll('[data-back]').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
      document.getElementById('mainMenu').classList.add('active');
    };
  });
}

function setupMainButtons() {
  document.getElementById('btnPlay').onclick = () => startGame({ mode: 'solo', map: 'lobby', roomName: 'Solo' });
  document.getElementById('btnCreateRoom').onclick = () => showScreen('createRoomScreen');
  document.getElementById('btnJoinRoom').onclick = () => showScreen('joinRoomScreen');
  document.getElementById('btnCustomize').onclick = () => { showScreen('customizeScreen'); initCustomizePreview(); };
  document.getElementById('btnInventory').onclick = () => { showScreen('inventoryScreen'); if (window.Inventory) window.Inventory.render(); };
  document.getElementById('btnShop').onclick = () => { showScreen('shopScreen'); if (window.Inventory) window.Inventory.renderShop(); };
  document.getElementById('btnSettings').onclick = () => { showScreen('settingsScreen'); loadSettings(); };
  document.getElementById('btnCopyId').onclick = () => {
    const id = window.PeerAPI ? window.PeerAPI.getMyId() : null;
    if (id) { navigator.clipboard.writeText(id); addNotification('ID copiado!', 'success'); }
  };

  document.getElementById('btnConfirmCreate').onclick = () => {
    const roomName = document.getElementById('roomName').value || 'Sala';
    const map = document.getElementById('mapSelect').value;
    const mode = document.getElementById('modeSelect').value;
    const maxPlayers = parseInt(document.getElementById('maxPlayers').value);
    if (window.Network) {
      window.Network.init({
        onOpen: (id, isHost) => {
          document.getElementById('createRoomInfo').innerHTML =
            `✅ Sala criada!<br>Seu ID: <b>${id}</b><br>Compartilhe com seus amigos para eles entrarem.`;
          document.getElementById('myPeerId').textContent = 'ID: ' + id;
          // Inicia o jogo direto — o peer do próprio jogo é o host
          setTimeout(() => { startGame({ mode: 'host', map, roomName, maxPlayers, peerId: id, gameMode: mode }); }, 800);
        },
        onError: (err) => {
          document.getElementById('createRoomInfo').textContent = 'Erro: ' + err.type + ' — tente novamente.';
        }
      });
    }
  };

  document.getElementById('btnConfirmJoin').onclick = () => {
    const hostId = document.getElementById('hostIdInput').value.trim();
    const name = document.getElementById('playerNameInput').value.trim() || 'Jogador';
    if (!hostId) {
      document.getElementById('joinRoomInfo').textContent = '❌ Digite o ID do host!';
      return;
    }
    if (window.Save) window.Save.setPlayerName(name);
    const info = document.getElementById('joinRoomInfo');
    info.innerHTML = `🔄 Conectando a <b>${hostId}</b>...`;

    if (window.Network) {
      window.Network.init({
        onOpen: (id, isHost) => {
          document.getElementById('myPeerId').textContent = 'ID: ' + id;
          info.innerHTML = `🔄 Conectando ao host...`;
          window.Network.connect(hostId);
        },
        onError: (err) => {
          info.innerHTML = '❌ Erro: ' + err.type + '<br>Tente novamente ou verifique o ID.';
        },
        onPeerJoined: (peerId) => {
          info.innerHTML = '✅ Conectado ao host! Entrando no jogo...';
        }
      });
      // Timeout — se não conectar em 8s, avisa
      setTimeout(() => {
        if (!window.GameState || !window.GameState.inGame) {
          const connected = window.PeerAPI && window.PeerAPI.getConnectedPeerIds().length > 0;
          if (!connected) {
            info.innerHTML = '⚠️ Não foi possível conectar.<br>Verifique se o ID está correto e se o host está online.';
          } else {
            const map = (window.GameState && window.GameState.map) || 'lobby';
            const roomName = (window.GameState && window.GameState.roomName) || 'Sala';
            const gameMode = (window.GameState && window.GameState.gameMode) || 'free';
            startGame({ mode: 'client', map, roomName, hostId, gameMode });
          }
        }
      }, 5000);
    }
  };

  document.getElementById('btnSaveAvatar').onclick = () => {
    addNotification('Avatar salvo!', 'success');
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    document.getElementById('mainMenu').classList.add('active');
  };
}

function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function setupCustomize() {
  document.querySelectorAll('.tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentTab = tab.dataset.tab;
      renderCustomizeTab();
    };
  });
  renderCustomizeTab();
}

function initCustomizePreview() {
  previewCanvas = document.getElementById('avatarPreviewCanvas');
  if (previewCanvas && window.Avatar) window.Avatar.initPreview(previewCanvas);
  renderCustomizeTab();
}

function renderCustomizeTab() {
  const content = document.getElementById('customizeContent');
  if (!content) return;
  const av = window.Save.getAvatar();
  const acc = window.Save.getAccessories();
  let html = '';

  if (currentTab === 'head') {
    html += '<h4>Cor da Pele</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.headColor === c ? 'active' : ''}" style="background:${c}" data-field="headColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'body') {
    html += '<h4>Cor do Corpo</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.bodyColor === c ? 'active' : ''}" style="background:${c}" data-field="bodyColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'arms') {
    html += '<h4>Cor dos Braços</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.armsColor === c ? 'active' : ''}" style="background:${c}" data-field="armsColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'legs') {
    html += '<h4>Cor das Pernas</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.legsColor === c ? 'active' : ''}" style="background:${c}" data-field="legsColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'hair') {
    html += '<h4>Estilo de Cabelo</h4>';
    for (const h of window.Avatar.HAIR_STYLES) {
      html += `<button class="option-btn ${av.hairStyle === h ? 'active' : ''}" data-field="hairStyle" data-value="${h}">${h}</button>`;
    }
    html += '<h4>Cor do Cabelo</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.hairColor === c ? 'active' : ''}" style="background:${c}" data-field="hairColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'clothes') {
    html += '<h4>Roupa</h4>';
    for (const cl of window.Avatar.CLOTHES) {
      html += `<button class="option-btn ${av.clothes === cl ? 'active' : ''}" data-field="clothes" data-value="${cl}">${cl}</button>`;
    }
    html += '<h4>Cor da Roupa</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.clothesColor === c ? 'active' : ''}" style="background:${c}" data-field="clothesColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'shoes') {
    html += '<h4>Sapatos</h4>';
    for (const sh of window.Avatar.SHOES) {
      html += `<button class="option-btn ${av.shoes === sh ? 'active' : ''}" data-field="shoes" data-value="${sh}">${sh}</button>`;
    }
    html += '<h4>Cor dos Sapatos</h4><div>';
    for (const c of window.Avatar.COLORS) {
      html += `<div class="color-swatch ${av.shoesColor === c ? 'active' : ''}" style="background:${c}" data-field="shoesColor" data-value="${c}"></div>`;
    }
    html += '</div>';
  } else if (currentTab === 'accessory') {
    html += '<h4>Chapéu/Boné</h4>';
    for (const h of window.Avatar.HATS) {
      html += `<button class="option-btn ${acc.hat === h ? 'active' : ''}" data-acc="hat" data-value="${h || ''}">${h || 'Nenhum'}</button>`;
    }
    html += '<h4>Óculos</h4>';
    for (const g of window.Avatar.GLASSES) {
      html += `<button class="option-btn ${acc.glasses === g ? 'active' : ''}" data-acc="glasses" data-value="${g || ''}">${g || 'Nenhum'}</button>`;
    }
    html += '<h4>Máscara</h4>';
    for (const m of window.Avatar.MASKS) {
      html += `<button class="option-btn ${acc.mask === m ? 'active' : ''}" data-acc="mask" data-value="${m || ''}">${m || 'Nenhum'}</button>`;
    }
  } else if (currentTab === 'wings') {
    html += '<h4>Costas</h4>';
    for (const b of window.Avatar.BACKS) {
      html += `<button class="option-btn ${acc.back === b ? 'active' : ''}" data-acc="back" data-value="${b || ''}">${b || 'Nenhum'}</button>`;
    }
  }

  content.innerHTML = html;

  content.querySelectorAll('.color-swatch').forEach(sw => {
    sw.onclick = () => {
      const field = sw.dataset.field;
      const value = sw.dataset.value;
      av[field] = value;
      window.Save.setAvatar(av);
      content.querySelectorAll(`[data-field="${field}"]`).forEach(s => s.classList.remove('active'));
      sw.classList.add('active');
      if (window.Avatar) window.Avatar.updatePreview(av, acc);
    };
  });
  content.querySelectorAll('.option-btn').forEach(btn => {
    btn.onclick = () => {
      if (btn.dataset.acc) {
        const accField = btn.dataset.acc;
        const value = btn.dataset.value || null;
        acc[accField] = value;
        window.Save.setAccessories(acc);
        content.querySelectorAll(`[data-acc="${accField}"]`).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      } else {
        const field = btn.dataset.field;
        const value = btn.dataset.value;
        av[field] = value;
        window.Save.setAvatar(av);
        content.querySelectorAll(`[data-field="${field}"]`).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      }
      if (window.Avatar) window.Avatar.updatePreview(av, acc);
    };
  });
}

function setupEmotes() {
  document.querySelectorAll('#emoteBar button').forEach(btn => {
    btn.onclick = () => { if (window.Player) window.Player.playEmote(btn.dataset.emote); };
  });
  const btnDay = document.getElementById('btnDayNight');
  if (btnDay) {
    btnDay.onclick = () => {
      if (window.Loader) {
        const t = window.Loader.toggleDayNight();
        addNotification(`Hora: ${t < 0.25 ? 'Madrugada' : t < 0.5 ? 'Manhã' : t < 0.75 ? 'Tarde' : 'Noite'}`, 'info');
      }
    };
  }
  const btnWeather = document.getElementById('btnWeather');
  if (btnWeather) {
    btnWeather.onclick = () => {
      if (window.Loader) {
        const w = window.Loader.toggleWeather();
        addNotification(`Clima: ${w === 'clear' ? 'Limpo ☀️' : w === 'rain' ? 'Chuva 🌧️' : w === 'snow' ? 'Neve ❄️' : 'Folhas 🍂'}`, 'info');
      }
    };
  }
}

function setupSettings() {
  const settings = window.Save.getSettings();
  document.getElementById('sensitivity').oninput = (e) => { settings.sensitivity = parseFloat(e.target.value); window.Save.setSettings(settings); };
  document.getElementById('volume').oninput = (e) => { settings.volume = parseFloat(e.target.value); window.Save.setSettings(settings); };
  document.getElementById('fov').oninput = (e) => {
    settings.fov = parseInt(e.target.value);
    window.Save.setSettings(settings);
    if (window.GameState && window.GameState.camera) {
      window.GameState.camera.fov = settings.fov;
      window.GameState.camera.updateProjectionMatrix();
    }
  };
  document.getElementById('shadows').onchange = (e) => { settings.shadows = e.target.checked; window.Save.setSettings(settings); };
  document.getElementById('particles').onchange = (e) => { settings.particles = e.target.checked; window.Save.setSettings(settings); };
  if (document.getElementById('bloom')) {
    document.getElementById('bloom').onchange = (e) => { settings.bloom = e.target.checked; window.Save.setSettings(settings); };
  }
  document.getElementById('fpMode').onchange = (e) => { settings.fpMode = e.target.checked; window.Save.setSettings(settings); };
}

function loadSettings() {
  const s = window.Save.getSettings();
  document.getElementById('sensitivity').value = s.sensitivity;
  document.getElementById('volume').value = s.volume;
  document.getElementById('fov').value = s.fov;
  document.getElementById('shadows').checked = s.shadows;
  document.getElementById('particles').checked = s.particles;
  if (document.getElementById('bloom')) document.getElementById('bloom').checked = s.bloom !== false;
  document.getElementById('fpMode').checked = s.fpMode !== false;
}

function toggleInventory() {
  const screen = document.getElementById('inventoryScreen');
  if (screen.classList.contains('active')) {
    screen.classList.remove('active');
  } else {
    document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
    screen.classList.add('active');
    if (window.Inventory) window.Inventory.render();
  }
}

function startGame(options) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById('hud').classList.remove('hidden');
  document.getElementById('chatBox').classList.remove('hidden');
  if (window.Game) window.Game.start(options);
}

function onLobbyJoined(data) {
  if (window.GameState) {
    window.GameState.roomName = data.roomName;
    window.GameState.map = data.map;
    window.GameState.hostId = data.hostId;
    window.GameState.gameMode = data.gameMode || 'free';
  }
  updateRoomInfo(data.roomName, data.map);
}

function updateHealth(h) {
  const fill = document.getElementById('healthFill');
  const text = document.getElementById('healthText');
  if (fill) { fill.style.width = h + '%'; fill.classList.toggle('low', h < 30); }
  if (text) text.textContent = Math.max(0, Math.round(h));
}

function updateAmmo(mag, reserve, weaponName) {
  const ammo = document.getElementById('ammoText');
  const wpn = document.getElementById('hudWeapon');
  if (ammo) ammo.textContent = `${mag}/${reserve}`;
  if (wpn) wpn.textContent = weaponName;
}

function updateWeaponsList() {
  const div = document.getElementById('hudWeapons');
  if (!div) return;
  const inv = window.Save.getInventory();
  const slots = [
    { id: inv.equipped.weapon1, num: 1 },
    { id: inv.equipped.weapon2, num: 2 },
    { id: inv.equipped.weapon3, num: 3 }
  ];
  div.innerHTML = '';
  for (const s of slots) {
    if (!s.id) continue;
    const cfg = window.Weapon.WEAPONS[s.id];
    const el = document.createElement('div');
    if (window.Weapon && window.Weapon.getCurrentWeaponId() === s.id) el.classList.add('active');
    el.textContent = `${s.num}. ${cfg.icon} ${cfg.name}`;
    el.onclick = () => { if (window.Weapon) window.Weapon.selectSlot(s.num - 1); };
    div.appendChild(el);
  }
}

function updateRoomInfo(room, map) {
  const r = document.getElementById('hudRoom');
  const m = document.getElementById('hudMap');
  if (r) r.textContent = 'Sala: ' + (room || '-');
  if (m) m.textContent = 'Mapa: ' + (map || '-');
}

function updatePlayerCount(count) {
  const p = document.getElementById('hudPlayers');
  if (p) p.textContent = 'Jogadores: ' + count;
}

function addNotification(text, type, duration) {
  type = type || 'info';
  duration = duration || 3000;
  const div = document.getElementById('notifications');
  if (!div) return;
  const n = document.createElement('div');
  n.className = 'notif ' + type;
  n.textContent = text;
  div.appendChild(n);
  setTimeout(() => {
    n.style.opacity = '0';
    n.style.transition = 'opacity 0.3s';
    setTimeout(() => n.remove(), 300);
  }, duration);
}

function flashDamage() {
  let overlay = document.getElementById('damageOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'damageOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:radial-gradient(circle,transparent 30%,rgba(255,0,0,0.4) 100%);pointer-events:none;z-index:200;opacity:0;transition:opacity 0.2s;';
    document.body.appendChild(overlay);
  }
  overlay.style.opacity = '1';
  setTimeout(() => { overlay.style.opacity = '0'; }, 200);
}

window.UI = {
  init: UIInit, showScreen,
  updateHealth, updateAmmo, updateWeaponsList,
  updateRoomInfo, updatePlayerCount,
  addNotification, flashDamage,
  onLobbyJoined, toggleInventory,
  renderCustomize: renderCustomizeTab
};
})();
