// ============================================================
// game-mode.js — Modos de jogo: Queimada (com times + rounds + VFX), Futebol, CTF
// + sistema de bola com física + trail + animação de arremesso
// ============================================================
(function() {
'use strict';

let scene = null;
let camera = null;
let currentMode = 'free';
let balls = [];
let trailMaterial = null;
let team = 0;                // 1 = azul, 2 = vermelho
let scores = { team1: 0, team2: 0 };
let eliminated = new Set();      // peerIds eliminados
let eliminatedLocal = false;     // se eu fui eliminado
let flags = null;
let catchCooldown = 0;
let roundActive = false;
let roundNumber = 0;
let teams = { team1: [], team2: [] };  // arrays de peerIds
let playersAlive = { team1: 0, team2: 0 };
let roundEndCallback = null;
let ballRespawnTimer = 0;
let voidCheckTimer = 0;
let gameOverFor = null;
let winMessage = null;

const TEAM_COLORS = { 1: 0x3b82f6, 2: 0xef4444 };

function GameModeInit(scn, cam) {
  scene = scn;
  camera = cam;
}

// ===== Sincronização de bola =====
function spawnBall(position, velocity, throwerId) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 16, 12),
    new THREE.MeshPhongMaterial({ color: 0xff6b35, emissive: 0x331100 })
  );
  mesh.position.copy(position);
  mesh.castShadow = true;
  scene.add(mesh);

  const shape = new CANNON.Sphere(0.3);
  const body = new CANNON.Body({
    mass: 1,
    shape: shape,
    position: new CANNON.Vec3(position.x, position.y, position.z),
    material: window.Physics.getWorld().materials.objectMat,
    linearDamping: 0.1,
    angularDamping: 0.1
  });
  body.velocity.set(velocity.x, velocity.y, velocity.z);
  window.Physics.getWorld().addBody(body);

  const trailGeom = new THREE.BufferGeometry();
  const trailPositions = new Float32Array(60 * 3);
  trailGeom.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
  const trailMat = new THREE.LineBasicMaterial({
    color: 0xff6b35, transparent: true, opacity: 0.7, linewidth: 3
  });
  const trail = new THREE.Line(trailGeom, trailMat);
  trail.frustumCulled = false;
  scene.add(trail);

  const ball = {
    mesh, body, trail,
    trailPoints: [],
    holder: null,
    lastThrower: throwerId,
    spawnTime: performance.now(),
    active: true,
    spawnPos: position.clone()
  };
  balls.push(ball);

  body.addEventListener('collide', (e) => {
    onBallCollide(ball, e);
  });

  if (window.Network) {
    window.Network.broadcast({
      type: 'ball',
      action: 'spawn',
      id: window.PeerAPI.getMyId(),
      x: position.x, y: position.y, z: position.z,
      vx: velocity.x, vy: velocity.y, vz: velocity.z,
      thrower: throwerId
    });
  }
  return ball;
}

function throwBall() {
  if (currentMode !== 'queimada' && currentMode !== 'futebol') return false;
  let held = null;
  for (const b of balls) {
    if (b.holder === 'me') { held = b; break; }
  }
  if (!held) return false;

  const camPos = window.Player.getCameraPosition();
  const camDir = window.Player.getCameraDirection();
  const vel = camDir.clone().multiplyScalar(35);
  vel.y += 3;

  held.body.velocity.set(vel.x, vel.y, vel.z);
  held.body.angularVelocity.set(Math.random() * 10, Math.random() * 10, Math.random() * 10);
  held.holder = null;
  held.lastThrower = window.PeerAPI.getMyId();
  held.mesh.position.copy(camPos.clone().add(camDir.clone().multiplyScalar(1)));
  held.spawnPos = held.mesh.position.clone();

  startThrowAnimation();

  if (window.Network) {
    window.Network.broadcast({
      type: 'ball',
      action: 'throw',
      id: window.PeerAPI.getMyId(),
      x: held.mesh.position.x, y: held.mesh.position.y, z: held.mesh.position.z,
      vx: vel.x, vy: vel.y, vz: vel.z,
      thrower: window.PeerAPI.getMyId()
    });
  }

  if (window.Audio && window.Audio.playSound) window.Audio.playSound('throw', { volume: 0.4 });
  return true;
}

function tryCatchBall() {
  if (catchCooldown > 0) return false;
  // Não pode pegar bola se foi eliminado
  if (currentMode === 'queimada' && eliminatedLocal) {
    if (window.UI) window.UI.addNotification('Você foi queimado! Aguarde o round terminar.', 'warn', 1500);
    return false;
  }
  for (const b of balls) {
    if (b.holder === 'me') return false;
  }
  const playerPos = window.Player.getPosition();
  let closest = null;
  let closestDist = 3.5;
  for (const b of balls) {
    if (b.holder) continue;
    const dist = b.mesh.position.distanceTo(playerPos);
    if (dist < closestDist) {
      closestDist = dist;
      closest = b;
    }
  }
  if (closest) {
    closest.holder = 'me';
    catchCooldown = 0.3;
    if (window.Audio && window.Audio.playSound) window.Audio.playSound('catch', { volume: 0.5 });
    if (window.UI) window.UI.addNotification('🏐 Bola pegada! Clique para arremessar', 'success', 1500);
    if (window.Effects) {
      window.Effects.createImpact(
        closest.mesh.position.x, closest.mesh.position.y, closest.mesh.position.z,
        0, 1, 0, 0xff6b35
      );
    }
    if (window.Network) {
      window.Network.broadcast({
        type: 'ball',
        action: 'catch',
        id: window.PeerAPI.getMyId(),
        ballIndex: balls.indexOf(closest)
      });
    }
    return true;
  }
  return false;
}

// ===== Quando a bola colide com algo =====
function onBallCollide(ball, event) {
  if (!ball.active) return;
  if (ball.holder) return;
  if (window.Network) {
    const remote = window.Network.getRemotePlayers();
    const ballPos = ball.mesh.position;
    for (const [id, rp] of remote) {
      if (!rp.mesh) continue;
      if (id === ball.lastThrower) continue;
      // Não acerte aliados
      if (currentMode === 'queimada') {
        const throwerTeam = getPeerTeam(ball.lastThrower);
        const targetTeam = getPeerTeam(id);
        if (throwerTeam && targetTeam && throwerTeam === targetTeam) continue;
      }
      const dist = rp.mesh.position.distanceTo(ballPos);
      if (dist < 1.0) {
        hitPlayer(id, ball.lastThrower, ballPos.clone());
        break;
      }
    }
  }
}

// ===== Jogador é atingido =====
function hitPlayer(peerId, byPeerId, hitPos) {
  if (currentMode !== 'queimada') return;
  if (eliminated.has(peerId)) return;

  // Verifica se é fogo amigo (não deveria, mas por segurança)
  const throwerTeam = getPeerTeam(byPeerId);
  const targetTeam = getPeerTeam(peerId);
  if (throwerTeam && targetTeam && throwerTeam === targetTeam) return;

  eliminated.add(peerId);

  // VFX dramático de acerto
  if (window.Effects && hitPos) {
    window.Effects.createExplosion(hitPos.x, hitPos.y, hitPos.z, 2);
    window.Effects.createBlood(hitPos.x, hitPos.y, hitPos.z, new THREE.Vector3(0, 1, 0));
    window.Effects.createHitMarker(hitPos);
  }
  if (window.Audio && window.Audio.playSound) window.Audio.playSound('explosion', { volume: 0.8 });

  const rp = window.Network ? window.Network.getRemotePlayer(peerId) : null;
  const throwerRp = window.Network ? window.Network.getRemotePlayer(byPeerId) : null;
  const name = rp ? rp.name : 'Jogador';
  const throwerName = byPeerId === window.PeerAPI.getMyId() ?
    'Você' :
    (throwerRp ? throwerRp.name : 'Jogador');

  if (window.UI) {
    window.UI.addNotification(`${name} foi queimado por ${throwerName}!`, 'warn', 3000);
    window.UI.flashDamage();
  }
  if (window.Chat) window.Chat.addSystem(`${name} foi queimado por ${throwerName}!`);

  // Se fui eu, marco como eliminado localmente e congelo
  if (peerId === window.PeerAPI.getMyId()) {
    eliminatedLocal = true;
    if (window.Player) window.Player.takeDamage(50, 'queimada');
    if (window.UI) window.UI.addNotification('☠️ Você foi queimado! Aguarde o round terminar...', 'error', 5000);
    // Congela o jogador (fica parado)
    if (window.Player && window.Player.getPlayerMesh) {
      const mesh = window.Player.getPlayerMesh();
      if (mesh) mesh.userData.emoteLock = true;
    }
  }

  // Broadcast
  if (window.Network) {
    window.Network.broadcast({
      type: 'mode',
      action: 'eliminate',
      id: window.PeerAPI.getMyId(),
      peerId: peerId,
      byPeerId: byPeerId
    });
  }

  // Atualiza contagem de vivos e checa vitória
  updateAliveCount();
  checkWinCondition();
}

// ===== Pega o time de um peer =====
function getPeerTeam(peerId) {
  if (teams.team1.includes(peerId)) return 1;
  if (teams.team2.includes(peerId)) return 2;
  return 0;
}

// ===== Atualiza contagem de jogadores vivos =====
function updateAliveCount() {
  playersAlive.team1 = 0;
  playersAlive.team2 = 0;
  // Conta jogadores locais + remotos
  const allPlayers = [window.PeerAPI.getMyId(), ...window.PeerAPI.getConnectedPeerIds()];
  for (const pid of allPlayers) {
    if (eliminated.has(pid)) continue;
    const t = getPeerTeam(pid);
    if (t === 1) playersAlive.team1++;
    else if (t === 2) playersAlive.team2++;
  }
  if (window.UI && currentMode === 'queimada') {
    updateQueimadaHUD();
  }
}

// ===== Verifica condição de vitória =====
function checkWinCondition() {
  if (!roundActive) return;
  if (currentMode !== 'queimada') return;

  const minPlayers = 2;
  if (teams.team1.length + teams.team2.length < minPlayers) return;

  let winner = 0;
  if (playersAlive.team1 === 0 && playersAlive.team2 > 0) winner = 2;
  else if (playersAlive.team2 === 0 && playersAlive.team1 > 0) winner = 1;

  if (winner > 0) {
    endRound(winner);
  }
}

// ===== Termina um round =====
function endRound(winnerTeam) {
  roundActive = false;
  if (winnerTeam === 1) scores.team1++;
  else if (winnerTeam === 2) scores.team2++;

  const winnerName = winnerTeam === 1 ? 'Time Azul' : 'Time Vermelho';
  const myTeam = team;
  const iWon = myTeam === winnerTeam;

  if (window.UI) {
    window.UI.addNotification(
      iWon ? `🏆 ${winnerName} VENCEU! Você sobreviveu!` : `☠️ ${winnerName} venceu o round!`,
      iWon ? 'success' : 'warn',
      5000
    );
  }
  if (window.Chat) window.Chat.addSystem(`🏁 Round ${roundNumber}: ${winnerName} venceu! (Placar: ${scores.team1} x ${scores.team2})`);

  // VFX de vitória
  if (iWon && window.Effects) {
    // Chuva de partículas
    const playerPos = window.Player.getPosition();
    for (let i = 0; i < 30; i++) {
      setTimeout(() => {
        if (window.Effects) {
          window.Effects.createExplosion(
            playerPos.x + (Math.random() - 0.5) * 10,
            playerPos.y + Math.random() * 5 + 5,
            playerPos.z + (Math.random() - 0.5) * 10,
            1.5
          );
        }
      }, i * 100);
    }
  }

  // Broadcast
  if (window.Network) {
    window.Network.broadcast({
      type: 'mode',
      action: 'round_end',
      winner: winnerTeam,
      scores: scores,
      id: window.PeerAPI.getMyId()
    });
  }

  // Aguarda 5s e inicia próximo round
  setTimeout(() => {
    startNewRound();
  }, 5000);
}

// ===== Inicia um novo round =====
function startNewRound() {
  roundNumber++;
  eliminated.clear();
  eliminatedLocal = false;
  roundActive = true;
  gameOverFor = null;

  // Limpa bolas antigas
  clearAllBalls();

  // Respawns
  if (window.Player) {
    const spawnPos = getTeamSpawnPosition(team);
    if (window.Player.setRespawnPoint) window.Player.setRespawnPoint(spawnPos);
    window.Player.respawn();
  }

  // Spawna 3 bolas no centro (apenas host)
  if (window.PeerAPI && window.PeerAPI.isHost()) {
    setTimeout(() => {
      for (let i = 0; i < 3; i++) {
        spawnBall(
          new THREE.Vector3(-2 + i * 2, 5, 0),
          new THREE.Vector3(0, 0, 0),
          null
        );
      }
    }, 1000);
  }

  // Descongela o avatar
  if (window.Player && window.Player.getPlayerMesh) {
    const mesh = window.Player.getPlayerMesh();
    if (mesh) mesh.userData.emoteLock = false;
  }

  if (window.UI) {
    window.UI.addNotification(`🎯 Round ${roundNumber} começou!`, 'info', 3000);
    updateQueimadaHUD();
  }
  if (window.Chat) window.Chat.addSystem(`=== Round ${roundNumber} ===`);

  // Broadcast
  if (window.Network) {
    window.Network.broadcast({
      type: 'mode',
      action: 'round_start',
      round: roundNumber,
      id: window.PeerAPI.getMyId()
    });
  }
}

// ===== Posição de spawn baseada no time =====
function getTeamSpawnPosition(t) {
  if (t === 1) return new THREE.Vector3(-15, 1, 0);   // Time azul (esquerda)
  if (t === 2) return new THREE.Vector3(15, 1, 0);    // Time vermelho (direita)
  return new THREE.Vector3(0, 1, 0);
}

// ===== Animação de arremesso =====
function startThrowAnimation() {
  if (window.Player && window.Avatar) {
    const mesh = window.Player.getPlayerMesh();
    if (mesh) mesh.userData.throwAnim = performance.now();
  }
  if (window.Network) {
    window.Network.broadcast({
      type: 'emote',
      id: window.PeerAPI.getMyId(),
      emote: 'throw'
    });
  }
}

// ===== Recebe dados de bola da rede =====
function receiveBallData(data) {
  if (data.id === window.PeerAPI.getMyId()) return;
  if (data.action === 'spawn') {
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(0.3, 16, 12),
      new THREE.MeshPhongMaterial({ color: 0xff6b35, emissive: 0x331100 })
    );
    mesh.position.set(data.x, data.y, data.z);
    scene.add(mesh);
    const shape = new CANNON.Sphere(0.3);
    const body = new CANNON.Body({
      mass: 1, shape,
      position: new CANNON.Vec3(data.x, data.y, data.z),
      material: window.Physics.getWorld().materials.objectMat,
      linearDamping: 0.1
    });
    body.velocity.set(data.vx, data.vy, data.vz);
    window.Physics.getWorld().addBody(body);

    const trailGeom = new THREE.BufferGeometry();
    const trailPositions = new Float32Array(60 * 3);
    trailGeom.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
    const trail = new THREE.Line(trailGeom, new THREE.LineBasicMaterial({
      color: 0xff6b35, transparent: true, opacity: 0.7
    }));
    trail.frustumCulled = false;
    scene.add(trail);

    balls.push({
      mesh, body, trail, trailPoints: [],
      holder: null, lastThrower: data.thrower,
      spawnTime: performance.now(), active: true,
      spawnPos: new THREE.Vector3(data.x, data.y, data.z)
    });
  } else if (data.action === 'throw') {
    let closest = null;
    let closestDist = 5;
    for (const b of balls) {
      const d = b.mesh.position.distanceTo(new THREE.Vector3(data.x, data.y, data.z));
      if (d < closestDist) { closestDist = d; closest = b; }
    }
    if (closest) {
      closest.holder = null;
      closest.lastThrower = data.thrower;
      closest.body.velocity.set(data.vx, data.vy, data.vz);
      closest.mesh.position.set(data.x, data.y, data.z);
      closest.spawnPos = closest.mesh.position.clone();
    }
    const rp = window.Network ? window.Network.getRemotePlayer(data.id) : null;
    if (rp && rp.mesh) rp.mesh.userData.throwAnim = performance.now();
  } else if (data.action === 'catch') {
    const ball = balls[data.ballIndex];
    if (ball) ball.holder = data.id;
  } else if (data.action === 'respawn_ball') {
    // Bola respawna no centro
    const ball = balls[data.ballIndex];
    if (ball) {
      ball.holder = null;
      ball.mesh.position.set(data.x, data.y, data.z);
      ball.body.position.set(data.x, data.y, data.z);
      ball.body.velocity.set(0, 0, 0);
      ball.spawnPos = new THREE.Vector3(data.x, data.y, data.z);
      // VFX de respawn
      if (window.Effects) {
        window.Effects.createImpact(data.x, data.y, data.z, 0, 1, 0, 0xffaa00);
      }
    }
  }
}

// ===== Recebe dados de modo da rede =====
function receiveModeData(data) {
  if (data.action === 'eliminate') {
    // Processa eliminação vinda da rede
    hitPlayer(data.peerId, data.byPeerId, null);
  } else if (data.action === 'round_start') {
    if (data.id !== window.PeerAPI.getMyId()) {
      roundNumber = data.round;
      eliminated.clear();
      eliminatedLocal = false;
      roundActive = true;
      if (window.UI) {
        window.UI.addNotification(`🎯 Round ${roundNumber} começou!`, 'info', 3000);
        updateQueimadaHUD();
      }
      if (window.Chat) window.Chat.addSystem(`=== Round ${roundNumber} ===`);
    }
  } else if (data.action === 'round_end') {
    if (data.id !== window.PeerAPI.getMyId()) {
      roundActive = false;
      scores = data.scores;
      const winnerName = data.winner === 1 ? 'Time Azul' : 'Time Vermelho';
      const iWon = team === data.winner;
      if (window.UI) {
        window.UI.addNotification(
          iWon ? `🏆 ${winnerName} VENCEU!` : `☠️ ${winnerName} venceu o round!`,
          iWon ? 'success' : 'warn',
          5000
        );
      }
      if (window.Chat) window.Chat.addSystem(`🏁 Round: ${winnerName} venceu! (${scores.team1} x ${scores.team2})`);
      setTimeout(() => {
        if (roundActive === false) startNewRound();
      }, 5000);
    }
  } else if (data.action === 'team_assign') {
    // Host atribuiu time a um jogador
    if (data.peerId === window.PeerAPI.getMyId()) {
      team = data.team;
      if (window.UI) {
        window.UI.addNotification(`Você é do Time ${team === 1 ? 'Azul 🔵' : 'Vermelho 🔴'}`, 'info', 3000);
        updateQueimadaHUD();
      }
    }
    if (data.id !== window.PeerAPI.getMyId()) {
      // Atualiza localmente
      if (data.team === 1 && !teams.team1.includes(data.peerId)) {
        teams.team1.push(data.peerId);
        teams.team2 = teams.team2.filter(p => p !== data.peerId);
      } else if (data.team === 2 && !teams.team2.includes(data.peerId)) {
        teams.team2.push(data.peerId);
        teams.team1 = teams.team1.filter(p => p !== data.peerId);
      }
      if (window.UI && currentMode === 'queimada') {
        updateQueimadaHUD();
      }
    }
  }
}

// ===== Atribuir time (host) =====
function assignTeam(peerId, t) {
  if (!window.PeerAPI || !window.PeerAPI.isHost()) return;
  if (t === 1) {
    teams.team1.push(peerId);
    teams.team2 = teams.team2.filter(p => p !== peerId);
  } else {
    teams.team2.push(peerId);
    teams.team1 = teams.team1.filter(p => p !== peerId);
  }
  if (peerId === window.PeerAPI.getMyId()) team = t;
  if (window.Network) {
    window.Network.broadcast({
      type: 'mode',
      action: 'team_assign',
      peerId: peerId,
      team: t,
      id: window.PeerAPI.getMyId()
    });
  }
  if (window.UI) updateQueimadaHUD();
}

// ===== Auto-balancear times =====
function autoBalanceTeams() {
  if (!window.PeerAPI || !window.PeerAPI.isHost()) return;
  const allPlayers = [window.PeerAPI.getMyId(), ...window.PeerAPI.getConnectedPeerIds()];
  teams.team1 = [];
  teams.team2 = [];
  for (let i = 0; i < allPlayers.length; i++) {
    const pid = allPlayers[i];
    if (i % 2 === 0) {
      teams.team1.push(pid);
      if (pid === window.PeerAPI.getMyId()) team = 1;
    } else {
      teams.team2.push(pid);
      if (pid === window.PeerAPI.getMyId()) team = 2;
    }
  }
  // Broadcast
  for (const pid of allPlayers) {
    const t = teams.team1.includes(pid) ? 1 : 2;
    if (window.Network) {
      window.Network.broadcast({
        type: 'mode',
        action: 'team_assign',
        peerId: pid,
        team: t,
        id: window.PeerAPI.getMyId()
      });
    }
  }
  if (window.UI) updateQueimadaHUD();
}

// ===== Update =====
function GameModeUpdate(delta) {
  catchCooldown = Math.max(0, catchCooldown - delta);
  ballRespawnTimer += delta;
  voidCheckTimer += delta;

  // Atualiza bolas
  for (let i = balls.length - 1; i >= 0; i--) {
    const ball = balls[i];
    if (!ball.active) continue;

    if (ball.holder === 'me') {
      const camPos = window.Player.getCameraPosition();
      const camDir = window.Player.getCameraDirection();
      const handPos = camPos.clone().add(camDir.clone().multiplyScalar(1.0));
      handPos.y -= 0.3;
      ball.mesh.position.copy(handPos);
      ball.body.position.set(handPos.x, handPos.y, handPos.z);
      ball.body.velocity.set(0, 0, 0);
      ball.body.angularVelocity.set(0, 0, 0);
    } else if (ball.holder) {
      const rp = window.Network.getRemotePlayer(ball.holder);
      if (rp && rp.mesh) {
        const handPos = rp.mesh.position.clone();
        handPos.y += 1.2;
        handPos.x += Math.cos(rp.currentRot.y) * 0.5;
        handPos.z -= Math.sin(rp.currentRot.y) * 0.5;
        ball.mesh.position.copy(handPos);
        ball.body.position.set(handPos.x, handPos.y, handPos.z);
        ball.body.velocity.set(0, 0, 0);
      }
    } else {
      ball.mesh.position.copy(ball.body.position);
      ball.mesh.quaternion.copy(ball.body.quaternion);
    }

    // Trail
    ball.trailPoints.push(ball.mesh.position.clone());
    if (ball.trailPoints.length > 60) ball.trailPoints.shift();
    const positions = ball.trail.geometry.attributes.position.array;
    for (let j = 0; j < 60; j++) {
      if (j < ball.trailPoints.length) {
        const p = ball.trailPoints[j];
        positions[j*3] = p.x;
        positions[j*3+1] = p.y;
        positions[j*3+2] = p.z;
      } else {
        positions[j*3] = ball.mesh.position.x;
        positions[j*3+1] = ball.mesh.position.y;
        positions[j*3+2] = ball.mesh.position.z;
      }
    }
    ball.trail.geometry.attributes.position.needsUpdate = true;
    ball.trail.geometry.setDrawRange(0, ball.trailPoints.length);

    // Remove bolas muito antigas
    if (performance.now() - ball.spawnTime > 60000 || ball.body.position.y < -25) {
      removeBall(i);
    }
  }

  // === Verifica respawn de bola (host only) ===
  if (window.PeerAPI && window.PeerAPI.isHost() && currentMode === 'queimada' && ballRespawnTimer > 1.0) {
    ballRespawnTimer = 0;
    for (let i = 0; i < balls.length; i++) {
      const ball = balls[i];
      if (ball.holder) continue;
      const pos = ball.mesh.position;
      // Se a bola saiu da quadra (|x| > 25 ou |z| > 14 ou caiu no chão estática)
      const isOutOfPlay = Math.abs(pos.x) > 25 || Math.abs(pos.z) > 14 || pos.y < -10;
      // Se está parada e fora da área central
      const vel = ball.body.velocity;
      const isStatic = Math.abs(vel.x) < 0.5 && Math.abs(vel.y) < 0.5 && Math.abs(vel.z) < 0.5;
      if (isOutOfPlay || (isStatic && pos.y < 1 && (Math.abs(pos.x) > 18 || Math.abs(pos.z) > 8))) {
        // Respawna a bola no centro
        const newPos = new THREE.Vector3(0, 5, 0);
        ball.holder = null;
        ball.mesh.position.copy(newPos);
        ball.body.position.set(newPos.x, newPos.y, newPos.z);
        ball.body.velocity.set(0, 0, 0);
        ball.spawnPos = newPos.clone();
        // VFX de respawn
        if (window.Effects) {
          window.Effects.createImpact(newPos.x, newPos.y, newPos.z, 0, 1, 0, 0xffaa00);
        }
        if (window.Network) {
          window.Network.broadcast({
            type: 'ball',
            action: 'respawn_ball',
            id: window.PeerAPI.getMyId(),
            ballIndex: i,
            x: newPos.x, y: newPos.y, z: newPos.z
          });
        }
        if (window.UI) window.UI.addNotification('🏐 Bola voltou ao centro!', 'info', 1500);
      }
    }
  }

  // === Anti-void: verifica jogador local a cada 0.5s ===
  if (currentMode === 'queimada' && voidCheckTimer > 0.5) {
    voidCheckTimer = 0;
    if (window.Player) {
      const pos = window.Player.getPosition();
      // Se caiu no void (y < 0 ou fora da quadra)
      if (pos.y < 0 || Math.abs(pos.x) > 30 || Math.abs(pos.z) > 18) {
        const spawnPos = getTeamSpawnPosition(team);
        if (window.Player.setRespawnPoint) window.Player.setRespawnPoint(spawnPos);
        window.Player.respawn();
        if (window.UI) window.UI.addNotification('Você caiu! Voltando para sua base.', 'warn', 2000);
      }
    }
  }

  // Verifica condição de vitória periodicamente
  if (currentMode === 'queimada' && roundActive && ballRespawnTimer > 0.5) {
    updateAliveCount();
    checkWinCondition();
  }
}

function removeBall(index) {
  const ball = balls[index];
  if (!ball) return;
  if (ball.mesh && ball.mesh.parent) ball.mesh.parent.remove(ball.mesh);
  if (ball.mesh.geometry) ball.mesh.geometry.dispose();
  if (ball.mesh.material) ball.mesh.material.dispose();
  if (ball.trail && ball.trail.parent) ball.trail.parent.remove(ball.trail);
  if (ball.trail.geometry) ball.trail.geometry.dispose();
  if (window.Physics && ball.body) {
    try { window.Physics.getWorld().removeBody(ball.body); } catch(e){}
  }
  balls.splice(index, 1);
}

function clearAllBalls() {
  for (let i = balls.length - 1; i >= 0; i--) removeBall(i);
}

// ===== HUD específico da queimada =====
function updateQueimadaHUD() {
  if (currentMode !== 'queimada') return;
  // Atualiza no elemento hudRoom
  const hudRoom = document.getElementById('hudRoom');
  if (hudRoom) {
    const myTeamName = team === 1 ? '🔵 Azul' : team === 2 ? '🔴 Vermelho' : 'Sem time';
    const aliveStatus = eliminatedLocal ? ' (MORTO)' : '';
    hudRoom.innerHTML = `QUEIMADA ${myTeamName}${aliveStatus} | Round ${roundNumber} | ${scores.team1} x ${scores.team2} | 🔵${playersAlive.team1} vs 🔴${playersAlive.team2}`;
  }
}

// ===== Setup Queimada =====
function setupQueimada() {
  currentMode = 'queimada';
  scores = { team1: 0, team2: 0 };
  eliminated.clear();
  eliminatedLocal = false;
  roundNumber = 0;
  teams = { team1: [], team2: [] };
  playersAlive = { team1: 0, team2: 0 };

  // Auto-balanceia times se for host
  if (window.PeerAPI && window.PeerAPI.isHost()) {
    setTimeout(() => autoBalanceTeams(), 500);
  } else {
    // Cliente: tem que descobrir seu time via mensagem team_assign do host
    team = 0;
  }

  if (window.UI) {
    window.UI.addNotification('🏐 QUEIMADA! Times serão formados automaticamente', 'info', 4000);
    window.UI.addNotification('Q: Pegar bola · Botão Esq: Arremessar', 'info', 3000);
  }
  // Abre a tela de seleção de times
  setTimeout(() => {
    if (window.UI) window.UI.showTeamSelect();
  }, 1000);

  // Inicia o primeiro round em 5s
  setTimeout(() => {
    if (window.PeerAPI && window.PeerAPI.isHost()) {
      startNewRound();
    }
  }, 5000);
}

function setupFutebol() {
  currentMode = 'futebol';
  scores = { team1: 0, team2: 0 };
  if (window.PeerAPI && window.PeerAPI.isHost()) {
    setTimeout(() => {
      spawnBall(new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, 0, 0), null);
    }, 1000);
  }
  if (window.UI) {
    window.UI.addNotification(`FUTEBOL!`, 'info');
    window.UI.addNotification('Q: Chutar (aproxima da bola)', 'info');
  }
}

function setupCTF() {
  currentMode = 'ctf';
  scores = { team1: 0, team2: 0 };
  const myId = window.PeerAPI.getMyId();
  team = (myId.charCodeAt(0) + myId.charCodeAt(1)) % 2 === 0 ? 1 : 2;
  flags = {
    flag1: createFlag(new THREE.Vector3(-30, 0, 0), 0x3b82f6),
    flag2: createFlag(new THREE.Vector3(30, 0, 0), 0xef4444)
  };
  if (window.UI) {
    window.UI.addNotification(`CAPTURE THE FLAG! Você é do Time ${team === 1 ? 'Azul' : 'Vermelho'}`, 'info');
  }
}

function createFlag(position, color) {
  const group = new THREE.Group();
  const pole = new THREE.Mesh(
    new THREE.CylinderGeometry(0.05, 0.05, 3, 8),
    new THREE.MeshLambertMaterial({ color: 0x666666 })
  );
  pole.position.y = 1.5;
  group.add(pole);
  const flag = new THREE.Mesh(
    new THREE.PlaneGeometry(1, 0.6),
    new THREE.MeshLambertMaterial({ color, side: THREE.DoubleSide })
  );
  flag.position.set(0.5, 2.5, 0);
  group.add(flag);
  group.position.copy(position);
  scene.add(group);
  return group;
}

function setupFree() {
  currentMode = 'free';
  scores = { team1: 0, team2: 0 };
  eliminated.clear();
  eliminatedLocal = false;
  if (flags) {
    if (flags.flag1 && flags.flag1.parent) flags.flag1.parent.remove(flags.flag1);
    if (flags.flag2 && flags.flag2.parent) flags.flag2.parent.remove(flags.flag2);
    flags = null;
  }
  if (window.UI) window.UI.hideTeamSelect();
}

function setMode(mode) {
  clearAllBalls();
  setupFree();
  if (mode === 'queimada') setupQueimada();
  else if (mode === 'futebol') setupFutebol();
  else if (mode === 'ctf') setupCTF();
}

// ===== API para UI chamar (selecionar time) =====
function joinTeam(t) {
  if (!window.PeerAPI) return;
  if (window.PeerAPI.isHost()) {
    assignTeam(window.PeerAPI.getMyId(), t);
  } else {
    // Cliente pede para host atribuir time (via broadcast, host processa)
    if (window.Network) {
      window.Network.broadcast({
        type: 'mode',
        action: 'request_team',
        peerId: window.PeerAPI.getMyId(),
        team: t,
        id: window.PeerAPI.getMyId()
      });
    }
    // Assume imediatamente para feedback visual
    team = t;
    if (window.UI) {
      window.UI.addNotification(`Você pediu Time ${t === 1 ? 'Azul 🔵' : 'Vermelho 🔴'}`, 'info', 2000);
    }
  }
}

function getMode() { return currentMode; }
function getTeam() { return team; }
function getScores() { return scores; }
function getTeams() { return teams; }
function getPlayersAlive() { return playersAlive; }
function getRoundNumber() { return roundNumber; }
function isEliminated() { return eliminatedLocal; }
function isRoundActive() { return roundActive; }
function isPeerEliminated(peerId) { return eliminated.has(peerId); }

window.GameMode = {
  init: GameModeInit,
  update: GameModeUpdate,
  spawnBall, throwBall, tryCatchBall,
  receiveBall: receiveBallData,
  receiveMode: receiveModeData,
  setMode, getMode, getTeam, getScores,
  getTeams, getPlayersAlive, getRoundNumber,
  isEliminated, isRoundActive, isPeerEliminated,
  joinTeam, assignTeam, autoBalanceTeams,
  clearAllBalls,
  updateQueimadaHUD,
  TEAM_COLORS
};
})();
