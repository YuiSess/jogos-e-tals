// ============================================================
// builder.js — Construção sincronizada
// ============================================================
(function() {
'use strict';

let scene = null;
let active = false;
let currentBlockType = 'box';
let currentColor = '#3b82f6';
let ghostMesh = null;
let placedBlocks = [];
let nextBlockId = 1;
let gridSnap = 1;
let selectedBlock = null;
let previewRotation = 0;
let previewScale = 1;

const BLOCK_TYPES = {
  box:      { geom: () => new THREE.BoxGeometry(1, 1, 1), half: [0.5, 0.5, 0.5] },
  ramp:     { geom: () => makeRampGeom(), half: [0.5, 0.5, 0.5] },
  cylinder: { geom: () => new THREE.CylinderGeometry(0.5, 0.5, 1, 16), half: [0.5, 0.5, 0.5] },
  sphere:   { geom: () => new THREE.SphereGeometry(0.5, 16, 12), half: [0.5, 0.5, 0.5] },
  plate:    { geom: () => new THREE.BoxGeometry(1, 0.1, 1), half: [0.5, 0.05, 0.5] }
};

const COLORS = ['#ef4444','#f97316','#fbbf24','#10b981','#3b82f6','#8b5cf6',
  '#ec4899','#ffffff','#1f2937','#9ca3af','#06b6d4','#84cc16'];

function makeRampGeom() {
  const geom = new THREE.BufferGeometry();
  const verts = new Float32Array([
    -0.5, -0.5, -0.5,   0.5, -0.5, -0.5,   0.5, -0.5, 0.5,
    -0.5, -0.5, -0.5,   0.5, -0.5, 0.5,    -0.5, -0.5, 0.5,
    -0.5, -0.5, -0.5,   0.5, 0.5, -0.5,    0.5, -0.5, -0.5,
    -0.5, -0.5, -0.5,  -0.5, 0.5, -0.5,    0.5, 0.5, -0.5,
    -0.5, -0.5, 0.5,    0.5, -0.5, 0.5,    0.5, 0.5, -0.5,
    -0.5, -0.5, 0.5,    0.5, 0.5, -0.5,   -0.5, 0.5, -0.5,
    -0.5, 0.5, -0.5,    0.5, 0.5, -0.5,    0.5, -0.5, 0.5,
    -0.5, 0.5, -0.5,    0.5, -0.5, 0.5,   -0.5, -0.5, 0.5
  ]);
  geom.setAttribute('position', new THREE.BufferAttribute(verts, 3));
  geom.computeVertexNormals();
  return geom;
}

function BuilderInit(scn) {
  scene = scn;
  const colorsDiv = document.getElementById('buildColors');
  if (colorsDiv) {
    colorsDiv.innerHTML = '';
    for (const c of COLORS) {
      const sw = document.createElement('div');
      sw.className = 'color-swatch';
      sw.style.background = c;
      sw.onclick = () => {
        currentColor = c;
        document.querySelectorAll('#buildColors .color-swatch').forEach(s => s.classList.remove('active'));
        sw.classList.add('active');
        updateGhost();
      };
      colorsDiv.appendChild(sw);
    }
  }
  document.querySelectorAll('.build-blocks button').forEach(btn => {
    btn.onclick = () => {
      currentBlockType = btn.dataset.block;
      document.querySelectorAll('.build-blocks button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      updateGhost();
    };
  });
  document.getElementById('buildRotate').onclick = () => { previewRotation += Math.PI / 4; updateGhost(); };
  document.getElementById('buildScale').onclick = () => { previewScale = previewScale >= 3 ? 0.5 : previewScale + 0.5; updateGhost(); };
  document.getElementById('buildDuplicate').onclick = duplicateSelected;
  document.getElementById('buildDelete').onclick = deleteSelected;
  document.getElementById('buildSave').onclick = saveMap;
  document.getElementById('buildLoad').onclick = loadMap;
  document.getElementById('buildExit').onclick = () => toggle();
  const first = document.querySelector('.build-blocks button');
  if (first) first.classList.add('active');
}

function toggle() {
  active = !active;
  const panel = document.getElementById('buildPanel');
  if (panel) panel.classList.toggle('hidden', !active);
  if (window.UI) window.UI.addNotification(active ? 'Modo construção ativo [B]' : 'Modo construção desativado', 'info');
  if (active) { if (!ghostMesh) updateGhost(); }
  else { if (ghostMesh && ghostMesh.parent) ghostMesh.parent.remove(ghostMesh); ghostMesh = null; }
}

function isActive() { return active; }

function updateGhost() {
  if (!active) return;
  if (ghostMesh && ghostMesh.parent) ghostMesh.parent.remove(ghostMesh);
  const cfg = BLOCK_TYPES[currentBlockType] || BLOCK_TYPES.box;
  const mat = new THREE.MeshLambertMaterial({ color: currentColor, transparent: true, opacity: 0.5 });
  ghostMesh = new THREE.Mesh(cfg.geom(), mat);
  ghostMesh.scale.setScalar(previewScale);
  ghostMesh.rotation.y = previewRotation;
  scene.add(ghostMesh);
}

function BuilderUpdate(delta) {
  if (!active || !ghostMesh) return;
  if (!window.Player) return;
  const camPos = window.Player.getCameraPosition();
  const camDir = window.Player.getCameraDirection();
  const from = camPos;
  const to = camPos.clone().add(camDir.clone().multiplyScalar(8));
  const hit = window.Physics.raycast(from, to);
  let pos;
  if (hit && hit.hasHit) {
    pos = new THREE.Vector3(hit.hitPoint.x, hit.hitPoint.y, hit.hitPoint.z);
    pos.x = Math.round(pos.x / gridSnap) * gridSnap;
    pos.y = Math.round(pos.y / gridSnap) * gridSnap + 0.5 * previewScale;
    pos.z = Math.round(pos.z / gridSnap) * gridSnap;
  } else {
    pos = camPos.clone().add(camDir.clone().multiplyScalar(5));
  }
  ghostMesh.position.copy(pos);
  ghostMesh.rotation.y = previewRotation;
  ghostMesh.scale.setScalar(previewScale);
  const prompt = document.getElementById('buildPrompt');
  if (prompt) prompt.textContent = `Bloco: ${currentBlockType} | Cor: ${currentColor} | Tamanho: ${previewScale}x | Clique Esq: Colocar | Clique Dir: Excluir`;
}

function placeBlock() {
  if (!active || !ghostMesh) return;
  const cfg = BLOCK_TYPES[currentBlockType] || BLOCK_TYPES.box;
  const mat = new THREE.MeshLambertMaterial({ color: currentColor });
  const mesh = new THREE.Mesh(cfg.geom(), mat);
  mesh.position.copy(ghostMesh.position);
  mesh.rotation.y = previewRotation;
  mesh.scale.setScalar(previewScale);
  mesh.castShadow = true; mesh.receiveShadow = true;
  scene.add(mesh);
  const half = cfg.half.map(h => h * previewScale);
  const bodyId = window.Physics.addStaticBox([mesh.position.x, mesh.position.y, mesh.position.z], half, [0, previewRotation, 0]);
  const block = {
    id: nextBlockId++, mesh, bodyId,
    type: currentBlockType, color: currentColor,
    position: { x: mesh.position.x, y: mesh.position.y, z: mesh.position.z },
    rotation: previewRotation, scale: previewScale
  };
  placedBlocks.push(block);
  if (window.Network) window.Network.broadcast({ type: 'build', action: 'place', id: window.PeerAPI.getMyId(), block });
}

function deleteBlock() {
  if (!active || !window.Player) return;
  const camPos = window.Player.getCameraPosition();
  const camDir = window.Player.getCameraDirection();
  let closest = null;
  let closestDist = 10;
  for (const b of placedBlocks) {
    const dist = b.mesh.position.distanceTo(camPos);
    const toBlock = b.mesh.position.clone().sub(camPos).normalize();
    const dot = toBlock.dot(camDir);
    if (dot > 0.95 && dist < closestDist) { closestDist = dist; closest = b; }
  }
  if (closest) {
    removeBlock(closest.id);
    if (window.Network) window.Network.broadcast({ type: 'build', action: 'delete', id: window.PeerAPI.getMyId(), blockId: closest.id });
  }
}

function deleteSelected() {
  if (selectedBlock) { removeBlock(selectedBlock.id); selectedBlock = null; }
}

function duplicateSelected() {
  if (!selectedBlock) return;
  const cfg = BLOCK_TYPES[selectedBlock.type];
  const mat = new THREE.MeshLambertMaterial({ color: selectedBlock.color });
  const mesh = new THREE.Mesh(cfg.geom(), mat);
  mesh.position.set(selectedBlock.position.x + 1, selectedBlock.position.y, selectedBlock.position.z);
  mesh.rotation.y = selectedBlock.rotation;
  mesh.scale.setScalar(selectedBlock.scale);
  scene.add(mesh);
  const half = cfg.half.map(h => h * selectedBlock.scale);
  const bodyId = window.Physics.addStaticBox([mesh.position.x, mesh.position.y, mesh.position.z], half, [0, selectedBlock.rotation, 0]);
  const block = { id: nextBlockId++, mesh, bodyId, type: selectedBlock.type, color: selectedBlock.color,
    position: { x: mesh.position.x, y: mesh.position.y, z: mesh.position.z }, rotation: selectedBlock.rotation, scale: selectedBlock.scale };
  placedBlocks.push(block);
  if (window.Network) window.Network.broadcast({ type: 'build', action: 'place', id: window.PeerAPI.getMyId(), block });
}

function removeBlock(blockId) {
  const idx = placedBlocks.findIndex(b => b.id === blockId);
  if (idx === -1) return;
  const b = placedBlocks[idx];
  if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
  if (b.mesh.geometry) b.mesh.geometry.dispose();
  if (b.mesh.material) b.mesh.material.dispose();
  window.Physics.removeBody(b.bodyId);
  placedBlocks.splice(idx, 1);
}

function receiveBuild(data) {
  if (data.id === window.PeerAPI.getMyId()) return;
  if (data.action === 'place') {
    const b = data.block;
    const cfg = BLOCK_TYPES[b.type] || BLOCK_TYPES.box;
    const mat = new THREE.MeshLambertMaterial({ color: b.color });
    const mesh = new THREE.Mesh(cfg.geom(), mat);
    mesh.position.set(b.position.x, b.position.y, b.position.z);
    mesh.rotation.y = b.rotation;
    mesh.scale.setScalar(b.scale);
    scene.add(mesh);
    const half = cfg.half.map(h => h * b.scale);
    const bodyId = window.Physics.addStaticBox([b.position.x, b.position.y, b.position.z], half, [0, b.rotation, 0]);
    placedBlocks.push({ id: b.id, mesh, bodyId, type: b.type, color: b.color, position: b.position, rotation: b.rotation, scale: b.scale });
  } else if (data.action === 'delete') {
    removeBlock(data.blockId);
  }
}

function saveMap() {
  const name = prompt('Nome do mapa:', 'meu_mapa');
  if (!name) return;
  const data = { blocks: placedBlocks.map(b => ({ id: b.id, type: b.type, color: b.color, position: b.position, rotation: b.rotation, scale: b.scale })) };
  window.Save.saveMap(name, data);
  if (window.UI) window.UI.addNotification(`Mapa "${name}" salvo (${data.blocks.length} blocos)`, 'success');
}

function loadMap() {
  const maps = window.Save.getSavedMaps();
  const names = Object.keys(maps);
  if (names.length === 0) { if (window.UI) window.UI.addNotification('Nenhum mapa salvo', 'warn'); return; }
  const name = prompt('Nome do mapa para carregar:\n' + names.join(', '), names[0]);
  if (!name) return;
  const data = window.Save.loadMap(name);
  if (!data) return;
  clearAllBlocks();
  for (const b of data.blocks) {
    const cfg = BLOCK_TYPES[b.type] || BLOCK_TYPES.box;
    const mat = new THREE.MeshLambertMaterial({ color: b.color });
    const mesh = new THREE.Mesh(cfg.geom(), mat);
    mesh.position.set(b.position.x, b.position.y, b.position.z);
    mesh.rotation.y = b.rotation;
    mesh.scale.setScalar(b.scale);
    scene.add(mesh);
    const half = cfg.half.map(h => h * b.scale);
    const bodyId = window.Physics.addStaticBox([b.position.x, b.position.y, b.position.z], half, [0, b.rotation, 0]);
    placedBlocks.push({ id: b.id || nextBlockId++, mesh, bodyId, type: b.type, color: b.color, position: b.position, rotation: b.rotation, scale: b.scale });
  }
  if (window.UI) window.UI.addNotification(`Mapa "${name}" carregado (${data.blocks.length} blocos)`, 'success');
}

function clearAllBlocks() {
  for (const b of placedBlocks) {
    if (b.mesh && b.mesh.parent) b.mesh.parent.remove(b.mesh);
    if (b.mesh.geometry) b.mesh.geometry.dispose();
    if (b.mesh.material) b.mesh.material.dispose();
    window.Physics.removeBody(b.bodyId);
  }
  placedBlocks = [];
}

window.Builder = {
  init: BuilderInit, toggle, isActive, update: BuilderUpdate,
  placeBlock, deleteBlock, receiveBuild, clearAll: clearAllBlocks
};
})();
