// ============================================================
// effects.js — VFX com Three.js
// ============================================================
(function() {
'use strict';

let scene = null;
let particleSystems = [];
let particlesEnabled = true;

function EffectsInit(scn) {
  scene = scn;
  particlesEnabled = window.Save ? window.Save.getSettings().particles : true;
}

function createMuzzleFlash(x, y, z, dx, dy, dz) {
  if (!scene) return;
  const flash = new THREE.PointLight(0xffaa33, 8, 8);
  flash.position.set(x, y, z);
  scene.add(flash);
  particleSystems.push({ mesh: null, light: flash, life: 0.08, maxLife: 0.08, type: 'flash' });
  if (particlesEnabled) {
    for (let i = 0; i < 6; i++) {
      const spark = new THREE.Mesh(
        new THREE.SphereGeometry(0.04, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0xffdd66, transparent: true })
      );
      spark.position.set(x, y, z);
      scene.add(spark);
      const spread = 0.1;
      particleSystems.push({
        mesh: spark, life: 0.3, maxLife: 0.3,
        velocity: new THREE.Vector3(dx + (Math.random() - 0.5) * spread, dy + (Math.random() - 0.5) * spread, dz + (Math.random() - 0.5) * spread),
        gravity: true, fade: true, type: 'spark'
      });
    }
  }
}

function createImpact(x, y, z, nx, ny, nz, color) {
  if (!scene) return;
  color = color || 0x888888;
  const hole = new THREE.Mesh(
    new THREE.CircleGeometry(0.06, 8),
    new THREE.MeshBasicMaterial({ color: 0x111111, transparent: true, opacity: 0.9 })
  );
  hole.position.set(x, y, z);
  hole.lookAt(x + nx, y + ny, z + nz);
  scene.add(hole);
  particleSystems.push({ mesh: hole, life: 5, maxLife: 5, fade: true, type: 'hole' });

  if (particlesEnabled) {
    for (let i = 0; i < 8; i++) {
      const spark = new THREE.Mesh(
        new THREE.SphereGeometry(0.03, 4, 4),
        new THREE.MeshBasicMaterial({ color: 0xffaa33, transparent: true })
      );
      spark.position.set(x, y, z);
      scene.add(spark);
      particleSystems.push({
        mesh: spark, life: 0.4, maxLife: 0.4,
        velocity: new THREE.Vector3(nx * 2 + (Math.random() - 0.5) * 3, ny * 2 + (Math.random() - 0.5) * 3, nz * 2 + (Math.random() - 0.5) * 3),
        gravity: true, fade: true, type: 'spark'
      });
    }
    const smoke = new THREE.Mesh(
      new THREE.SphereGeometry(0.15, 6, 6),
      new THREE.MeshBasicMaterial({ color: 0x666666, transparent: true, opacity: 0.6 })
    );
    smoke.position.set(x, y, z);
    scene.add(smoke);
    particleSystems.push({
      mesh: smoke, life: 1.2, maxLife: 1.2,
      velocity: new THREE.Vector3(nx * 0.5, ny * 0.5 + 0.5, nz * 0.5),
      gravity: false, fade: true, scale: true, type: 'smoke'
    });
  }
}

function createExplosion(x, y, z, radius) {
  if (!scene) return;
  radius = radius || 5;
  const light = new THREE.PointLight(0xff6600, 25, radius * 4);
  light.position.set(x, y, z);
  scene.add(light);
  particleSystems.push({ mesh: null, light, life: 0.4, maxLife: 0.4, type: 'flash' });

  const fire = new THREE.Mesh(
    new THREE.SphereGeometry(radius * 0.4, 16, 16),
    new THREE.MeshBasicMaterial({ color: 0xff4400, transparent: true, opacity: 0.95 })
  );
  fire.position.set(x, y, z);
  scene.add(fire);
  particleSystems.push({ mesh: fire, life: 0.5, maxLife: 0.5, fade: true, scale: true, scaleTo: radius * 1.2, type: 'fire' });

  if (particlesEnabled) {
    for (let i = 0; i < 25; i++) {
      const smoke = new THREE.Mesh(
        new THREE.SphereGeometry(0.3 + Math.random() * 0.4, 6, 6),
        new THREE.MeshBasicMaterial({ color: 0x333333, transparent: true, opacity: 0.7 })
      );
      smoke.position.set(x, y, z);
      scene.add(smoke);
      const ang = Math.random() * Math.PI * 2;
      const elev = Math.random() * Math.PI * 0.5;
      const spd = 3 + Math.random() * 5;
      particleSystems.push({
        mesh: smoke, life: 1.5 + Math.random(), maxLife: 1.5,
        velocity: new THREE.Vector3(Math.cos(ang) * Math.cos(elev) * spd, Math.sin(elev) * spd + 2, Math.sin(ang) * Math.cos(elev) * spd),
        gravity: false, fade: true, scale: true, type: 'smoke'
      });
    }
    for (let i = 0; i < 30; i++) {
      const spark = new THREE.Mesh(
        new THREE.SphereGeometry(0.05, 4, 4),
        new THREE.MeshBasicMaterial({ color: 0xffaa00, transparent: true })
      );
      spark.position.set(x, y, z);
      scene.add(spark);
      const ang = Math.random() * Math.PI * 2;
      const elev = Math.random() * Math.PI * 0.5;
      const spd = 8 + Math.random() * 10;
      particleSystems.push({
        mesh: spark, life: 0.6, maxLife: 0.6,
        velocity: new THREE.Vector3(Math.cos(ang) * Math.cos(elev) * spd, Math.sin(elev) * spd, Math.sin(ang) * Math.cos(elev) * spd),
        gravity: true, fade: true, type: 'spark'
      });
    }
  }
}

function createBulletTrail(from, to, color) {
  if (!scene) return;
  color = color || 0xffff66;
  const geom = new THREE.BufferGeometry().setFromPoints([from, to]);
  const mat = new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.9 });
  const line = new THREE.Line(geom, mat);
  scene.add(line);
  particleSystems.push({ mesh: line, life: 0.08, maxLife: 0.08, fade: true, type: 'trail' });
}

function createHitMarker(position) {
  if (!scene) return;
  const marker = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xff0000, transparent: true, opacity: 0.8 })
  );
  marker.position.copy(position);
  scene.add(marker);
  particleSystems.push({ mesh: marker, life: 0.3, maxLife: 0.3, fade: true, scale: true, type: 'marker' });
}

function createBlood(x, y, z, dir) {
  if (!scene || !particlesEnabled) return;
  for (let i = 0; i < 12; i++) {
    const drop = new THREE.Mesh(
      new THREE.SphereGeometry(0.05, 4, 4),
      new THREE.MeshBasicMaterial({ color: 0xaa0000, transparent: true })
    );
    drop.position.set(x, y, z);
    scene.add(drop);
    particleSystems.push({
      mesh: drop, life: 0.5, maxLife: 0.5,
      velocity: new THREE.Vector3(dir.x * 2 + (Math.random() - 0.5) * 4, dir.y * 2 + Math.random() * 2, dir.z * 2 + (Math.random() - 0.5) * 4),
      gravity: true, fade: true, type: 'blood'
    });
  }
}

// ===== Partículas ambientais (poeira, fumaça, neve) =====
function createAmbientParticles(count, type) {
  if (!scene || !particlesEnabled) return null;
  type = type || 'dust';
  const geometry = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  const velocities = [];
  const colors = new Float32Array(count * 3);
  const sizes = new Float32Array(count);

  for (let i = 0; i < count; i++) {
    positions[i*3] = (Math.random() - 0.5) * 100;
    positions[i*3+1] = Math.random() * 30;
    positions[i*3+2] = (Math.random() - 0.5) * 100;
    velocities.push(new THREE.Vector3(
      (Math.random() - 0.5) * 0.3,
      -Math.random() * 0.5 - 0.1,
      (Math.random() - 0.5) * 0.3
    ));
    if (type === 'snow') {
      colors[i*3] = 1; colors[i*3+1] = 1; colors[i*3+2] = 1;
      sizes[i] = 0.1 + Math.random() * 0.1;
    } else if (type === 'dust') {
      colors[i*3] = 0.9; colors[i*3+1] = 0.8; colors[i*3+2] = 0.6;
      sizes[i] = 0.04 + Math.random() * 0.06;
    } else {
      colors[i*3] = 1; colors[i*3+1] = 0.6; colors[i*3+2] = 0.3;
      sizes[i] = 0.06 + Math.random() * 0.08;
    }
  }
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  geometry.setAttribute('size', new THREE.BufferAttribute(sizes, 1));

  const material = new THREE.PointsMaterial({
    size: 0.1, vertexColors: true,
    transparent: true, opacity: 0.6,
    blending: THREE.AdditiveBlending,
    depthWrite: false
  });
  const points = new THREE.Points(geometry, material);
  points.userData.velocities = velocities;
  points.userData.type = type;
  scene.add(points);
  return points;
}

function updateAmbientParticles(points, delta) {
  if (!points) return;
  const positions = points.geometry.attributes.position.array;
  const velocities = points.userData.velocities;
  for (let i = 0; i < velocities.length; i++) {
    positions[i*3] += velocities[i].x * delta;
    positions[i*3+1] += velocities[i].y * delta;
    positions[i*3+2] += velocities[i].z * delta;
    // Reseta quando cai no chão
    if (positions[i*3+1] < 0) {
      positions[i*3] = (Math.random() - 0.5) * 100;
      positions[i*3+1] = 30;
      positions[i*3+2] = (Math.random() - 0.5) * 100;
    }
  }
  points.geometry.attributes.position.needsUpdate = true;
}

function EffectsUpdate(delta) {
  for (let i = particleSystems.length - 1; i >= 0; i--) {
    const p = particleSystems[i];
    p.life -= delta;
    if (p.light) p.light.intensity *= 0.85;
    if (p.mesh) {
      if (p.velocity) {
        p.mesh.position.x += p.velocity.x * delta;
        p.mesh.position.y += p.velocity.y * delta;
        p.mesh.position.z += p.velocity.z * delta;
        if (p.gravity) p.velocity.y -= 18 * delta;
      }
      if (p.fade && p.mesh.material) {
        const t = Math.max(0, p.life / p.maxLife);
        p.mesh.material.opacity = t;
      }
      if (p.scale) {
        const t = p.life / p.maxLife;
        const s = p.scaleTo ? Math.max(0.01, 1 + (1 - t) * (p.scaleTo)) : Math.max(0.01, 1 + (1 - t) * 1.5);
        p.mesh.scale.setScalar(s);
      }
    }
    if (p.life <= 0) {
      if (p.mesh) {
        scene.remove(p.mesh);
        if (p.mesh.geometry) p.mesh.geometry.dispose();
        if (p.mesh.material) p.mesh.material.dispose();
      }
      if (p.light) scene.remove(p.light);
      particleSystems.splice(i, 1);
    }
  }
}

function ClearAllEffects() {
  for (const p of particleSystems) {
    if (p.mesh) {
      scene.remove(p.mesh);
      if (p.mesh.geometry) p.mesh.geometry.dispose();
      if (p.mesh.material) p.mesh.material.dispose();
    }
    if (p.light) scene.remove(p.light);
  }
  particleSystems = [];
}

window.Effects = {
  init: EffectsInit,
  createMuzzleFlash, createImpact, createExplosion,
  createBulletTrail, createHitMarker, createBlood,
  createAmbientParticles, updateAmbientParticles,
  update: EffectsUpdate, clearAll: ClearAllEffects
};
})();
