// ============================================================
// inventory.js
// ============================================================
(function() {
'use strict';

const ALL_ITEMS = {
  pistol:   { name: 'Pistola', icon: '🔫', type: 'weapon', price: 0 },
  rifle:    { name: 'Rifle', icon: '🪖', type: 'weapon', price: 200 },
  shotgun:  { name: 'Shotgun', icon: '💥', type: 'weapon', price: 300 },
  sniper:   { name: 'Sniper', icon: '🎯', type: 'weapon', price: 500 },
  launcher: { name: 'Lança-Granada', icon: '🚀', type: 'weapon', price: 800 },
  grenade:  { name: 'Granada', icon: '💣', type: 'weapon', price: 50 },
  cap:      { name: 'Boné', icon: '🧢', type: 'hat', price: 100 },
  helmet:   { name: 'Capacete', icon: '⛑️', type: 'hat', price: 150 },
  tophat:   { name: 'Cartola', icon: '🎩', type: 'hat', price: 200 },
  beanie:   { name: 'Gorro', icon: '🧶', type: 'hat', price: 80 },
  crown:    { name: 'Coroa', icon: '👑', type: 'hat', price: 1000 },
  sunglasses: { name: 'Óculos de Sol', icon: '🕶️', type: 'glasses', price: 100 },
  round:    { name: 'Óculos Redondo', icon: '👓', type: 'glasses', price: 80 },
  vr:       { name: 'VR Headset', icon: '🥽', type: 'glasses', price: 300 },
  visor:    { name: 'Visor Cyber', icon: '🔮', type: 'glasses', price: 250 },
  clown:    { name: 'Máscara Palhaço', icon: '🤡', type: 'mask', price: 150 },
  ninja:    { name: 'Máscara Ninja', icon: '🥷', type: 'mask', price: 200 },
  cyborg:   { name: 'Máscara Cyborg', icon: '🤖', type: 'mask', price: 400 },
  skull:    { name: 'Máscara Caveira', icon: '💀', type: 'mask', price: 350 },
  backpack: { name: 'Mochila', icon: '🎒', type: 'back', price: 120 },
  wings:    { name: 'Asas', icon: '🦋', type: 'back', price: 600 },
  cape:     { name: 'Capa', icon: '🦸', type: 'back', price: 250 },
  jetpack:  { name: 'Jetpack', icon: '🚀', type: 'back', price: 900 }
};

function InventoryInit() { renderInventory(); renderShop(); setupDragDrop(); }

function renderInventory() {
  const grid = document.getElementById('inventoryGrid');
  if (!grid) return;
  const inv = window.Save.getInventory();
  grid.innerHTML = '';
  for (const itemId of inv.items) {
    const item = ALL_ITEMS[itemId];
    if (!item) continue;
    const isEquipped = isItemEquipped(itemId);
    const el = document.createElement('div');
    el.className = 'inv-item' + (isEquipped ? ' equipped' : '');
    el.draggable = true;
    el.dataset.itemId = itemId;
    el.innerHTML = `<div class="inv-icon">${item.icon}</div><div class="inv-name">${item.name}</div>`;
    el.addEventListener('click', () => toggleEquip(itemId));
    el.addEventListener('dragstart', (e) => { e.dataTransfer.setData('text/plain', itemId); });
    grid.appendChild(el);
  }
  document.querySelectorAll('.equip-slot').forEach(slot => {
    const slotName = slot.dataset.slot;
    const equippedId = inv.equipped[slotName];
    slot.classList.toggle('filled', !!equippedId);
    if (equippedId) {
      const item = ALL_ITEMS[equippedId];
      slot.innerHTML = `${item.icon} ${item.name}<br><small style="color:#8b949e">clique para remover</small>`;
      slot.onclick = () => unequip(slotName);
    } else {
      slot.innerHTML = slotName.startsWith('weapon') ? `Arma ${slotName.slice(-1)}` : slotName;
      slot.onclick = () => {};
    }
  });
}

function isItemEquipped(itemId) {
  const inv = window.Save.getInventory();
  for (const slot in inv.equipped) {
    if (inv.equipped[slot] === itemId) return true;
  }
  return false;
}

function toggleEquip(itemId) {
  const item = ALL_ITEMS[itemId];
  if (!item) return;
  const inv = window.Save.getInventory();
  if (item.type === 'weapon') {
    const slots = ['weapon1', 'weapon2', 'weapon3'];
    let slot = slots.find(s => inv.equipped[s] === itemId);
    if (slot) { inv.equipped[slot] = null; }
    else { slot = slots.find(s => !inv.equipped[s]) || 'weapon1'; inv.equipped[slot] = itemId; }
  } else if (item.type === 'hat') inv.equipped.hat = inv.equipped.hat === itemId ? null : itemId;
  else if (item.type === 'glasses') inv.equipped.glasses = inv.equipped.glasses === itemId ? null : itemId;
  else if (item.type === 'mask') inv.equipped.mask = inv.equipped.mask === itemId ? null : itemId;
  else if (item.type === 'back') inv.equipped.back = inv.equipped.back === itemId ? null : itemId;
  window.Save.setInventory(inv);
  const accessories = {
    hat: inv.equipped.hat, glasses: inv.equipped.glasses,
    mask: inv.equipped.mask, back: inv.equipped.back
  };
  window.Save.setAccessories(accessories);
  renderInventory();
  if (window.UI) window.UI.addNotification(`${item.name} ${isItemEquipped(itemId) ? 'equipado' : 'desequipado'}`, 'success');
}

function unequip(slotName) {
  const inv = window.Save.getInventory();
  inv.equipped[slotName] = null;
  window.Save.setInventory(inv);
  const accessories = {
    hat: inv.equipped.hat, glasses: inv.equipped.glasses,
    mask: inv.equipped.mask, back: inv.equipped.back
  };
  window.Save.setAccessories(accessories);
  renderInventory();
}

function setupDragDrop() {
  document.querySelectorAll('.equip-slot').forEach(slot => {
    slot.addEventListener('dragover', (e) => { e.preventDefault(); slot.style.background = '#30363d'; });
    slot.addEventListener('dragleave', () => { slot.style.background = ''; });
    slot.addEventListener('drop', (e) => {
      e.preventDefault(); slot.style.background = '';
      const itemId = e.dataTransfer.getData('text/plain');
      const item = ALL_ITEMS[itemId];
      if (!item) return;
      const slotName = slot.dataset.slot;
      if (slotName.startsWith('weapon') && item.type !== 'weapon') return;
      if (slotName === 'hat' && item.type !== 'hat') return;
      if (slotName === 'mask' && item.type !== 'mask' && item.type !== 'glasses') return;
      if (slotName === 'back' && item.type !== 'back') return;
      const inv = window.Save.getInventory();
      inv.equipped[slotName] = itemId;
      window.Save.setInventory(inv);
      const accessories = {
        hat: inv.equipped.hat, glasses: inv.equipped.glasses,
        mask: inv.equipped.mask, back: inv.equipped.back
      };
      window.Save.setAccessories(accessories);
      renderInventory();
    });
  });
}

function renderShop() {
  const grid = document.getElementById('shopGrid');
  if (!grid) return;
  const shop = window.Save.getShop();
  document.getElementById('shopCoins').textContent = shop.coins;
  grid.innerHTML = '';
  for (const itemId in ALL_ITEMS) {
    const item = ALL_ITEMS[itemId];
    const owned = shop.owned.includes(itemId);
    const el = document.createElement('div');
    el.className = 'shop-item';
    el.innerHTML = `
      <div class="shop-item-icon">${item.icon}</div>
      <div class="shop-item-name">${item.name}</div>
      <div class="shop-item-price">🪙 ${item.price}</div>
      <button ${owned ? 'disabled' : ''}>${owned ? '✓ Possui' : 'Comprar'}</button>
    `;
    if (!owned) el.querySelector('button').onclick = () => buyItem(itemId);
    grid.appendChild(el);
  }
}

function buyItem(itemId) {
  const item = ALL_ITEMS[itemId];
  if (!item) return;
  const shop = window.Save.getShop();
  if (shop.coins < item.price) {
    if (window.UI) window.UI.addNotification('Moedas insuficientes!', 'error');
    return;
  }
  shop.coins -= item.price;
  shop.owned.push(itemId);
  const inv = window.Save.getInventory();
  if (!inv.items.includes(itemId)) inv.items.push(itemId);
  window.Save.setShop(shop);
  window.Save.setInventory(inv);
  if (window.UI) window.UI.addNotification(`${item.name} comprado!`, 'success');
  renderShop(); renderInventory();
}

function addCoins(amount) {
  const shop = window.Save.getShop();
  shop.coins += amount;
  window.Save.setShop(shop);
  renderShop();
}

window.Inventory = {
  init: InventoryInit, render: renderInventory, renderShop,
  toggleEquip, unequip, buyItem, addCoins, ALL_ITEMS
};
})();
